"""Compare undirected water-network and Euclidean distance on identical nitrate inputs."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.spatial import Delaunay
from scipy.spatial.distance import cdist

from enrich_agv_gis import normalize_reaches
from fit_nitrate_distance import COLUMNS, PARAMETER, distance_kernel, fit_sources, metrics, spatial_validation
from prepare_nitrogen import ROOT, parse_dates
from water_connectivity import build_network


def load_cached_network(directory: Path) -> tuple[nx.MultiGraph, dict, pd.DataFrame, dict]:
    collections = {
        name: json.loads((directory / "source" / f"{name}.geojson").read_text(encoding="utf-8"))
        for name in ("watercourses", "culverts")
    }
    reaches, _, _ = normalize_reaches(collections)
    matches = pd.read_csv(directory / "measurement_network_matches.csv", dtype={"location_code": str})
    if matches["location_code"].duplicated().any():
        raise ValueError("GIS measurement matches must have unique location codes.")
    graph, stations = build_network(reaches, matches)
    provenance = json.loads((directory / "provenance.json").read_text(encoding="utf-8"))
    counts = {"reach_count": len(reaches), "graph_nodes": len(graph), "graph_edges": graph.number_of_edges()}
    if any(provenance[key] != value for key, value in counts.items()):
        raise ValueError("Cached GIS topology does not reproduce its provenance; regenerate GIS enrichment.")
    if any(node not in graph for node in stations.values()):
        raise ValueError("A matched station has no reconstructed network node.")
    return graph, stations, matches, provenance


def network_candidates(graph: nx.Graph, stations: dict, spacing: float) -> tuple[pd.DataFrame, dict]:
    if graph.is_directed():
        raise ValueError("This connectivity-distance version requires an undirected graph.")
    if not np.isfinite(spacing) or spacing <= 0:
        raise ValueError("Candidate spacing must be finite and positive.")
    points = np.array(list(stations.values()), dtype=float)
    if len(points) < 3 or np.linalg.matrix_rank(points - points.mean(axis=0)) < 2:
        raise ValueError("Candidates require at least three non-collinear matched monitoring sites.")
    components = {node: number for number, nodes in enumerate(nx.connected_components(graph), start=1)
                  for node in nodes}
    observed_components = {components[node] for node in stations.values()}
    hull = Delaunay(points)
    nodes = sorted(node for node in graph if components[node] in observed_components)
    inside = hull.find_simplex(np.array(nodes), tol=1e-8) >= 0
    representatives = {}
    for node, accepted in zip(nodes, inside):
        if not accepted:
            continue
        x, y = node
        cell_x, cell_y = int(np.floor(x / spacing)), int(np.floor(y / spacing))
        key = (components[node], cell_x, cell_y)
        distance = (x - (cell_x + .5) * spacing) ** 2 + (y - (cell_y + .5) * spacing) ** 2
        proposal = (distance, node)
        if key not in representatives or proposal < representatives[key]:
            representatives[key] = proposal
    if len(representatives) > 10000:
        raise ValueError("More than 10,000 network candidates; increase candidate spacing.")
    rows = [
        {"candidate_id": f"NET{index:04d}", "network_component": key[0],
         "cell_x": key[1], "cell_y": key[2], "rd_x": choice[1][0], "rd_y": choice[1][1]}
        for index, (key, choice) in enumerate(sorted(representatives.items()))
    ]
    sources = pd.DataFrame(rows)
    if sources.empty or set(sources["network_component"]) != observed_components:
        raise ValueError("Every observed network component must have candidate support.")
    return sources, components


def network_distances(graph: nx.Graph, sensors: list, candidates: list) -> np.ndarray:
    if graph.is_directed():
        raise ValueError("This connectivity-distance version requires an undirected graph.")
    if any(node not in graph for node in sensors + candidates):
        raise ValueError("Every sensor and candidate must be a network node.")
    result = np.full((len(sensors), len(candidates)), np.inf)
    for index, node in enumerate(sensors):
        distances = nx.single_source_dijkstra_path_length(graph, node, weight="weight")
        result[index] = [distances.get(candidate, np.inf) for candidate in candidates]
    return result


def network_kernel(distances: np.ndarray, decay_length: float) -> np.ndarray:
    if not np.isfinite(decay_length) or decay_length <= 0:
        raise ValueError("Decay length must be finite and positive.")
    if np.isnan(distances).any() or (distances < 0).any():
        raise ValueError("Network distances must be nonnegative lengths or infinity for disconnected pairs.")
    return np.exp(-distances / decay_length)


def write_report(output: Path, sources: pd.DataFrame, observations: pd.DataFrame,
                 comparison: pd.DataFrame, metadata: dict) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    for axis, column, title in zip(axes[:2], ["relative_score", "euclidean_relative_score"],
                                   ["Water-connectivity distance", "Euclidean: identical support"]):
        cloud = axis.scatter(sources["rd_x"] / 1000, sources["rd_y"] / 1000, c=sources[column],
                             vmin=0, vmax=1, cmap="Purples", s=35)
        sites = observations.drop_duplicates("location_code")
        axis.scatter(sites["model_rd_x"] / 1000, sites["model_rd_y"] / 1000, s=4, c="black")
        axis.set(xlabel="RD east (km)", ylabel="RD north (km)", title=title)
        axis.set_aspect("equal")
        fig.colorbar(cloud, ax=axis, label="Relative coefficient (not probability)")
    exact = observations.loc[observations["value_kind"].eq("exact")]
    means = exact.groupby("location_code")[[
        "value", "held_out_prediction_mg_n_l", "euclidean_held_out_prediction_mg_n_l",
    ]].mean()
    axes[2].scatter(means["value"], means["held_out_prediction_mg_n_l"], s=13, label="Network")
    axes[2].scatter(means["value"], means["euclidean_held_out_prediction_mg_n_l"],
                    s=13, marker="x", label="Euclidean")
    limit = float(means.max().max())
    axes[2].plot([0, limit], [0, limit], color="grey", linestyle="--")
    axes[2].set(xlabel="Observed site mean (uncensored, mg N/L)",
                ylabel="Held-out prediction (mg N/L)", title="Same geographic holdouts")
    axes[2].legend()
    fig.tight_layout()
    fig.savefig(output / "network_distance_diagnostics.png", dpi=150)
    plt.close(fig)
    scores = comparison.set_index("model")["exact_rmse_mg_n_l"]
    verdict = ("Network distance improves held-out exact-result RMSE over both comparison models."
               if scores["network"] < min(scores["euclidean_same_support"], scores["offset_only"]) else
               "Network distance does NOT beat both comparison models on held-out exact-result RMSE. "
               "Connectivity alone does not establish source locations.")
    document = f"""<!doctype html><html lang="en"><meta charset="utf-8">
<title>Nitrate water-connectivity distance</title>
<style>body{{font:16px system-ui;max-width:1200px;margin:32px auto;padding:16px}}
table{{border-collapse:collapse;font-size:14px}}td,th{{border:1px solid #ddd;padding:6px}}
img{{max-width:100%}}.warning{{padding:16px;background:#fff3cd}}</style>
<h1>Nitrate water-connectivity distance: {metadata['year']}</h1>
<p>{metadata['observation_count']} results at {metadata['site_count']} unambiguously matched sites;
{metadata['excluded_site_count']} baseline sites excluded for unavailable/ambiguous network assignment.
{metadata['upper_bound_count']} below-detection results remain soft upper bounds. Fixed GMT+1.</p>
<p class="warning">{html.escape(verdict)} Candidate scores are not confirmed sources, probabilities,
credible intervals or pollution loads.</p>
<h2>Like-for-like geographic holdout comparison (mg N/L)</h2>
{comparison.to_html(index=False, float_format=lambda x: f'{x:.5g}')}
<p>All three rows use identical observations, site folds and censoring treatment. Both distance
models use identical on-network candidates, snapped sensor coordinates, decay length and ridge
penalty. The original all-site Euclidean baseline is untouched; its
{metadata['original_baseline']['site_count']}-site held-out RMSE of
{metadata['original_baseline']['held_out_rmse_mg_n_l']:.5g} is context only, NOT a like-for-like comparison.</p>
<p>Network kernel: A[i,j] = exp(-shortest_undirected_water_network_length(i,j) /
{metadata['decay_length_m']:g} m), with exactly zero source influence for disconnected pairs.
Finite paths may traverse intervening measurement sites. A shared, fitted constant offset is
not transported across the network and is not measured upstream background.</p>
<p>Candidate spacing: {metadata['grid_spacing_m']:g} m; regularization:
{metadata['regularization']:g}. One graph node nearest each occupied cell centre per observed
connected component, inside the monitoring-site convex hull. Candidate locations need not be
cell centres; components in the same cell remain separate. Candidate selection uses geometry
only, not concentration values, and is held fixed across validation folds.</p>
<p>The original conservative GIS matching is reused (maximum
{metadata['gis_provenance']['snap_distance_limit_m']:g} m,
{metadata['gis_provenance']['ambiguous_match_margin_m']:g} m ambiguity margin).
Snapping offsets are audited, not added as artificial off-water route lengths. Both models
use the same snapped coordinates. Only shared, rounded endpoints connect reaches; crossings
alone do not. Culverts are included, but hydraulic passability, pump operations and actual
flow direction are unverified. The AMS011 assumed-outlet directions are NOT used.
The current GIS snapshot is not verified historical topology for {metadata['year']}.
No path in this conservative graph does not prove hydraulic isolation in reality.</p>
<p>Fitting reuses the baseline's nonnegative optimizer, equal-total-site weights and squared
exact residual / positive upper-bound-violation loss. No zeros or limit/2 are substituted.
No Bayesian inference, transport-time calibration, reactions, source inventories or land
attribution are added. Scores are separately normalized within each model, not probabilities.</p>
<img src="network_distance_diagnostics.png" alt="Network and Euclidean candidate scores and held-out predictions">
<p>All dates at a station stay together in geographic-quadrant holdouts without a boundary
buffer. Held-out predictions for components unseen in training are flagged explicitly;
network-source contributions there are zero, with only the shared offset remaining.
Seasonal variation is diagnosed, not fitted. No hyperparameter search was performed.</p>
<p><a href="../nitrogen_source_analysis/nitrogen_map.html?model=network">Open network model on existing map</a>
 | <a href="model_metadata.json">Metadata</a> | <a href="comparison.csv">Comparison CSV</a>
 | <a href="candidate_sources.geojson">Candidate GeoJSON</a>
 | <a href="observations_with_predictions.csv">Audited predictions</a>
 | <a href="excluded_observations.csv">Excluded observations</a>
 | <a href="source_receptor_distances.csv">Distances and connectivity</a>
 | <a href="seasonal_diagnostics.csv">Seasonal diagnostics</a></p></html>"""
    (output / "report.html").write_text(document, encoding="utf-8")


def run(data_dir: Path, baseline_dir: Path, output: Path, spacing: float | None = None,
        decay_length: float | None = None, regularization: float | None = None) -> dict:
    if output.resolve() in {baseline_dir.resolve(), data_dir.resolve()}:
        raise ValueError("Network outputs must be separate from the baseline and prepared data.")
    baseline_path = baseline_dir / "model_metadata.json"
    observation_path = baseline_dir / "observations_with_predictions.csv"
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    spacing = baseline["grid_spacing_m"] if spacing is None else spacing
    decay_length = baseline["decay_length_m"] if decay_length is None else decay_length
    regularization = baseline["regularization"] if regularization is None else regularization
    observations = pd.read_csv(observation_path, dtype={"sample_id": str, "location_code": str,
                                                       "quality_code": str}, keep_default_na=False)
    if (len(observations) != baseline["observation_count"]
            or not observations["parameter_id"].eq(PARAMETER).all()
            or not observations["use_in_model"].eq(True).all()
            or not parse_dates(observations["date_time"]).dt.year.eq(baseline["year"]).all()):
        raise ValueError("Baseline observation snapshot disagrees with its metadata or eligibility.")
    observations = observations[COLUMNS + [
        "location_name", "rd_x", "rd_y", "longitude", "latitude", "value_kind",
    ]].copy()
    graph, station_nodes, matches, provenance = load_cached_network(data_dir / "gis")
    match_columns = ["location_code", "snap_status", "distance_to_watercourse_m", "manual_review_recommended"]
    audited = observations.merge(matches[match_columns], on="location_code", how="left", validate="many_to_one")
    audited["included_in_network_model"] = (
        audited["snap_status"].eq("matched") & audited["location_code"].isin(station_nodes))
    audited["network_exclusion_reason"] = np.where(
        audited["included_in_network_model"], "", "network_" + audited["snap_status"].fillna("missing_match"))
    excluded = audited.loc[~audited["included_in_network_model"]].copy()
    observations = audited.loc[audited["included_in_network_model"]].copy().reset_index(drop=True)
    codes = sorted(observations["location_code"].unique())
    selected_nodes = {code: station_nodes[code] for code in codes}
    sources, components = network_candidates(graph, selected_nodes, spacing)
    observations["network_component"] = observations["location_code"].map(
        {code: components[node] for code, node in selected_nodes.items()})
    observations["model_rd_x"] = observations["location_code"].map({code: node[0] for code, node in selected_nodes.items()})
    observations["model_rd_y"] = observations["location_code"].map({code: node[1] for code, node in selected_nodes.items()})
    sites = observations.drop_duplicates("location_code").sort_values("location_code")
    sensor_nodes = [selected_nodes[code] for code in sites["location_code"]]
    candidate_nodes = list(sources[["rd_x", "rd_y"]].itertuples(index=False, name=None))
    distances = network_distances(graph, sensor_nodes, candidate_nodes)
    straight_distances = cdist(sensor_nodes, candidate_nodes)
    site_index = pd.Series(np.arange(len(sites)), index=sites["location_code"])
    row_indices = observations["location_code"].map(site_index).to_numpy()
    kernels = {
        "network": network_kernel(distances, decay_length),
        "euclidean_same_support": distance_kernel(np.array(sensor_nodes), np.array(candidate_nodes), decay_length),
    }
    fitted_models, validations, prediction_tables = {}, {}, {}
    for name, site_kernel in kernels.items():
        kernel = site_kernel[row_indices]
        fitted_models[name] = fit_sources(kernel, observations, regularization)
        prediction_tables[name], validations[name] = spatial_validation(observations, sites, kernel, regularization)
        validations[name]["candidate_domain"] = "Identical on-network nodes; fixed geometry-only candidate support."
    predictions = prediction_tables["network"]
    euclidean_predictions = prediction_tables["euclidean_same_support"]
    if not np.array_equal(predictions["spatial_fold"], euclidean_predictions["spatial_fold"]):
        raise RuntimeError("Comparison models must use identical geographic folds.")
    predictions["fitted_prediction_mg_n_l"] = fitted_models["network"]["prediction"]
    predictions["euclidean_fitted_prediction_mg_n_l"] = fitted_models["euclidean_same_support"]["prediction"]
    predictions["euclidean_held_out_prediction_mg_n_l"] = euclidean_predictions["held_out_prediction_mg_n_l"]
    predictions["exact_residual_mg_n_l"] = np.where(
        predictions["value_kind"].eq("exact"), predictions["fitted_prediction_mg_n_l"] - predictions["value"], np.nan)
    predictions["upper_bound_violation_mg_n_l"] = np.where(
        predictions["value_kind"].eq("upper_bound"),
        np.maximum(predictions["fitted_prediction_mg_n_l"] - predictions["value"], 0), np.nan)
    predictions["component_seen_in_training"] = [
        bool(((predictions["network_component"] == component) & predictions["spatial_fold"].ne(fold)).any())
        for component, fold in zip(predictions["network_component"], predictions["spatial_fold"])
    ]
    transform = Transformer.from_crs(28992, 4326, always_xy=True)
    sources["longitude"], sources["latitude"] = transform.transform(sources["rd_x"], sources["rd_y"])
    for name, prefix in [("network", ""), ("euclidean_same_support", "euclidean_")]:
        values = fitted_models[name]["sources"]
        sources[prefix + "coefficient_mg_n_l"] = values
        sources[prefix + "relative_score"] = values / values.max() if values.max() > 0 else np.zeros(len(values))
    comparison = pd.DataFrame([
        {"model": name, **validations[name]["distance_model"]} for name in kernels
    ] + [{"model": "offset_only", **validations["network"]["offset_only"]}])
    metadata = {
        "model": "Nonnegative regularized undirected water-connectivity distance inversion",
        "year": baseline["year"], "start": baseline["start"], "end": baseline["end"],
        "parameter_id": PARAMETER, "unit": "mg N/L", "time_zone": baseline["time_zone"],
        "grid_spacing_m": spacing, "decay_length_m": decay_length, "regularization": regularization,
        "site_count": len(sites), "observation_count": len(predictions), "candidate_count": len(sources),
        "exact_count": int(predictions["value_kind"].eq("exact").sum()),
        "upper_bound_count": int(predictions["value_kind"].eq("upper_bound").sum()),
        "excluded_site_count": int(excluded["location_code"].nunique()), "excluded_observation_count": len(excluded),
        "exclusion_counts": excluded["network_exclusion_reason"].value_counts().to_dict(),
        "observed_components": int(predictions["network_component"].nunique()),
        "disconnected_source_receptor_pairs": int(np.isinf(distances).sum()),
        "held_out_rows_in_components_unseen_in_training": int((~predictions["component_seen_in_training"]).sum()),
        "candidate_rule": "Nearest graph node to cell centre, per cell and observed component, within monitoring convex hull.",
        "routing": "Undirected Dijkstra with reach lengths in RD metres; disconnected paths have infinite distance and zero kernel.",
        "snap_offsets": "Not added to route length; Euclidean comparison also uses snapped sensor coordinates.",
        "topology": "Cached official watercourses and culverts; only shared endpoints rounded to 0.01 m form junctions.",
        "limitations": "Potential geometric connectivity only; passability, historical topology, pump operation and flow direction unverified. No AMS011 direction scenario. No graph path does not prove hydraulic isolation.",
        "fitting": {"objective": baseline["objective"], "censoring": baseline["censoring"],
                    "offset": baseline["offset"], "uncertainty": baseline["uncertainty"]},
        "gis_provenance": {"path": str(data_dir / "gis" / "provenance.json"),
                           "graph_nodes": len(graph), "graph_edges": graph.number_of_edges(),
                           "snap_distance_limit_m": provenance["snap_distance_limit_m"],
                           "ambiguous_match_margin_m": provenance["ambiguous_match_margin_m"]},
        "original_baseline": {
            "directory": str(baseline_dir), "site_count": baseline["site_count"],
            "held_out_rmse_mg_n_l": baseline["spatial_validation"]["distance_model"]["exact_rmse_mg_n_l"],
            "metadata_sha256": hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
            "observations_sha256": hashlib.sha256(observation_path.read_bytes()).hexdigest(),
        },
        "models": {
            name: {"offset_mg_n_l": fitted["offset"], "solver_objective": fitted["objective"],
                   "solver_iterations": fitted["iterations"],
                   "training_metrics": metrics(observations, fitted["prediction"]),
                   "spatial_validation": validations[name]}
            for name, fitted in fitted_models.items()
        },
        "comparison": comparison.to_dict(orient="records"),
    }
    features = [{
        "type": "Feature", "geometry": {"type": "Point", "coordinates": [float(row.longitude), float(row.latitude)]},
        "properties": {"candidate_id": row.candidate_id, "network_component": int(row.network_component),
                       "coefficient_mg_n_l": float(row.coefficient_mg_n_l), "relative_score": float(row.relative_score),
                       "euclidean_coefficient_mg_n_l": float(row.euclidean_coefficient_mg_n_l),
                       "euclidean_relative_score": float(row.euclidean_relative_score)},
    } for row in sources.itertuples(index=False)]
    geojson = {"type": "FeatureCollection", "features": features}
    rmse = comparison.set_index("model")["exact_rmse_mg_n_l"]
    map_data = {
        "metric": "network", "start": baseline["start"], "end": baseline["end"], "parameter": PARAMETER,
        "gridSpacing": spacing, "decayLength": decay_length, "sources": geojson,
        "validationImproved": bool(rmse["network"] < rmse["offset_only"]),
        "siteCount": len(sites), "excludedSiteCount": metadata["excluded_site_count"],
        "comparison": {name: float(value) for name, value in rmse.items()},
        "includedSites": codes,
    }
    output.mkdir(parents=True, exist_ok=True)
    sources.to_csv(output / "candidate_sources.csv", index=False)
    predictions.to_csv(output / "observations_with_predictions.csv", index=False)
    excluded.to_csv(output / "excluded_observations.csv", index=False)
    comparison.to_csv(output / "comparison.csv", index=False)
    pairs = pd.DataFrame({
        "location_code": np.repeat(sites["location_code"].to_numpy(), len(sources)),
        "candidate_id": np.tile(sources["candidate_id"].to_numpy(), len(sites)),
        "connected": np.isfinite(distances).ravel(),
        "network_distance_m": np.where(np.isfinite(distances), distances, np.nan).ravel(),
        "euclidean_distance_m": straight_distances.ravel(),
        "network_kernel": kernels["network"].ravel(), "euclidean_kernel": kernels["euclidean_same_support"].ravel(),
    })
    pairs.to_csv(output / "source_receptor_distances.csv", index=False)
    seasonal = []
    for quarter, group in predictions.groupby(parse_dates(predictions["date_time"]).dt.quarter):
        for name, column in [("network", "held_out_prediction_mg_n_l"),
                             ("euclidean_same_support", "euclidean_held_out_prediction_mg_n_l"),
                             ("offset_only", "held_out_offset_only_mg_n_l")]:
            seasonal.append({"quarter": int(quarter), "model": name, **metrics(group, group[column].to_numpy())})
    pd.DataFrame(seasonal).to_csv(output / "seasonal_diagnostics.csv", index=False)
    for filename, data in [("model_metadata.json", metadata), ("candidate_sources.geojson", geojson),
                           ("model_map.json", map_data)]:
        (output / filename).write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    write_report(output, sources, predictions, comparison, metadata)
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "datasets" / "nitrogen_source_analysis")
    parser.add_argument("--baseline-dir", type=Path, default=ROOT / "datasets" / "nitrate_distance_baseline_2024")
    parser.add_argument("--output", type=Path, default=ROOT / "datasets" / "nitrate_network_distance_2024")
    parser.add_argument("--grid-spacing-m", type=float, help="Defaults to the preserved baseline setting.")
    parser.add_argument("--decay-length-m", type=float, help="Defaults to the preserved baseline setting.")
    parser.add_argument("--regularization", type=float, help="Defaults to the preserved baseline setting.")
    args = parser.parse_args()
    metadata = run(args.data_dir.resolve(), args.baseline_dir.resolve(), args.output.resolve(),
                   args.grid_spacing_m, args.decay_length_m, args.regularization)
    print(json.dumps({key: metadata[key] for key in [
        "site_count", "observation_count", "excluded_site_count", "candidate_count",
        "observed_components", "comparison",
    ]}, indent=2))
    print(f"Report: {args.output.resolve() / 'report.html'}")


if __name__ == "__main__":
    main()
