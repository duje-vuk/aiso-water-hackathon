(function (root) {
  "use strict";
  const DAY = 86400000;
  const COLORS = ["#FDF0C2", "#FBC56A", "#F28A36", "#C2410C"];
  const dayISO = day => new Date(day * DAY).toISOString().slice(0, 10);
  function isoDay(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
    const time = Date.parse(value + "T00:00:00Z");
    if (!Number.isFinite(time) || dayISO(time / DAY) !== value) return null;
    return time / DAY;
  }
  function validateWindow(start, end, minimum, minDate, maxDate) {
    const first = isoDay(start), last = isoDay(end);
    if (first === null || last === null) return "date";
    if (first > last) return "order";
    if (first < isoDay(minDate) || last > isoDay(maxDate)) return "bounds";
    if (!Number.isInteger(minimum) || minimum < 1) return "minimum";
    return null;
  }
  function lowerBound(rows, day) {
    let low = 0, high = rows.length;
    while (low < high) {
      const middle = Math.floor((low + high) / 2);
      if (rows[middle][0] < day) low = middle + 1;
      else high = middle;
    }
    return low;
  }
  function siteStats(site, parameter, start, end) {
    const rows = site.observations[parameter] || [];
    const first = lowerBound(rows, start), last = lowerBound(rows, end + 1);
    if (last === first) return null;
    const values = rows.slice(first, last).map(row => row[1]).sort((a, b) => a - b);
    const n = values.length, middle = Math.floor(n / 2);
    return {
      n, median: n % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2,
      min: values[0], max: values[n - 1], first: rows[first][0], last: rows[last - 1][0],
    };
  }
  function windowSummary(sites, parameter, start, end, minimum) {
    const visible = [];
    let noData = 0, insufficient = 0, sampleCount = 0;
    for (const site of sites) {
      const stats = siteStats(site, parameter, start, end);
      if (!stats) noData++;
      else if (stats.n < minimum) insufficient++;
      else { visible.push({ site, stats }); sampleCount += stats.n; }
    }
    return { visible, noData, insufficient, sampleCount };
  }
  function colorFor(value, cap) {
    const level = cap > 0 ? Math.min(3, Math.floor(value / cap * 4)) : 0;
    return COLORS[Math.max(0, level)];
  }
  function normalize(value) {
    return String(value || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  }
  function searchSites(sites, query) {
    const text = normalize(query).trim();
    if (!text) return [];
    return sites.filter(site => normalize(site.code + " " + site.name).includes(text))
      .sort((a, b) => Number(normalize(b.code) === text) - Number(normalize(a.code) === text)
        || a.code.localeCompare(b.code)).slice(0, 8);
  }
  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    })[char]);
  }
  function modelMatchesWindow(model, state) {
    return !!model && state.parameter === model.parameter && state.start === model.start && state.end === model.end;
  }
  function availableDistanceModels(payload) {
    const models = {};
    if (payload.distanceModel) models.distance = payload.distanceModel;
    if (payload.connectivityModel) models.network = payload.connectivityModel;
    if (payload.dailyModels) {
      models["daily-distance"] = { ...payload.dailyModels, dailyMetric: "euclidean" };
      models["daily-network"] = { ...payload.dailyModels, dailyMetric: "network" };
    }
    return models;
  }
  function resolveDailyModel(model, date) {
    if (!model || !model.dailyMetric) return model;
    const entry = model.days[date];
    if (!entry) throw new RangeError("Daily model date is outside the available calendar.");
    const fitted = entry.status === "fitted" ? entry.fits[model.dailyMetric] : null;
    const maximum = model.normalizationMaxima[model.dailyMetric];
    const features = fitted ? model.candidates.features.map((feature, index) => ({
      ...feature, properties: { ...feature.properties, coefficient_mg_n_l: fitted.coefficients[index],
        relative_score: maximum > 0 ? fitted.coefficients[index] / maximum : 0 },
    })) : [];
    return {
      ...entry, isDaily: true, dailyMetric: model.dailyMetric, parameter: model.parameter,
      start: date, end: date, minimumSites: model.minimumSites, minimumExactSites: model.minimumExactSites,
      sources: { type: "FeatureCollection", features },
    };
  }
  function adjacentModelDay(date, step, start, end) {
    const day = isoDay(date), first = isoDay(start), last = isoDay(end);
    if (day === null || first === null || last === null || ![-1, 1].includes(step)) return null;
    const next = day + step;
    return next < first || next > last ? null : dayISO(next);
  }
  function bootstrapFeatures(model, stability) {
    if (!model || !model.isDaily || model.status !== "fitted" || !stability) return [];
    const entry = stability.days[model.start];
    if (!entry || entry.status !== "available") return [];
    const values = entry.models[model.dailyMetric];
    return model.sources.features.map((feature, index) => ({
      ...feature, properties: { ...feature.properties, selectionFrequency: values.selectionFrequency[index],
        coefficientP025: values.coefficientP025[index], coefficientMedian: values.coefficientMedian[index],
        coefficientP975: values.coefficientP975[index] },
    }));
  }
  const STABILITY_COLORS = ["#f0f9e8", "#bae4bc", "#7bccc4", "#43a2ca", "#0868ac"];
  const stabilityColor = frequency => STABILITY_COLORS[Math.min(4, Math.floor(frequency * 5))];
  const api = { isoDay, dayISO, validateWindow, siteStats, windowSummary, colorFor, searchSites, escapeHTML, modelMatchesWindow, availableDistanceModels, resolveDailyModel, adjacentModelDay, bootstrapFeatures, stabilityColor };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof document === "undefined") return;
  root.NitrogenMap = api;

  const STR = {
    en: {
      title: "Amstel nitrogen map", badge: "REAL AGV DATA", search: "Search location: ID, name or place",
      filterTitle: "Nitrogen and time window", pollutantLabel: "Nitrogen pollutant",
      startLabel: "From (inclusive, GMT+1)", endLabel: "To (inclusive, GMT+1)", minimumLabel: "Minimum samples per location",
      allDates: "All data", recentDates: "2015 onward", lastYear: "Last 12 months of data",
      cancel: "Cancel", apply: "Apply filters", filters: "Filters", fit: "Fit visible sites",
      methodTitle: "Data, interpretation and privacy", reportLink: "Full data preparation report",
      coverage: (a, b) => `Available observations: ${a} to ${b}. No interpolation or zero-filling.`,
      status: (n, count, missing, low) => `${n} locations shown | ${count} eligible analyte samples | ${missing} locations without data in this window | ${low} below minimum sample count`,
      empty: "No locations meet these filters. Change the pollutant, dates or minimum sample count.",
      median: "Median", samples: "Eligible samples", range: "Observed range", observed: "Samples within this window",
      insufficient: "Fewer samples than required", noData: "No eligible measurements in this window",
      legend: "Median concentration (mg N/L)", scale: "Fixed analyte scale across all dates. Colors are not regulatory classes. Top color includes values above the scale cap.",
      cap: "95th percentile scale cap",
      method: "Real AGV surface-water samples only: quality code 0, valid dates, finite nonnegative concentrations, no censored inequalities. Laboratory replicates are median-aggregated per sample/analyte in the prepared wide table. All timestamps are assumed fixed GMT+1 (UTC+01:00, without daylight-saving changes), as requested by the user. Source calendar days are retained. Start and end are inclusive. At least five samples per location by default; locations without data or below the minimum are hidden, never treated as zero. RD New coordinates were assumed and converted to WGS84; invalid or ambiguous locations are excluded. Colors use a fixed per-analyte 95th percentile of all mapped eligible sample values. The last year is partial. Monitoring locations are not predicted pollution sources.",
      privacy: "All measurement filtering and statistics run locally in your browser. Leaflet is stored locally. The grey PDOK/Kadaster basemap, as in the supplied map, requires internet and receives tile/viewport requests, but no measurement values, site names or searches. If tiles fail, points remain visible on a blank map with an explicit warning. No analytics, geocoding or measurement uploads.",
      tileError: "Background tiles could not load. Real monitoring points remain available; check your internet connection. No alternative provider was contacted.",
      noResults: "No monitoring locations found.",
      networkLabel: "Watercourses and culverts", pumpLabel: "Pumping stations", structureLabel: "Weirs and dams",
      clearRelations: "Clear highlighted links", gisReportLink: "GIS sources, relationships and assumptions",
      gisScenario: (outlet, count, offset) => `ASSUMED OUTLET SCENARIO: ${outlet} | ${count} sites connected in the geometric network | outlet snap ${offset} m. Not observed flow. Click a monitoring point for network links.`,
      networkTitle: "Assumed outlet connectivity", snap: "Centreline offset", review: "Manual match review recommended",
      upstream: "Scenario upstream", downstream: "Scenario downstream", unresolved: "Direction unresolved",
      notMatched: "Unmatched or ambiguous watercourse assignment; no flow direction inferred.",
      flowNote: "Blue: toward the chosen outlet. Purple: upstream neighbors. Arrows are scenario assumptions, not measured flow. Hydraulic passability is unverified.",
      structureNote: "Hydraulic structures near this route; operating state unknown.",
      more: n => `and ${n} more`,
      modelLabel: "Distance-only candidate scores (purple, not confirmed sources)",
      modelWindow: "Use model nitrate/date window",
      modelDescription: (a, b) => `Fixed model: ${a} to ${b}, GMT+1. Purple intensity/size = relative coefficient (0–1), NOT probability or pollution load. No flow direction or water connectivity.`,
      modelMismatch: "Overlay hidden: select nitrate and exactly the model date window to compare. Measurement filters do not refit the model.",
      modelWeak: "WARNING: geographic holdout RMSE does not improve over a constant-only model. Source locations are not established.",
      modelCandidate: "Distance-model candidate", modelScore: "Relative score (0–1, not probability)",
      modelAmplitude: "Kernel amplitude (mg N/L, not emission rate)",
      modelKind: "Distance model version", modelEuclidean: "Straight-line baseline",
      modelNetwork: "Water-connectivity distance",
      networkModelDescription: (a, b, n, excluded) => `Fixed model: ${a} to ${b}, GMT+1. Shortest undirected water-network distance; ${n} matched sites used, ${excluded} baseline sites excluded. Purple = relative coefficient, NOT probability or pollution load. Flow direction and hydraulic passability are unverified. Orange measurements still include all sites meeting the filters.`,
      networkComparison: (n, e, b) => `Same-support holdout RMSE (mg N/L): network ${n}, straight-line ${e}, constant-only ${b}.`,
      networkFitSite: "Included in connectivity-distance fit",
      networkExcludedSite: "Not included in connectivity-distance fit (unmatched or ambiguous network assignment)",
      modelDailyEuclidean: "Daily straight-line (matched sites)", modelDailyNetwork: "Daily water-connectivity",
      dailyDateLabel: "Day (GMT+1)", previousDay: "Previous calendar day", nextDay: "Next calendar day",
      dailyDateError: "Choose a valid daily-model date inside its analysis year.",
      dailyNoData: "No matched observations on this day. No source estimates shown.",
      dailyInsufficient: "Insufficient data for a daily source fit. No source estimates shown.",
      dailyDescription: (day, n, exact, upper, minimum, exactMinimum) => `Independent daily slot ${day} (fixed GMT+1): ${n} matched sites, ${exact} exact results, ${upper} upper bounds. Screen: ${minimum} sites and ${exactMinimum} sites with exact results. This screen is NOT evidence of identifiability or confidence.`,
      dailyCaution: "Exploratory daily fit; samples need not be simultaneous. Purple scores use a fixed cross-day scale per version, NOT probability. Orange markers show uncensored readings within this day.",
      dailyCV: (n, daily, annual, offset) => `Same-day spatial holdout: ${n} results evaluated. Exact RMSE (mg N/L): daily ${daily}, annual ${annual}, daily constant-only ${offset}.`,
      dailyNoCV: "Independent spatial validation unavailable for this day: insufficient same-day training coverage or no exact held-out results.",
      dailyIncluded: "Sampled site used in this daily fit",
      dailyExcluded: "Not used in this daily fit",
      metricUnavailable: "not available",
      mapView: "Map view", strengthView: "Fitted source scores", stabilityView: "Bootstrap hotspot stability",
      stabilityTitle: "Hotspot selection frequency", stabilityScore: "Bootstrap selection frequency",
      stabilityRange: "2.5–97.5 bootstrap amplitude percentiles (mg N/L)",
      stabilityNote: "Site-resampling robustness, NOT probability of a real source. Grey: monitoring sites.",
      stabilityMissing: "Bootstrap estimates unavailable for this day. No substitute confidence layer.",
      stabilityValid: (valid, attempted, fraction) => `${valid}/${attempted} valid site-bootstrap draws; nominal top ${fraction}% candidate ranks, including ties. Not source probability.`,
      leafletError: "The local Leaflet library could not load. Re-run build_nitrogen_map.py and keep the vendor folder beside this page.",
      bootError: "Map initialization failed. See the browser console for details.",
      errors: {
        date: "Enter valid start and end dates.", order: "The start date must not follow the end date.",
        bounds: "Choose dates within the available observation period.", minimum: "Minimum samples must be a positive whole number.",
      },
    },
    nl: {
      title: "Stikstofkaart Amstel", badge: "ECHTE AGV-DATA", search: "Zoek meetlocatie: code, naam of plaats",
      filterTitle: "Stikstof en tijdvenster", pollutantLabel: "Stikstofparameter",
      startLabel: "Van (inclusief, GMT+1)", endLabel: "Tot (inclusief, GMT+1)", minimumLabel: "Minimumaantal monsters per locatie",
      allDates: "Alle data", recentDates: "Vanaf 2015", lastYear: "Laatste 12 maanden met data",
      cancel: "Annuleren", apply: "Filters toepassen", filters: "Filters", fit: "Zoom naar zichtbare locaties",
      methodTitle: "Data, interpretatie en privacy", reportLink: "Volledig rapport over de datavoorbereiding",
      coverage: (a, b) => `Beschikbare waarnemingen: ${a} tot ${b}. Geen interpolatie of aanvulling met nullen.`,
      status: (n, count, missing, low) => `${n} locaties zichtbaar | ${count} bruikbare parametermonsters | ${missing} locaties zonder data in dit tijdvenster | ${low} onder het minimumaantal`,
      empty: "Geen locaties voldoen aan deze filters. Wijzig de parameter, datums of het minimumaantal monsters.",
      median: "Mediaan", samples: "Bruikbare monsters", range: "Waargenomen bereik", observed: "Monsters binnen dit tijdvenster",
      insufficient: "Minder monsters dan vereist", noData: "Geen bruikbare metingen in dit tijdvenster",
      legend: "Mediane concentratie (mg N/L)", scale: "Vaste parameterschaal voor alle datums. Kleuren zijn geen wettelijke klassen. De hoogste kleur omvat waarden boven het schaalmaximum.",
      cap: "Schaalmaximum: 95e percentiel",
      method: "Alleen echte AGV-oppervlaktewatermonsters: kwaliteitscode 0, geldige datums, eindige niet-negatieve concentraties, geen ongelijkheden bij detectiegrenzen. Laboratoriumreplicaten zijn per monster en parameter samengevat met de mediaan. Alle tijdstippen worden op verzoek van de gebruiker als vaste GMT+1 (UTC+01:00, zonder zomertijd) behandeld. Kalenderdatums uit de bron blijven behouden. Begin- en einddatum tellen mee. Standaard minimaal vijf monsters per locatie. Locaties zonder data of onder het minimum zijn verborgen en tellen niet als nul. RD New is aangenomen en omgezet naar WGS84; ongeldige of dubbelzinnige locaties zijn uitgesloten. Kleuren gebruiken een vast 95e percentiel per parameter van alle bruikbare gekarteerde monsters. Het laatste jaar is onvolledig. Meetlocaties zijn geen voorspelde vervuilingsbronnen.",
      privacy: "Alle meetwaarden, filters en statistieken blijven lokaal in uw browser. Leaflet is lokaal opgeslagen. De grijze PDOK/Kadaster-achtergrondkaart uit het voorbeeld heeft internet nodig en ontvangt tegel- en kaartvensterverzoeken, maar geen meetwaarden, locatienamen of zoekopdrachten. Bij een tegelfout blijven de meetpunten zichtbaar met een waarschuwing. Geen analyseservices, geocodering of uploads van meetgegevens.",
      tileError: "Achtergrondkaart kon niet laden. De echte meetpunten blijven beschikbaar; controleer uw internetverbinding. Er is geen andere kaartaanbieder benaderd.",
      noResults: "Geen meetlocaties gevonden.",
      networkLabel: "Waterlopen en duikers", pumpLabel: "Gemalen", structureLabel: "Stuwen en dammen",
      clearRelations: "Wis gemarkeerde verbindingen", gisReportLink: "GIS-bronnen, verbindingen en aannames",
      gisScenario: (outlet, count, offset) => `AANGENOMEN UITLAATSCENARIO: ${outlet} | ${count} locaties verbonden in het geometrische netwerk | uitlaat op ${offset} m van de hartlijn. Geen gemeten stroming. Klik op een meetpunt voor verbindingen.`,
      networkTitle: "Aangenomen uitlaatverbindingen", snap: "Afstand tot hartlijn", review: "Handmatige controle aanbevolen",
      upstream: "Scenario bovenstrooms", downstream: "Scenario benedenstrooms", unresolved: "Richting onbepaald",
      notMatched: "Geen eenduidige koppeling aan een waterloop; geen stroomrichting afgeleid.",
      flowNote: "Blauw: naar de gekozen uitlaat. Paars: bovenstroomse buren. Pijlen zijn scenario-aannames, geen gemeten stroming. Doorlaatbaarheid is niet vastgesteld.",
      structureNote: "Kunstwerken nabij dit traject; bedrijfsstand onbekend.",
      more: n => `en nog ${n}`,
      modelLabel: "Afstandsmodel: kandidaatscores (paars, geen bevestigde bronnen)",
      modelWindow: "Gebruik nitraat en tijdvenster van model",
      modelDescription: (a, b) => `Vast model: ${a} tot ${b}, GMT+1. Paarse intensiteit/grootte = relatieve coefficient (0–1), GEEN kans of emissievracht. Geen stromingsrichting of waterverbindingen.`,
      modelMismatch: "Overlay verborgen: kies nitraat en exact het modeltijdvenster. Meetfilters berekenen het model niet opnieuw.",
      modelWeak: "WAARSCHUWING: geografische validatie verbetert de RMSE niet ten opzichte van een constant model. Bronlocaties zijn niet vastgesteld.",
      modelCandidate: "Kandidaat uit afstandsmodel", modelScore: "Relatieve score (0–1, geen kans)",
      modelAmplitude: "Kernelamplitude (mg N/L, geen emissiesnelheid)",
      modelKind: "Versie van afstandsmodel", modelEuclidean: "Basis: hemelsbrede afstand",
      modelNetwork: "Afstand via waterverbindingen",
      networkModelDescription: (a, b, n, excluded) => `Vast model: ${a} tot ${b}, GMT+1. Kortste ongerichte waternetwerkafstand; ${n} gekoppelde locaties gebruikt, ${excluded} basislocaties uitgesloten. Paars = relatieve coefficient, GEEN kans of emissievracht. Stromingsrichting en hydraulische passeerbaarheid zijn niet bevestigd. Oranje metingen omvatten nog alle locaties die aan de filters voldoen.`,
      networkComparison: (n, e, b) => `RMSE met gelijke validatieset (mg N/L): netwerk ${n}, hemelsbreed ${e}, constant ${b}.`,
      networkFitSite: "Gebruikt in model met waternetwerkafstand",
      networkExcludedSite: "Niet gebruikt in model met waternetwerkafstand (geen of onduidelijke netwerkkoppeling)",
      modelDailyEuclidean: "Dagelijks hemelsbreed (gekoppelde locaties)", modelDailyNetwork: "Dagelijkse waternetwerkafstand",
      dailyDateLabel: "Dag (GMT+1)", previousDay: "Vorige kalenderdag", nextDay: "Volgende kalenderdag",
      dailyDateError: "Kies een geldige modeldatum binnen het analysejaar.",
      dailyNoData: "Geen gekoppelde waarnemingen op deze dag. Geen bronschattingen getoond.",
      dailyInsufficient: "Onvoldoende data voor een dagelijkse bronfit. Geen bronschattingen getoond.",
      dailyDescription: (day, n, exact, upper, minimum, exactMinimum) => `Onafhankelijk dagvenster ${day} (vast GMT+1): ${n} gekoppelde locaties, ${exact} exacte resultaten, ${upper} bovengrenzen. Selectie: ${minimum} locaties en ${exactMinimum} locaties met exacte resultaten. Dit bewijst GEEN identificeerbaarheid of betrouwbaarheid.`,
      dailyCaution: "Verkennende dagfit; monsters zijn niet noodzakelijk gelijktijdig genomen. Paarse scores gebruiken een vaste schaal over alle dagen per versie, GEEN kans. Oranje punten tonen ongecensureerde metingen binnen deze dag.",
      dailyCV: (n, daily, annual, offset) => `Ruimtelijke validatie binnen dezelfde dag: ${n} resultaten. RMSE (mg N/L): dagelijks ${daily}, jaarlijks ${annual}, dagelijkse constante ${offset}.`,
      dailyNoCV: "Onafhankelijke ruimtelijke validatie ontbreekt voor deze dag: onvoldoende trainingsdekking of geen exacte validatiemetingen.",
      dailyIncluded: "Bemonsterde locatie gebruikt in deze dagfit",
      dailyExcluded: "Niet gebruikt in deze dagfit", metricUnavailable: "niet beschikbaar",
      mapView: "Kaartweergave", strengthView: "Geschatte bronscores", stabilityView: "Bootstrap-hotspotstabiliteit",
      stabilityTitle: "Hotspotselectiefrequentie", stabilityScore: "Selectiefrequentie in bootstrap",
      stabilityRange: "2.5–97.5 bootstrappercentielen van amplitude (mg N/L)",
      stabilityNote: "Robuustheid bij herhaalde locatiesteekproeven, GEEN kans op een echte bron. Grijs: meetlocaties.",
      stabilityMissing: "Geen bootstrapschattingen voor deze dag. Geen vervangende betrouwbaarheidslaag.",
      stabilityValid: (valid, attempted, fraction) => `${valid}/${attempted} geldige locatiesteekproeven; nominaal hoogste ${fraction}% kandidaatrangen, inclusief gelijke waarden. Geen bronkans.`,
      leafletError: "De lokale Leaflet-bibliotheek kon niet laden. Voer build_nitrogen_map.py opnieuw uit en bewaar de map vendor naast deze pagina.",
      bootError: "De kaart kon niet worden gestart. Zie de browserconsole voor details.",
      errors: {
        date: "Vul geldige begin- en einddatums in.", order: "De begindatum mag niet na de einddatum liggen.",
        bounds: "Kies datums binnen de beschikbare meetperiode.", minimum: "Het minimumaantal moet een positief geheel getal zijn.",
      },
    },
  };
  const $ = id => document.getElementById(id);
  let lang = "en", data, map, dots, legendElement, current, markers = new Map(), tileFailed = false;
  let state, selectedRoutes, distanceLayer, modelKind = "distance", modelDay, modelView = "strength";
  const t = () => STR[lang];
  const number = value => new Intl.NumberFormat(lang === "nl" ? "nl-NL" : "en-GB", { maximumSignificantDigits: 4 }).format(value);
  const pollutantName = () => data.pollutants[state.parameter].name[lang];
  const selectedDistanceModel = () => resolveDailyModel(availableDistanceModels(data)[modelKind], modelDay);
  const describeDistanceModel = model => model.isDaily
    ? t().dailyDescription(model.start, model.siteCount, model.exactCount, model.upperBoundCount,
      model.minimumSites, model.minimumExactSites)
    : modelKind === "network"
      ? t().networkModelDescription(model.start, model.end, model.siteCount, model.excludedSiteCount)
      : t().modelDescription(model.start, model.end);
  function useModelWindow() {
    const model = selectedDistanceModel();
    state = { ...state, parameter: model.parameter, start: model.start, end: model.end,
      minimum: model.isDaily ? 1 : state.minimum };
    $("modelToggle").checked = true;
    setDraft();
    redraw();
  }
  function changeModelDay(date) {
    if (!data.dailyModels.days[date]) { showMessage(t().dailyDateError, true); $("modelDay").value = modelDay; return; }
    modelDay = date;
    useModelWindow();
  }
  const zoomHandlers = ["touchZoom", "doubleClickZoom", "scrollWheelZoom", "boxZoom", "keyboard"];
  function showMessage(message, error = false) {
    $("message").textContent = message;
    $("message").classList.toggle("error", error);
  }
  function networkPopup(site) {
    const network = site.network;
    if (!network) return "";
    if (network.status !== "matched") return `<div class="network-info"><b>${t().networkTitle}</b><p>${t().notMatched}</p></div>`;
    const describe = relation => {
      const links = network.links.filter(link => link.relation === relation).sort((a, b) => a.distance - b.distance);
      return links.slice(0, 6).map(link => `${escapeHTML(link.to)} (${number(link.distance)} m)`).join(", ")
        + (links.length > 6 ? `; ${t().more(links.length - 6)}` : "") || "-";
    };
    const unresolved = network.links.filter(link => link.relation === "connected_direction_unresolved").length;
    return `<div class="network-info"><b>${t().networkTitle}: ${escapeHTML(data.gis.outlet)}</b>`
      + `<p>${t().snap}: ${number(network.snapDistance)} m${network.reviewRecommended ? `<br><b>${t().review}</b>` : ""}</p>`
      + `<p>${t().upstream}: ${describe("scenario_upstream")}<br>${t().downstream}: ${describe("scenario_downstream")}`
      + `<br>${t().unresolved}: ${unresolved}</p><p class="sub">${t().flowNote}</p></div>`;
  }
  function highlightSite(site) {
    if (!data.gis || !selectedRoutes) return;
    selectedRoutes.clearLayers();
    for (const feature of data.gis.routes.features) {
      const properties = feature.properties;
      if (properties.from_location !== site.code && properties.to_location !== site.code) continue;
      const color = properties.from_location === site.code ? "#0284c7" : "#7c3aed";
      const coordinates = feature.geometry.coordinates;
      const label = `${properties.from_location} \u2192 ${properties.to_location}: ${number(properties.network_distance_m)} m`
        + (properties.nearby_hydraulic_structure_codes.length ? ` | ${t().structureNote}` : "");
      root.L.polyline(coordinates.map(point => [point[1], point[0]]), { color, weight: 4, opacity: .85 })
        .bindTooltip(escapeHTML(label)).addTo(selectedRoutes);
      const index = Math.max(1, Math.floor(coordinates.length / 2));
      const a = coordinates[index - 1], b = coordinates[index];
      const angle = -Math.atan2(b[1] - a[1], (b[0] - a[0]) * Math.cos(b[1] * Math.PI / 180)) * 180 / Math.PI;
      root.L.marker([b[1], b[0]], {
        interactive: false,
        icon: root.L.divIcon({ className: "scenario-arrow", iconSize: [18, 18], iconAnchor: [9, 9],
          html: `<span style="display:block;color:${color};transform:rotate(${angle}deg)">&#9654;</span>` }),
      }).addTo(selectedRoutes);
    }
  }
  function initGIS() {
    if (!data.gis) return;
    $("gisControls").hidden = false;
    $("gisReport").hidden = false;
    selectedRoutes = root.L.layerGroup().addTo(map);
    const watercourses = root.L.geoJSON(data.gis.watercourses, {
      interactive: false, style: { color: "#0ea5e9", weight: 1.5, opacity: .5 },
    }).addTo(map);
    const pumps = root.L.layerGroup(), barriers = root.L.layerGroup();
    for (const feature of data.gis.structures.features) {
      const properties = feature.properties, point = feature.geometry.coordinates;
      const pump = properties.structure_type === "pumps";
      root.L.circleMarker([point[1], point[0]], {
        radius: pump ? 4 : 3, color: pump ? "#0369a1" : "#991b1b", weight: 1.5,
        fillColor: pump ? "#e0f2fe" : "#fee2e2", fillOpacity: 1,
      }).bindTooltip(`${escapeHTML(properties.asset_code)} (${escapeHTML(properties.structure_type)})`)
        .addTo(pump ? pumps : barriers);
    }
    pumps.addTo(map);
    for (const [id, layer] of [["networkToggle", watercourses], ["pumpToggle", pumps], ["structureToggle", barriers]]) {
      $(id).addEventListener("change", () => $(id).checked ? layer.addTo(map) : map.removeLayer(layer));
    }
    $("clearRelations").addEventListener("click", () => selectedRoutes.clearLayers());
  }
  function initDistanceModel() {
    const models = availableDistanceModels(data);
    if (!Object.keys(models).length) return;
    if (!models[modelKind]) modelKind = Object.keys(models)[0];
    $("modelControls").hidden = false;
    for (const kind of Object.keys(models)) {
      const option = document.createElement("option");
      option.value = kind;
      $("modelKind").appendChild(option);
    }
    $("modelKind").value = modelKind;
    map.createPane("distanceCandidates").style.zIndex = "390";
    distanceLayer = root.L.layerGroup().addTo(map);
    $("modelToggle").checked = new URLSearchParams(root.location.search).get("model") === modelKind;
    $("modelKind").addEventListener("change", () => {
      const previousWasDaily = !!selectedDistanceModel().isDaily;
      modelKind = $("modelKind").value;
      if (previousWasDaily || selectedDistanceModel().isDaily) useModelWindow();
      else redraw();
    });
    $("modelToggle").addEventListener("change", renderDistanceModel);
    $("modelView").value = modelView;
    $("modelView").addEventListener("change", () => { modelView = $("modelView").value; redraw(); });
    $("modelWindow").addEventListener("click", useModelWindow);
    if (data.dailyModels) {
      $("modelDay").min = data.dailyModels.start;
      $("modelDay").max = data.dailyModels.end;
      $("modelDay").addEventListener("change", () => changeModelDay($("modelDay").value));
      for (const [id, step] of [["previousDay", -1], ["nextDay", 1]]) {
        $(id).addEventListener("click", () => {
          const next = adjacentModelDay(modelDay, step, data.dailyModels.start, data.dailyModels.end);
          if (next !== null) changeModelDay(next);
        });
      }
    }
  }
  function renderDistanceModel() {
    if (!distanceLayer) return;
    distanceLayer.clearLayers();
    const model = selectedDistanceModel(), matches = modelMatchesWindow(model, state);
    const text = lang === "nl" ? STR.nl : STR.en;
    if (!model.isDaily) modelView = "strength";
    $("modelView").value = modelView;
    $("modelView").disabled = !model.isDaily;
    $("modelView").setAttribute("aria-label", text.mapView);
    $("modelView").options[0].textContent = text.strengthView;
    $("modelView").options[1].textContent = text.stabilityView;
    $("modelKind").setAttribute("aria-label", text.modelKind);
    const names = { distance: text.modelEuclidean, network: text.modelNetwork,
      "daily-distance": text.modelDailyEuclidean, "daily-network": text.modelDailyNetwork };
    for (const option of $("modelKind").options) {
      option.textContent = names[option.value];
    }
    $("modelLabel").textContent = text.modelLabel;
    $("modelWindow").textContent = text.modelWindow;
    $("dailyControls").hidden = !model.isDaily;
    let dailyStatus = "";
    if (model.isDaily) {
      $("modelDay").value = modelDay;
      $("dailyDateLabel").textContent = text.dailyDateLabel;
      $("previousDay").setAttribute("aria-label", text.previousDay);
      $("nextDay").setAttribute("aria-label", text.nextDay);
      $("previousDay").disabled = modelDay === data.dailyModels.start;
      $("nextDay").disabled = modelDay === data.dailyModels.end;
      if (model.status === "no_data") dailyStatus = text.dailyNoData;
      else if (model.status !== "fitted") dailyStatus = text.dailyInsufficient;
      else {
        const validation = model.validation;
        const metric = value => value === null ? text.metricUnavailable : number(value);
        dailyStatus = text.dailyCaution + " " + (validation && validation["daily_" + model.dailyMetric].exact_count
          ? text.dailyCV(model.cvObservationCount, metric(validation["daily_" + model.dailyMetric].exact_rmse_mg_n_l),
            metric(validation["annual_" + model.dailyMetric].exact_rmse_mg_n_l),
            metric(validation.daily_offset.exact_rmse_mg_n_l)) : text.dailyNoCV);
      }
    }
    $("modelStatus").textContent = describeDistanceModel(model) + (dailyStatus ? " " + dailyStatus : "")
      + (modelKind === "network" ? " " + text.networkComparison(
        number(model.comparison.network), number(model.comparison.euclidean_same_support),
        number(model.comparison.offset_only)) : "")
      + (!matches ? " " + text.modelMismatch : "") + (!model.isDaily && !model.validationImproved ? " " + text.modelWeak : "");
    const stability = data.dailyStability && model.isDaily ? data.dailyStability.days[model.start] : null;
    const stabilityStatus = stability && stability.status === "available"
      ? text.stabilityValid(stability.validReplicates, stability.attemptedReplicates,
        number(100 * data.dailyStability.hotspotFraction)) : text.stabilityMissing;
    if (modelView === "stability") $("modelStatus").textContent += " " + stabilityStatus;
    if (document.body.classList.contains("embedded") && model.isDaily) {
      $("modelStatus").textContent = `${model.start} | ${model.siteCount} matched sites | `
        + (model.status === "fitted" ? (modelView === "stability" ? stabilityStatus : text.strengthView)
          : model.status === "no_data" ? text.dailyNoData : text.dailyInsufficient);
    }
    if (!$("modelToggle").checked || !matches) return;
    const features = modelView === "stability" ? bootstrapFeatures(model, data.dailyStability) : model.sources.features;
    for (const feature of features) {
      const p = feature.properties, point = feature.geometry.coordinates;
      const score = modelView === "stability" ? p.selectionFrequency : p.relative_score;
      const extra = modelView === "stability"
        ? `<p>${text.stabilityScore}: ${number(p.selectionFrequency)}<br>`
          + `${text.stabilityRange}: ${number(p.coefficientP025)} &ndash; ${number(p.coefficientP975)}</p>`
          + `<p>${stabilityStatus}<br>${text.stabilityNote}</p>`
        : `<p>${text.modelScore}: ${number(p.relative_score)}<br>`
          + `${text.modelAmplitude}: ${number(p.coefficient_mg_n_l)}</p>`;
      root.L.circleMarker([point[1], point[0]], {
        radius: 3 + 7 * score, color: modelView === "stability" ? "#155e75" : "#5b21b6",
        weight: 1, pane: "distanceCandidates",
        fillColor: modelView === "stability" ? stabilityColor(score) : "#7c3aed",
        fillOpacity: modelView === "stability" ? .35 + .6 * score : .1 + .75 * score,
      }).bindPopup(`<b>${text.modelCandidate}: ${escapeHTML(p.candidate_id)}</b>`
        + extra
        + `<p>${describeDistanceModel(model)}</p>`)
        .addTo(distanceLayer);
    }
  }
  function popup(site, stats) {
    const name = escapeHTML(site.name), code = escapeHTML(site.code);
    const model = selectedDistanceModel();
    let modelNote = "";
    if (model && $("modelToggle").checked && modelMatchesWindow(model, state)) {
      if (model.isDaily) {
        modelNote = `<p>${model.status === "fitted"
          ? (model.includedSites.includes(site.code) ? t().dailyIncluded : t().dailyExcluded)
          : model.status === "no_data" ? t().dailyNoData : t().dailyInsufficient}</p>`;
      } else if (modelKind === "network") {
        modelNote = `<p>${model.includedSites.includes(site.code) ? t().networkFitSite : t().networkExcludedSite}</p>`;
      }
    }
    if (!stats || stats.n < state.minimum) {
      return `<b>${name}</b><br>${code}<p>${stats ? t().insufficient : t().noData}</p>`
        + `<span class="sub">${state.start} &ndash; ${state.end}</span>${modelNote}${networkPopup(site)}`;
    }
    const cap = data.pollutants[state.parameter].colorCap;
    const width = cap > 0 ? Math.min(100, stats.median / cap * 100) : 0;
    return `<b>${name}</b><br><span class="sub">${code}</span>`
      + `<p>${escapeHTML(pollutantName())}</p><div class="reading">${t().median}: <b>${number(stats.median)} mg N/L</b></div>`
      + `<div class="reading-bar" role="presentation"><span style="width:${width}%"></span></div>`
      + `<p>${t().samples}: <b>${stats.n}</b><br>${t().range}: ${number(stats.min)} &ndash; ${number(stats.max)} mg N/L`
      + `<br>${t().observed}: ${dayISO(stats.first)} &ndash; ${dayISO(stats.last)}</p>`
      + `<span class="sub">${state.start} &ndash; ${state.end}<br>WFD: ${escapeHTML(site.wfd || "-")} &middot; EAG: ${escapeHTML(site.eag || "-")}</span>${modelNote}${networkPopup(site)}`;
  }
  function renderLegend() {
    if (modelView === "stability") {
      legendElement.innerHTML = `<b>${t().stabilityTitle}</b>`
        + STABILITY_COLORS.map((color, i) => `<div><i style="background:${color}"></i>`
          + `${number(i / 5)} &ndash; ${number((i + 1) / 5)}</div>`).join("")
        + `<div class="note">${t().stabilityNote}</div>`;
      return;
    }
    const cap = data.pollutants[state.parameter].colorCap;
    legendElement.innerHTML = `<b>${escapeHTML(pollutantName())}</b><b>${t().legend}</b>`
      + COLORS.map((color, i) => `<div><i style="background:${color}"></i>`
        + (cap <= 0 ? (i === 0 ? "0" : "-") : i === 3 ? `&ge; ${number(cap * .75)}` : `${number(cap * i / 4)} &ndash; &lt; ${number(cap * (i + 1) / 4)}`) + "</div>").join("")
      + `<div class="note">${t().cap}: ${number(cap)} mg N/L<br>${t().scale}</div>`;
  }
  function redraw() {
    map.closePopup();
    if (selectedRoutes) selectedRoutes.clearLayers();
    dots.clearLayers();
    markers = new Map();
    renderDistanceModel();
    current = windowSummary(data.sites, state.parameter, isoDay(state.start), isoDay(state.end), state.minimum);
    for (const { site, stats } of current.visible) {
      const marker = root.L.circleMarker([site.lat, site.lon], {
        radius: modelView === "stability" ? 3 : 5 + Math.min(5, Math.sqrt(stats.n) / 2),
        color: "#fff", weight: 1.4,
        fillColor: modelView === "stability" ? "#475569" : colorFor(stats.median, data.pollutants[state.parameter].colorCap),
        fillOpacity: .95,
      }).bindPopup(() => popup(site, stats)).addTo(dots);
      marker.bindTooltip(`${escapeHTML(site.code)}: ${number(stats.median)} mg N/L`);
      marker.on("click", () => highlightSite(site));
      markers.set(site.code, marker);
    }
    $("status").textContent = t().status(current.visible.length, current.sampleCount, current.noData, current.insufficient);
    $("crumb").textContent = `${pollutantName()} | ${state.start} \u2013 ${state.end} | \u2265 ${state.minimum}`;
    $("map").dataset.visibleSites = String(current.visible.length);
    $("map").dataset.sampleCount = String(current.sampleCount);
    showMessage(tileFailed ? t().tileError : current.visible.length ? "" : t().empty);
    renderLegend();
  }
  function fitVisible() {
    const sites = current.visible.length ? current.visible.map(item => item.site) : data.sites;
    map.fitBounds(sites.map(site => [site.lat, site.lon]), { padding: [30, 30], maxZoom: 12 });
  }
  function setDraft() {
    $("pollutant").value = state.parameter;
    $("start").value = state.start;
    $("end").value = state.end;
    $("minimum").value = state.minimum;
    $("filterError").textContent = "";
  }
  function closeFilter() {
    $("filterPop").hidden = true;
    $("filterBtn").setAttribute("aria-expanded", "false");
    $("map").classList.remove("locked");
    zoomHandlers.forEach(handler => map[handler].enable());
  }
  function openFilter() {
    setDraft();
    $("filterPop").hidden = false;
    $("filterBtn").setAttribute("aria-expanded", "true");
    map.closePopup();
    $("map").classList.add("locked");
    zoomHandlers.forEach(handler => map[handler].disable());
    $("pollutant").focus();
  }
  function renderSearch() {
    const matches = searchSites(data.sites, $("q").value);
    $("list").replaceChildren();
    if ($("q").value.trim() && !matches.length) {
      const empty = document.createElement("li");
      empty.textContent = t().noResults;
      empty.style.padding = "10px";
      $("list").appendChild(empty);
    }
    for (const site of matches) {
      const li = document.createElement("li"), button = document.createElement("button");
      button.type = "button";
      button.textContent = site.name;
      const small = document.createElement("small");
      small.textContent = site.code;
      button.appendChild(small);
      button.addEventListener("click", () => {
        closeFilter();
        $("q").value = site.name;
        $("list").replaceChildren();
        map.setView([site.lat, site.lon], 13);
        const marker = markers.get(site.code);
        if (marker) marker.openPopup();
        else root.L.popup().setLatLng([site.lat, site.lon]).setContent(
          popup(site, siteStats(site, state.parameter, isoDay(state.start), isoDay(state.end))),
        ).openOn(map);
        highlightSite(site);
      });
      li.appendChild(button);
      $("list").appendChild(li);
    }
  }
  function applyLanguage() {
    document.documentElement.lang = lang;
    document.title = t().title;
    for (const id of ["title", "badge", "filterTitle", "pollutantLabel", "startLabel", "endLabel",
      "minimumLabel", "allDates", "recentDates", "lastYear", "cancel", "apply", "methodTitle",
      "method", "privacy", "reportLink", "networkLabel", "pumpLabel", "structureLabel",
      "clearRelations", "gisReportLink"]) $(id).textContent = t()[id];
    if (data.gis) $("gisScenario").textContent = t().gisScenario(data.gis.outlet, data.gis.connectedSites, number(data.gis.outletSnapDistance));
    $("q").placeholder = t().search;
    $("q").setAttribute("aria-label", t().search);
    $("filterBtn").setAttribute("aria-label", t().filters);
    $("fit").textContent = t().fit;
    $("coverage").textContent = t().coverage(data.minDate, data.maxDate);
    const draft = $("pollutant").value;
    $("pollutant").replaceChildren();
    for (const [parameter, definition] of Object.entries(data.pollutants)) {
      const option = document.createElement("option");
      option.value = parameter;
      option.textContent = definition.name[lang];
      $("pollutant").appendChild(option);
    }
    $("pollutant").value = draft || state.parameter;
    document.querySelectorAll("[data-lang]").forEach(button => button.setAttribute("aria-pressed", String(button.dataset.lang === lang)));
    $("filterError").textContent = "";
    redraw();
  }
  function boot() {
    data = JSON.parse($("nitrogen-data").textContent);
    if (!root.L) { showMessage(t().leafletError, true); return; }
    state = { parameter: "Ntot_mgN/l", start: data.defaultStart, end: data.maxDate, minimum: 5 };
    const query = new URLSearchParams(root.location.search);
    document.body.classList.toggle("embedded", query.get("embedded") === "1");
    modelView = query.get("view") === "stability" ? "stability" : "strength";
    modelDay = data.dailyModels ? (query.get("day") || data.dailyModels.defaultDate) : null;
    if (data.dailyModels && !data.dailyModels.days[modelDay]) {
      throw new Error("Requested daily-model date is outside the available calendar.");
    }
    const requestedModel = query.get("model");
    const definition = availableDistanceModels(data)[requestedModel];
    if (["distance", "network", "daily-distance", "daily-network"].includes(requestedModel) && !definition) {
      throw new Error("Requested distance model is not embedded; rebuild the model and map.");
    }
    const model = resolveDailyModel(definition, modelDay);
    if (model) {
      modelKind = requestedModel;
      state = { ...state, parameter: model.parameter, start: model.start, end: model.end,
        minimum: model.isDaily ? 1 : state.minimum };
    }
    map = root.L.map("map", { zoomSnap: .5, preferCanvas: true }).setView([52.3, 4.9], 10);
    const tiles = root.L.tileLayer("https://service.pdok.nl/brt/achtergrondkaart/wmts/v2_0/grijs/EPSG:3857/{z}/{x}/{y}.png", {
      attribution: 'Kaartgegevens &copy; <a href="https://www.kadaster.nl">Kadaster</a>',
      minZoom: 6, maxZoom: 19,
    }).addTo(map);
    tiles.on("tileerror", () => { tileFailed = true; showMessage(t().tileError); });
    dots = root.L.layerGroup().addTo(map);
    initGIS();
    initDistanceModel();
    const legend = root.L.control({ position: "bottomright" });
    legend.onAdd = () => (legendElement = root.L.DomUtil.create("div", "legend"));
    legend.addTo(map);
    const fit = root.L.control({ position: "topleft" });
    fit.onAdd = () => {
      const box = root.L.DomUtil.create("div", "leaflet-bar");
      const button = root.L.DomUtil.create("button", "", box);
      button.type = "button";
      button.id = "fit";
      button.addEventListener("click", fitVisible);
      root.L.DomEvent.disableClickPropagation(box);
      return box;
    };
    fit.addTo(map);
    if (query.get("embedded") === "1") {
      root.addEventListener("message", event => {
        if (event.source !== root.parent || !event.data || event.data.type !== "nitrogen-report-filter") return;
        const message = event.data;
        if (!["daily-network", "daily-distance"].includes(message.model)
            || !data.dailyModels.days[message.day] || !["strength", "stability"].includes(message.view)) {
          showMessage(t().dailyDateError, true);
          return;
        }
        modelKind = message.model;
        modelDay = message.day;
        modelView = message.view;
        $("modelKind").value = modelKind;
        useModelWindow();
        fitVisible();
      });
    }
    for (const id of ["start", "end"]) { $(id).min = data.minDate; $(id).max = data.maxDate; }
    $("filterBtn").addEventListener("click", () => $("filterPop").hidden ? openFilter() : closeFilter());
    $("cancel").addEventListener("click", () => { closeFilter(); $("filterBtn").focus(); });
    $("filters").addEventListener("submit", event => {
      event.preventDefault();
      const minimum = Number($("minimum").value);
      const error = validateWindow($("start").value, $("end").value, minimum, data.minDate, data.maxDate);
      if (error) { $("filterError").textContent = t().errors[error]; return; }
      state = { parameter: $("pollutant").value, start: $("start").value, end: $("end").value, minimum };
      if (availableDistanceModels(data)[modelKind] && availableDistanceModels(data)[modelKind].dailyMetric
          && state.start === state.end && data.dailyModels.days[state.start]) modelDay = state.start;
      redraw();
      closeFilter();
      $("filterBtn").focus();
    });
    $("allDates").addEventListener("click", () => { $("start").value = data.minDate; $("end").value = data.maxDate; });
    $("recentDates").addEventListener("click", () => { $("start").value = data.defaultStart; $("end").value = data.maxDate; });
    $("lastYear").addEventListener("click", () => {
      const end = new Date(data.maxDate + "T00:00:00Z"), year = end.getUTCFullYear() - 1;
      const month = end.getUTCMonth(), day = end.getUTCDate();
      const anniversary = new Date(Date.UTC(year, month, day));
      if (anniversary.getUTCMonth() !== month) anniversary.setUTCDate(0);
      $("start").value = dayISO(Math.max(isoDay(data.minDate), anniversary.getTime() / DAY + 1));
      $("end").value = data.maxDate;
    });
    $("q").addEventListener("input", renderSearch);
    $("q").addEventListener("keydown", event => {
      if (event.key === "Escape") $("list").replaceChildren();
      if (event.key === "ArrowDown" || event.key === "Enter") {
        const first = $("list").querySelector("button");
        if (first) { event.preventDefault(); event.key === "Enter" ? first.click() : first.focus(); }
      }
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape" && !$("filterPop").hidden) { closeFilter(); $("filterBtn").focus(); }
    });
    document.addEventListener("click", event => {
      if (!event.target.closest(".searchbar")) {
        $("list").replaceChildren();
        if (!$("filterPop").hidden) closeFilter();
      }
    });
    document.querySelectorAll("[data-lang]").forEach(button => button.addEventListener("click", () => {
      lang = button.dataset.lang;
      applyLanguage();
    }));
    setDraft();
    applyLanguage();
    fitVisible();
  }
  try { boot(); }
  catch (error) { console.error("Nitrogen map initialization failed", error); showMessage(t().bootError, true); }
})(typeof globalThis !== "undefined" ? globalThis : this);
