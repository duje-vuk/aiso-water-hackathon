import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from build_nitrogen_map import build_payload, load_daily_models, load_daily_stability, load_distance_model, write_map
from prepare_nitrogen import NITROGEN


class MapBuildTests(unittest.TestCase):
    def samples(self):
        frame = pd.DataFrame({
            "sample_id": ["s1", "s2", "s3"],
            "location_code": ["A", "A", "B"],
            "date_time": ["2020-01-01 01:00:00", "2020-01-31 23:59:59", "2020-02-01 12:00:00"],
            "compartment": "OW",
            **{parameter: [np.nan, np.nan, np.nan] for parameter in NITROGEN},
        })
        frame["Ntot_mgN/l"] = [2., 4., 10.]
        return frame

    def locations(self):
        return pd.DataFrame({
            "location_code": ["A", "B"], "location_name": ["Real site", "Ambiguous site"],
            "valid_rd_coordinate": [True, True], "metadata_variant_count": [1, 2],
            "latitude": [52.3, 52.4], "longitude": [4.9, 5.0],
            "wfd_water_type": ["M6b", "M6b"], "ecological_analysis_area": ["EAG1", "EAG2"],
        })

    def test_exact_dates_values_and_excluded_coordinates(self):
        payload = build_payload(self.samples(), self.locations())
        self.assertEqual(len(payload["pollutants"]), 7)
        self.assertEqual(payload["minDate"], "2020-01-01")
        self.assertEqual(payload["maxDate"], "2020-01-31")
        self.assertEqual(payload["meta"]["sampleRowsExcludedForCoordinates"], 1)
        self.assertEqual(payload["meta"]["analyteSampleCount"], 2)
        self.assertEqual(payload["sites"][0]["observations"]["Ntot_mgN/l"], [[18262, 2.], [18292, 4.]])
        self.assertAlmostEqual(payload["pollutants"]["Ntot_mgN/l"]["colorCap"], 3.9)
        json.dumps(payload, allow_nan=False)

    def test_rejects_duplicate_samples_invalid_values_and_invalid_dates(self):
        samples = self.samples()
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            build_payload(pd.concat([samples, samples.iloc[[0]]]), self.locations())
        samples.loc[0, "Ntot_mgN/l"] = np.inf
        with self.assertRaisesRegex(ValueError, "Invalid eligible"):
            build_payload(samples, self.locations())
        samples = self.samples()
        samples.loc[0, "date_time"] = ""
        with self.assertRaisesRegex(ValueError, "valid date"):
            build_payload(samples, self.locations())

    def test_calendar_day_is_preserved_in_fixed_gmt_plus_one(self):
        samples = self.samples()
        samples["date_time"] = ["2020-01-01 00:01:00+01:00", "2020-01-31 23:59:59+01:00",
                                "2020-02-01 12:00:00+01:00"]
        payload = build_payload(samples, self.locations())
        self.assertEqual(payload["minDate"], "2020-01-01")
        self.assertEqual(payload["sites"][0]["observations"]["Ntot_mgN/l"][0][0], 18262)
        self.assertEqual(payload["meta"]["timeZone"], "UTC+01:00")

    def test_html_embeds_data_without_executable_place_names(self):
        locations = self.locations()
        locations.loc[0, "location_name"] = "</script><script>alert('not executable')</script>"
        payload = build_payload(self.samples(), locations)
        with tempfile.TemporaryDirectory() as directory:
            with patch("build_nitrogen_map.ensure_leaflet"):
                target = write_map(payload, Path(directory))
            document = target.read_text(encoding="utf-8")
            self.assertNotIn("__NITROGEN_DATA__", document)
            self.assertNotIn("__NITROGEN_SCRIPT__", document)
            self.assertNotIn("<script>alert('not executable')", document)
            self.assertIn("\\u003c/script\\u003e", document)
            self.assertEqual(json.loads((Path(directory) / "nitrogen_map_data.json").read_text())["meta"]["analyteSampleCount"], 2)

    def test_distance_overlay_is_optional_and_validates_scores(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "model_map.json"
            payload = {}
            load_distance_model(path, payload)
            self.assertNotIn("distanceModel", payload)
            model = {
                "start": "2024-01-01", "end": "2024-12-31", "parameter": "NO3_mgN/l_nf",
                "sources": {"type": "FeatureCollection", "features": [{
                    "geometry": {"type": "Point", "coordinates": [4.9, 52.3]},
                    "properties": {"relative_score": .5, "coefficient_mg_n_l": .2},
                }]},
            }
            path.write_text(json.dumps(model))
            load_distance_model(path, payload)
            self.assertEqual(payload["distanceModel"], model)
            network = {**model, "metric": "network", "includedSites": ["A"], "siteCount": 1,
                       "excludedSiteCount": 1,
                       "comparison": {"network": .6, "euclidean_same_support": .7, "offset_only": .5}}
            path.write_text(json.dumps(network))
            load_distance_model(path, payload, "connectivityModel")
            self.assertEqual(payload["connectivityModel"], network)
            self.assertIn("distanceModel", payload)
            path.write_text(json.dumps(model))
            with self.assertRaisesRegex(ValueError, "network coverage"):
                load_distance_model(path, {}, "connectivityModel")
            model["sources"]["features"][0]["properties"]["relative_score"] = 1.5
            path.write_text(json.dumps(model))
            with self.assertRaisesRegex(ValueError, "invalid coordinates or candidate scores"):
                load_distance_model(path, {})

    def test_daily_overlay_validates_calendar_support_and_source_arrays(self):
        model = {
            "parameter": "NO3_mgN/l_nf", "start": "2024-01-01", "end": "2024-01-01",
            "defaultDate": "2024-01-01", "minimumSites": 3, "minimumExactSites": 2,
            "normalizationMaxima": {"network": 1., "euclidean": 1.},
            "candidates": {"type": "FeatureCollection", "features": [{
                "geometry": {"type": "Point", "coordinates": [4.9, 52.3]},
                "properties": {"candidate_id": "N1"},
            }]},
            "days": {"2024-01-01": {
                "date": "2024-01-01", "status": "fitted", "siteCount": 3, "exactSiteCount": 2,
                "sampleCount": 3, "exactCount": 2, "upperBoundCount": 1,
                "includedSites": ["A", "B", "C"],
                "fits": {metric: {"coefficients": [.5], "offset_mg_n_l": .1}
                         for metric in ["network", "euclidean"]},
            }},
        }
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "daily.json"
            payload = {}
            load_daily_models(path, payload)
            self.assertNotIn("dailyModels", payload)
            path.write_text(json.dumps(model))
            load_daily_models(path, payload)
            self.assertEqual(payload["dailyModels"], model)
            model["days"]["2024-01-01"]["fits"]["network"]["coefficients"] = [2.]
            path.write_text(json.dumps(model))
            with self.assertRaisesRegex(ValueError, "normalization"):
                load_daily_models(path, {})
            model["days"]["2024-01-01"]["fits"]["network"]["coefficients"] = [.5]
            model["end"] = "2024-01-02"
            path.write_text(json.dumps(model))
            with self.assertRaisesRegex(ValueError, "every calendar day"):
                load_daily_models(path, {})

    def test_bootstrap_overlay_checks_input_hashes_and_probability_ranges(self):
        import hashlib
        daily = {
            "start": "2024-01-01", "end": "2024-01-01",
            "candidates": {"features": [{"properties": {"candidate_id": "N1"}}]},
            "days": {"2024-01-01": {"status": "fitted"}},
        }
        with tempfile.TemporaryDirectory() as directory:
            path, daily_path = Path(directory) / "stability.json", Path(directory) / "model_map.json"
            observations = Path(directory) / "observations_with_predictions.csv"
            daily_path.write_text(json.dumps(daily))
            observations.write_text("test-snapshot")
            model = {
                "start": daily["start"], "end": daily["end"], "candidateIds": ["N1"],
                "replicates": 20, "hotspotFraction": .1,
                "dailyModelMapSha256": hashlib.sha256(daily_path.read_bytes()).hexdigest(),
                "dailyObservationsSha256": hashlib.sha256(observations.read_bytes()).hexdigest(),
                "days": {"2024-01-01": {
                    "status": "available", "attemptedReplicates": 20, "validReplicates": 20,
                    "models": {metric: {"selectionFrequency": [.8], "coefficientP025": [.1],
                                       "coefficientMedian": [.2], "coefficientP975": [.3]}
                               for metric in ["network", "euclidean"]},
                }},
            }
            path.write_text(json.dumps(model))
            payload = {"dailyModels": daily}
            load_daily_stability(path, daily_path, payload)
            self.assertEqual(payload["dailyStability"], model)
            observations.write_text("changed")
            with self.assertRaisesRegex(ValueError, "Stale bootstrap"):
                load_daily_stability(path, daily_path, payload)
            observations.write_text("test-snapshot")
            model["days"]["2024-01-01"]["models"]["network"]["selectionFrequency"] = [1.1]
            path.write_text(json.dumps(model))
            with self.assertRaisesRegex(ValueError, "frequencies"):
                load_daily_stability(path, daily_path, payload)


if __name__ == "__main__":
    unittest.main()
