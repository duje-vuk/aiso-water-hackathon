"""Prepare AGV nitrogen evidence without altering source files.

Run with the conda play interpreter; see scripts/README.md.
"""
from __future__ import annotations

import argparse
import base64
import csv
import html
import json
from datetime import timedelta, timezone
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from pyproj import Transformer


ROOT = Path(__file__).resolve().parents[1]
GMT_PLUS_ONE = timezone(timedelta(hours=1), name="GMT+1")
CHEMISTRY = "FYCHEM_alleParamtrs_alleJaren_Amstelland_1900tmjuni.csv"
BIOLOGY = "HB_alleKwalelementen_alleJaren_Amstelland.csv"
NITROGEN = {
    "Ntot_mgN/l": "total nitrogen",
    "NKj_mgN/l": "Kjeldahl nitrogen",
    "NO3_mgN/l_nf": "nitrate (filtered)",
    "NO2_mgN/l_nf": "nitrite (filtered)",
    "NH4_mgN/l_nf": "ammonium (filtered)",
    "NH3_mgN/l_nf": "ammonia (filtered)",
    "sNO3NO2_mgN/l_nf": "nitrate + nitrite (filtered)",
}
CONTEXT = {
    "T_oC": "water temperature",
    "pH": "pH",
    "O2_mg/l": "dissolved oxygen",
    "O2_%": "oxygen saturation",
    "Cl_mg/l": "chloride",
    "Cl_mg/l_nf": "chloride (filtered)",
    "GELDHD_mS/m_20oC": "electrical conductivity at 20 deg C",
    "GELDHD_mS/m_25oC": "electrical conductivity at 25 deg C",
    "Ptot_mgP/l": "total phosphorus",
    "Ptot_mgP/l_nf": "phosphorus (filtered)",
    "PO4_mgP/l": "orthophosphate",
    "PO4_mgP/l_nf": "orthophosphate (filtered)",
    "CHLFa_ug/l": "chlorophyll-a",
}
BIO_NAMES = {
    "MEA_n": "macroinvertebrate count",
    "DTA_n": "diatom count",
    "FPA_n": "phytoplankton count",
    "FPA_n/ml": "phytoplankton concentration",
    "ZICHT_m": "water transparency",
    "MONSDTE_m": "sampling depth",
}
NAMES = NITROGEN | CONTEXT | BIO_NAMES

# Technical identifiers and Dutch place/species names remain unchanged.
COLUMNS = {
    "monsterident": "sample_id",
    "locatiecode": "location_code",
    "locatie namespace": "location_namespace",
    "locatie omschrijving": "location_name",
    "locatie x": "rd_x",
    "locatie y": "rd_y",
    "locatie z": "location_elevation",
    "locatie referentievlakzcoord": "elevation_reference",
    "locatie KRW watertype": "wfd_water_type",
    "locatie EAG": "ecological_analysis_area",
    "locatie afaanvoergebied": "supply_drainage_area",
    "locatie KRWmeetpuntlocatie": "wfd_monitoring_location",
    "locatie morfologielocatie": "location_morphology",
    "locatie bodemsoortlocatie": "location_soil_type",
    "locatie meetprogrammahistorie": "historical_monitoring_program",
    "locatie meetprogrammaactueel": "current_monitoring_program",
    "locatie meetnethistorie": "historical_monitoring_network",
    "locatie meetnetactueel": "current_monitoring_network",
    "compartiment": "compartment",
    "datum": "date_time",
    "fewsparameter": "parameter_id",
    "fewsparametercode": "fews_parameter_code",
    "fewsparameternaam": "parameter_name_dutch",
    "fewsparametercategorie": "parameter_category_code",
    "fewsparametergrootheid": "fews_quantity_code",
    "fewsparametereenheidequivalent": "fews_unit_equivalent",
    "fewsparametereenheidreferentie": "fews_unit_reference",
    "fewsparameterparameterfractie": "fews_parameter_fraction_code",
    "limietsymbool": "limit_symbol",
    "meetwaarde": "reported_value",
    "eenheid": "reported_unit",
    "waardebewerkingsmethode": "value_processing_method",
    "kwaliteitsoordeelcode": "quality_code",
    "afronding": "rounding",
    "opmerkingmeting": "measurement_comment",
    "externereferentie": "external_reference",
    "xcoormonster": "sample_rd_x",
    "ycoormonster": "sample_rd_y",
    "monsternemer": "sampler",
    "planvanaanpak": "sampling_plan",
    "bemonsteringssoort": "sampling_type",
    "bron": "source",
    "analist": "analyst",
    "veldapparaat": "field_instrument",
    "bemonsteringsprotocol": "sampling_protocol",
    "analyseprotocol": "analysis_protocol",
    "analysecode": "analysis_code",
    "parametercode": "parameter_code",
    "grootheid": "quantity_code",
    "parameterfractie": "parameter_fraction_code",
    "parametergroep": "parameter_group_code",
    "parametertypering": "parameter_typing_code",
    "biotaxonnaam": "biological_taxon_name",
    "confertaxon": "tentative_taxon",
    "TWN naam": "twn_name",
    "TWN taxontype": "twn_taxon_type",
    "TWN taxonlevel": "twn_taxon_level",
    "WNA nederlandse soortnaam": "species_name_dutch",
    "TWN taxongroup": "twn_taxon_group",
    "beschermingsstatus florafaunawet": "flora_fauna_act_protection_status",
    "WNA oeverplantensoorten": "bank_plant_species",
    "WNA emerse plantensoorten": "emergent_plant_species",
    "WNA soorten met drijvend blad": "floating_leaf_species",
    "WNA kroossoorten": "duckweed_species",
    "WNA onderwaterplantensoorten": "submerged_plant_species",
    "WNA stromingsgilde vis": "fish_flow_guild",
    "WNA migratiegilde vis": "fish_migration_guild",
    "WNA habitatvoorkeur vis": "fish_habitat_preference",
    "WNA plantminnendheid vis": "fish_vegetation_affinity",
    "WNA reynolds groep cyanobacterieen": "cyanobacteria_reynolds_group",
    "WNA zuurstoftolerante vis": "fish_oxygen_tolerance",
    "WNA fytoplankton groep": "phytoplankton_group",
    "WNA fytoplankton subgroep": "phytoplankton_subgroup",
    "WNA toxische blauwalg": "toxic_cyanobacteria",
    "gedrag": "behavior",
    "lengteklasse": "length_class",
    "levensstadium": "life_stage",
    "levensvorm": "life_form",
    "verschijningsvorm": "appearance",
    "geslacht": "sex",
    "eenheidequivalent": "unit_equivalent",
    "eenheidreferentie": "unit_reference",
    "waarde": "reported_value",
    "locatie": "pump_series_id",
    "parameter": "parameter_id",
    "ID": "parameter_id",
    "NAME": "parameter_name_dutch",
    "SHORT_NAME": "short_name_dutch",
    "GROUP": "group_dutch",
    "TYPE": "measurement_type",
    "UNIT": "declared_unit",
    "VALUE_RESOLUTION": "value_resolution",
    "ALLOW_MISSING": "allow_missing",
    "STANDARD_NAME": "standard_name",
    "CELL_METHOD": "cell_method",
    "tijdstap": "time_step_dutch",
    "Bron": "source_code",
    "InternalParameterId": "internal_parameter_id",
    "P_naam": "internal_name_dutch",
    "P_grootheid": "internal_quantity_code",
    "P_categorie": "internal_category_code",
    "P_normkader": "assessment_framework",
    "P_parameter": "internal_parameter_code",
    "P_eenheidequivalent": "internal_unit_equivalent",
    "P_eenheidreferentie": "internal_unit_reference",
    "P_parameterfractie": "internal_fraction_code",
    "H_MAX": "h_max_source_threshold",
    "Z_MAX": "z_max_source_threshold",
    "H_MIN": "h_min_source_threshold",
    "Z_MIN": "z_min_source_threshold",
    "categorie": "category_code",
    "PAR_ID": "parameter_reference_id",
}
META = [
    "location_code", "location_name", "rd_x", "rd_y", "wfd_water_type",
    "ecological_analysis_area", "supply_drainage_area",
]


def save(frame: pd.DataFrame, output: Path, name: str) -> None:
    frame.to_csv(output / name, index=False)


def parse_dates(values: pd.Series) -> pd.Series:
    parsed = pd.to_datetime(values, format="mixed", errors="coerce")
    if parsed.dt.tz is None:
        return parsed.dt.tz_localize(GMT_PLUS_ONE)
    return parsed.dt.tz_convert(GMT_PLUS_ONE)


def clean_measurements(frame: pd.DataFrame) -> pd.DataFrame:
    frame = frame.rename(columns=COLUMNS).copy()
    frame["date_time_raw"] = frame["date_time"]
    frame["date_time"] = parse_dates(frame["date_time"])
    frame["value"] = pd.to_numeric(frame["reported_value"], errors="coerce")
    frame["invalid_date"] = frame["date_time"].isna()
    frame["invalid_value"] = ~np.isfinite(frame["value"])
    frame["is_censored"] = ~frame["limit_symbol"].fillna("").isin(["", "="])
    frame["parameter_name_en"] = frame["parameter_id"].map(NAMES)
    frame["analysis_eligible"] = (
        ~frame["invalid_date"] & ~frame["invalid_value"]
        & ~frame["is_censored"] & frame["quality_code"].eq("0")
        & frame["compartment"].eq("OW") & frame["value"].ge(0)
    )
    nitrogen = frame["parameter_id"].isin(NITROGEN)
    frame["analysis_unit"] = frame["reported_unit"]
    # Parameter definitions explicitly express these seven analytes as nitrogen.
    frame.loc[nitrogen, "analysis_unit"] = "mg N/L"
    frame.loc[nitrogen & ~frame["reported_unit"].eq("mg/l"), "analysis_eligible"] = False
    return frame


def nitrogen_wide(chemistry: pd.DataFrame) -> pd.DataFrame:
    good = chemistry.loc[chemistry["analysis_eligible"]].copy()
    keys = ["sample_id", "location_code", "date_time", "compartment"]
    grouped = good.groupby(keys + ["parameter_id"], dropna=False)["value"]
    medians = grouped.median().unstack("parameter_id")
    counts = grouped.size().unstack("parameter_id").add_suffix("__replicate_count")
    return medians.join(counts).reset_index()


def inventory(source: Path, output: Path, sample_size: int) -> list[dict]:
    records, translations = [], []
    for path in sorted(source.glob("*.csv")):
        with path.open(encoding="utf-8-sig", newline="") as stream:
            reader = csv.reader(stream)
            header = next(reader)
            rows = []
            if header[0] == "GMT+1":
                parameter_header = next(reader)
                english = ["date_time", "water_level_m_nap"]
                if len(header) == 3:
                    english.append("discharge_m3_day")
                for original, parameter, translated in zip(header, parameter_header, english):
                    translations.append({
                        "source_file": path.name, "source_column": original,
                        "source_parameter_header": parameter, "english_column": translated,
                    })
            else:
                for column in header:
                    if column not in COLUMNS:
                        raise ValueError(f"Untranslated source column: {path.name}: {column}")
                    translations.append({
                        "source_file": path.name, "source_column": column,
                        "source_parameter_header": "", "english_column": COLUMNS[column],
                    })
            for _, row in zip(range(sample_size), reader):
                rows.append(row)
        ten_minute = "10min" in path.name
        records.append({
            "source_file": path.name, "size_bytes": path.stat().st_size,
            "delimiter": ",", "encoding": "utf-8-sig", "source_column_count": len(header),
            "header_rows": 2 if header[0] == "GMT+1" else 1,
            "sample_rows_read": len(rows),
            "inspection_scope": "bounded sample only" if ten_minute else "full streaming processing",
            "source_columns_json": json.dumps(header),
        })
    save(pd.DataFrame(translations), output, "column_translations.csv")
    return records


def prepare_dictionary(source: Path, output: Path) -> None:
    guide = pd.read_csv(source / "Parameter_uitleg.csv", dtype=str).rename(columns=COLUMNS)
    guide["parameter_name_en"] = guide["parameter_id"].map(NAMES)
    guide["translation_status"] = np.where(
        guide["parameter_name_en"].notna(), "translated for this analysis",
        "original Dutch retained; outside selected parameter scope",
    )
    save(guide, output, "parameter_dictionary.csv")
    save(guide.loc[guide["parameter_id"].isin(NAMES)], output, "relevant_parameters.csv")


def prepare_chemistry(source: Path, output: Path, chunk_size: int) -> tuple[pd.DataFrame, dict]:
    needed = META + [
        "sample_id", "compartment", "date_time", "parameter_id", "limit_symbol",
        "reported_value", "reported_unit", "quality_code", "measurement_comment",
        "value_processing_method",
    ]
    usecols = [key for key, value in COLUMNS.items() if value in needed]
    header = pd.read_csv(source / CHEMISTRY, nrows=0).columns
    usecols = [column for column in usecols if column in header]
    parts, metadata, total = [], [], 0
    source_start, source_end = pd.NaT, pd.NaT
    source_parameters = set()
    for chunk in pd.read_csv(source / CHEMISTRY, dtype=str, usecols=usecols, chunksize=chunk_size):
        chunk["source_record_number"] = np.arange(total + 2, total + len(chunk) + 2)
        total += len(chunk)
        dates = parse_dates(chunk["datum"])
        if dates.notna().any():
            source_start = dates.min() if pd.isna(source_start) else min(source_start, dates.min())
            source_end = dates.max() if pd.isna(source_end) else max(source_end, dates.max())
        source_parameters.update(chunk["fewsparameter"].dropna().unique())
        translated = chunk.rename(columns=COLUMNS)
        metadata.append(translated[META].drop_duplicates())
        selected = chunk.loc[chunk["fewsparameter"].isin(NITROGEN | CONTEXT)]
        if not selected.empty:
            parts.append(clean_measurements(selected))
    selected = pd.concat(parts, ignore_index=True)
    selected["source_file"] = CHEMISTRY
    nitrogen = selected.loc[selected["parameter_id"].isin(NITROGEN)].copy()
    context = selected.loc[~selected["parameter_id"].isin(NITROGEN)].copy()
    save(nitrogen, output, "nitrogen_observations.csv")
    save(context, output, "supporting_chemistry.csv")
    wide = nitrogen_wide(nitrogen)
    save(wide, output, "nitrogen_samples_wide.csv")

    variants = pd.concat(metadata, ignore_index=True).drop_duplicates()
    variants["rd_x"] = pd.to_numeric(variants["rd_x"], errors="coerce")
    variants["rd_y"] = pd.to_numeric(variants["rd_y"], errors="coerce")
    variants["valid_rd_coordinate"] = (
        variants["rd_x"].between(0, 300000) & variants["rd_y"].between(300000, 650000)
    )
    variants["longitude"] = np.nan
    variants["latitude"] = np.nan
    valid = variants["valid_rd_coordinate"]
    transformer = Transformer.from_crs(28992, 4326, always_xy=True)
    lon, lat = transformer.transform(variants.loc[valid, "rd_x"], variants.loc[valid, "rd_y"])
    variants.loc[valid, "longitude"] = lon
    variants.loc[valid, "latitude"] = lat
    save(variants, output, "location_metadata_variants.csv")
    counts = variants.groupby("location_code").size()
    # Prefer usable coordinates, but explicitly flag non-unique metadata.
    locations = variants.sort_values("valid_rd_coordinate", ascending=False).drop_duplicates("location_code")
    locations["metadata_variant_count"] = locations["location_code"].map(counts)
    locations["has_nitrogen_observations"] = locations["location_code"].isin(nitrogen["location_code"])
    save(locations.sort_values("location_code"), output, "monitoring_locations.csv")

    for name, frame in [("nitrogen", nitrogen), ("supporting_chemistry", context)]:
        audit = frame.groupby(
            ["parameter_id", "reported_unit", "quality_code", "limit_symbol", "compartment"],
            dropna=False,
        ).agg(
            observation_count=("value", "size"), invalid_dates=("invalid_date", "sum"),
            invalid_values=("invalid_value", "sum"), eligible_count=("analysis_eligible", "sum"),
        ).reset_index()
        save(audit, output, f"{name}_quality_audit.csv")
    duplicate_keys = ["sample_id", "location_code", "date_time_raw", "parameter_id", "reported_value",
                      "reported_unit", "limit_symbol", "quality_code", "compartment"]
    facts = {
        "chemistry_source_rows": total, "nitrogen_rows": len(nitrogen),
        "chemistry_source_start": str(source_start), "chemistry_source_end": str(source_end),
        "chemistry_source_parameter_count": len(source_parameters),
        "chemistry_source_location_count": len(counts),
        "supporting_chemistry_rows": len(context),
        "nitrogen_locations": nitrogen["location_code"].nunique(),
        "nitrogen_start": str(nitrogen["date_time"].min()),
        "nitrogen_end": str(nitrogen["date_time"].max()),
        "nitrogen_eligible_rows": int(nitrogen["analysis_eligible"].sum()),
        "nitrogen_censored_rows": int(nitrogen["is_censored"].sum()),
        "nitrogen_duplicate_key_rows_retained": int(nitrogen.duplicated(duplicate_keys).sum()),
        "location_metadata_conflicts": int((counts > 1).sum()),
        "wide_sample_rows": len(wide),
    }
    return nitrogen, facts


def flow_partial(frame: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    dates = parse_dates(frame["datum"])
    values = pd.to_numeric(frame["waarde"], errors="coerce")
    aligned = dates.notna() & dates.eq(dates.dt.floor("h"))
    valid = aligned & np.isfinite(values) & frame["locatie"].notna()
    data = pd.DataFrame({
        "pump_series_id": frame.loc[valid, "locatie"],
        "date": dates.loc[valid].dt.normalize(),
        "value": values.loc[valid],
        "hour_mask": np.left_shift(np.int64(1), dates.loc[valid].dt.hour.to_numpy(dtype=np.int64)),
    })
    partial = data.groupby(["pump_series_id", "date"]).agg(
        hourly_value_sum=("value", "sum"), observation_count=("value", "size"),
        minimum_hourly_value=("value", "min"), maximum_hourly_value=("value", "max"),
        hour_mask=("hour_mask", lambda group: int(np.bitwise_or.reduce(group.to_numpy()))),
    ).reset_index()
    return partial, {
        "source_rows": len(frame), "invalid_or_missing_dates": int(dates.isna().sum()),
        "non_hour_aligned_rows": int((dates.notna() & ~aligned).sum()),
        "invalid_values": int((~np.isfinite(values)).sum()),
        "excluded_rows": int((~valid).sum()), "negative_value_rows": int(values.lt(0).sum()),
    }


def combine_flow_partials(partials: list[pd.DataFrame]) -> pd.DataFrame:
    daily = pd.concat(partials, ignore_index=True).groupby(["pump_series_id", "date"]).agg(
        hourly_value_sum=("hourly_value_sum", "sum"),
        observation_count=("observation_count", "sum"),
        minimum_hourly_value=("minimum_hourly_value", "min"),
        maximum_hourly_value=("maximum_hourly_value", "max"),
        hour_mask=("hour_mask", lambda group: int(np.bitwise_or.reduce(group.to_numpy(dtype=np.int64)))),
    ).reset_index()
    daily["observed_hours"] = daily["hour_mask"].map(int.bit_count)
    daily["duplicate_hour_rows"] = daily["observation_count"] - daily["observed_hours"]
    daily["coverage_fraction"] = daily["observed_hours"] / 24
    daily["complete_day"] = daily["observed_hours"].eq(24) & daily["duplicate_hour_rows"].eq(0)
    daily["volume_m3_assuming_hourly_rates"] = daily["hourly_value_sum"].where(daily["complete_day"])
    return daily.drop(columns="hour_mask")


def prepare_flows(source: Path, output: Path, chunk_size: int) -> tuple[pd.DataFrame, dict]:
    partials, audit = [], {}
    for chunk in pd.read_csv(source / "polderdebieten_uur_fews.csv", dtype=str, chunksize=chunk_size):
        if not chunk["parameter"].eq("Q.m3.uur").all():
            raise ValueError("Unexpected hourly flow parameter; cannot combine units.")
        partial, counts = flow_partial(chunk)
        partials.append(partial)
        for key, value in counts.items():
            audit[key] = audit.get(key, 0) + value
    daily = combine_flow_partials(partials)
    save(daily, output, "polder_flow_daily.csv")
    summary = daily.groupby("pump_series_id").agg(
        first_date=("date", "min"), last_date=("date", "max"),
        days_with_data=("date", "size"), complete_days=("complete_day", "sum"),
        duplicate_hour_rows=("duplicate_hour_rows", "sum"),
    ).reset_index()
    summary["station_asset_id"] = summary["pump_series_id"].str.split("_").str[0]
    summary["coordinates_available"] = False
    save(summary, output, "pump_series_inventory.csv")
    audit["pump_series_count"] = len(summary)
    audit["daily_rows"] = len(daily)
    audit["complete_days"] = int(daily["complete_day"].sum())
    audit["start"] = str(daily["date"].min())
    audit["end"] = str(daily["date"].max())
    return daily, audit


def prepare_pumps(source: Path, output: Path, chunk_size: int) -> dict:
    total, invalid_dates, invalid_states = 0, 0, 0
    start, end = pd.NaT, pd.NaT
    path = output / "pump_indicator_observations.csv"
    for chunk in pd.read_csv(source / "poldergemalen_aan_uit.csv", dtype=str, chunksize=chunk_size):
        if not chunk["parameter"].eq("INDCTAUT.DIMSLS.NE").all():
            raise ValueError("Unexpected pump indicator parameter.")
        chunk = chunk.rename(columns=COLUMNS)
        chunk["source_record_number"] = np.arange(total + 2, total + len(chunk) + 2)
        chunk["date_time_raw"] = chunk["date_time"]
        chunk["date_time"] = parse_dates(chunk["date_time"])
        chunk["indicator_value"] = pd.to_numeric(chunk["reported_value"], errors="coerce")
        chunk["invalid_date"] = chunk["date_time"].isna()
        chunk["invalid_indicator"] = ~chunk["indicator_value"].isin([0, 1])
        chunk.to_csv(path, mode="w" if total == 0 else "a", header=total == 0, index=False)
        total += len(chunk)
        invalid_dates += int(chunk["invalid_date"].sum())
        invalid_states += int(chunk["invalid_indicator"].sum())
        if chunk["date_time"].notna().any():
            minimum, maximum = chunk["date_time"].min(), chunk["date_time"].max()
            start = minimum if pd.isna(start) else min(start, minimum)
            end = maximum if pd.isna(end) else max(end, maximum)
    return {
        "source_rows": total, "invalid_dates": invalid_dates, "invalid_indicator_rows": invalid_states,
        "start": str(start), "end": str(end),
    }


def prepare_biology(source: Path, output: Path, chunk_size: int) -> dict:
    columns = ["locatiecode", "datum", "fewsparameter", "eenheid", "kwaliteitsoordeelcode"]
    parts, total, invalid_dates = [], 0, 0
    for chunk in pd.read_csv(source / BIOLOGY, usecols=columns, dtype=str, chunksize=chunk_size):
        chunk = chunk.rename(columns=COLUMNS)
        dates = parse_dates(chunk["date_time"])
        chunk["year"] = dates.dt.year
        total += len(chunk)
        invalid_dates += int(dates.isna().sum())
        parts.append(chunk.groupby(
            ["location_code", "year", "parameter_id", "reported_unit", "quality_code"], dropna=False,
        ).size().rename("observation_count").reset_index())
    summary = pd.concat(parts).groupby(
        ["location_code", "year", "parameter_id", "reported_unit", "quality_code"], dropna=False,
    )["observation_count"].sum().reset_index()
    summary["parameter_name_en"] = summary["parameter_id"].map(NAMES)
    summary["parameter_translation_available"] = summary["parameter_name_en"].notna()
    save(summary, output, "hydrobiology_coverage.csv")
    return {
        "source_rows": total, "invalid_dates": invalid_dates,
        "locations": summary["location_code"].nunique(),
        "parameters": summary["parameter_id"].nunique(),
        "first_year": float(summary["year"].min()), "last_year": float(summary["year"].max()),
    }


def prepare_regional(source: Path, output: Path) -> tuple[pd.DataFrame, dict]:
    frames, facts = [], {}
    definitions = [
        ("Amstelsluizen_waterhoogte.csv", "amstel_locks_daily.csv", ["water_level_m_nap"], "amstel_locks"),
        ("Berlagebrug_debiet_waterhoogte.csv", "berlage_bridge_daily.csv",
         ["water_level_m_nap", "discharge_m3_day"], "berlage_bridge"),
    ]
    for original, target, quantities, prefix in definitions:
        frame = pd.read_csv(source / original, skiprows=2, names=["date_time_raw"] + quantities, dtype=str)
        frame["date_time_gmt_plus_1"] = pd.to_datetime(
            frame["date_time_raw"], format="%d-%m-%Y %H:%M", errors="coerce",
        ).dt.tz_localize(GMT_PLUS_ONE)
        frame["invalid_date"] = frame["date_time_gmt_plus_1"].isna()
        for column in quantities:
            frame[f"{column}_raw"] = frame[column]
            frame[column] = pd.to_numeric(frame[column], errors="coerce")
            frame[f"{column}_invalid"] = ~np.isfinite(frame[column])
        frame["date"] = frame["date_time_gmt_plus_1"].dt.normalize()
        save(frame, output, target)
        usable = frame.loc[~frame["invalid_date"]].copy()
        if usable["date"].duplicated().any():
            raise ValueError(f"Multiple daily regional readings: {original}")
        facts[original] = {
            "source_rows": len(frame), "invalid_dates": int(frame["invalid_date"].sum()),
            "start": str(usable["date"].min()), "end": str(usable["date"].max()),
            "invalid_numeric_cells": int(sum(frame[f"{c}_invalid"].sum() for c in quantities)),
        }
        frames.append(usable.set_index("date")[quantities].add_prefix(prefix + "__"))
    merged = pd.concat(frames, axis=1).sort_index().reset_index()
    save(merged, output, "regional_hydrology_daily.csv")
    return merged, facts


def summarize_nitrogen(nitrogen: pd.DataFrame, output: Path, recent_year: int) -> pd.DataFrame:
    # One value per sample/analyte prevents lab replicates from overweighting summaries.
    good = nitrogen.loc[nitrogen["analysis_eligible"]]
    keys = ["sample_id", "location_code", "date_time", "parameter_id"]
    samples = good.groupby(keys, dropna=False)["value"].median().reset_index()
    parameter_summary = nitrogen.groupby("parameter_id").agg(
        observation_count=("value", "size"), location_count=("location_code", "nunique"),
        censored_count=("is_censored", "sum"), eligible_observation_count=("analysis_eligible", "sum"),
        first_observation=("date_time", "min"), last_observation=("date_time", "max"),
    ).join(samples.groupby("parameter_id").agg(
        eligible_sample_count=("value", "size"), median_eligible_sample_mg_n_l=("value", "median"),
    )).reset_index()
    parameter_summary.insert(1, "parameter_name_en", parameter_summary["parameter_id"].map(NITROGEN))
    save(parameter_summary, output, "nitrogen_parameter_summary.csv")
    recent = samples.loc[samples["date_time"].dt.year.ge(recent_year)]
    stats = recent.groupby(["location_code", "parameter_id"]).agg(
        sample_count=("value", "size"), median_mg_n_l=("value", "median"),
        p90_mg_n_l=("value", lambda values: values.quantile(0.9)),
        first_sample=("date_time", "min"), last_sample=("date_time", "max"),
    ).reset_index()
    stats["parameter_name_en"] = stats["parameter_id"].map(NITROGEN)
    stats["minimum_five_samples"] = stats["sample_count"].ge(5)
    stats["window_start_year"] = recent_year
    save(stats, output, "nitrogen_location_summary.csv")
    return samples


def make_plots(samples: pd.DataFrame, flows: pd.DataFrame, regional: pd.DataFrame,
               output: Path, recent_year: int) -> list[tuple[str, str]]:
    figures = output / "figures"
    figures.mkdir(exist_ok=True)
    images = []

    def finish(fig: plt.Figure, name: str, caption: str) -> None:
        fig.tight_layout()
        fig.savefig(figures / name, dpi=150)
        plt.close(fig)
        images.append((name, caption))

    recent = samples.loc[samples["date_time"].dt.year.ge(recent_year)].copy()
    recent["year"] = recent["date_time"].dt.year
    annual = recent.groupby(["year", "location_code", "parameter_id"])["value"].median().reset_index()
    annual = annual.groupby(["year", "parameter_id"])["value"].agg(["median", "count"]).reset_index()
    save(annual.rename(columns={"count": "monitoring_location_count", "median": "median_site_median_mg_n_l"}),
         output, "nitrogen_annual_summary.csv")
    fig, axes = plt.subplots(2, 1, figsize=(11, 7), sharex=True)
    for parameter, group in annual.groupby("parameter_id"):
        axes[0].plot(group["year"], group["median"], marker=".", label=NITROGEN[parameter])
        axes[1].plot(group["year"], group["count"], marker=".")
    axes[0].set(ylabel="mg N/L", title=f"Annual median of site medians, from {recent_year}")
    axes[0].legend(fontsize=8, ncol=2)
    axes[1].set(xlabel="Year", ylabel="Sites contributing")
    finish(fig, "nitrogen_trends.png",
           "Uncensored, surface-water, quality-code-0 samples only. Site composition changes over time; "
           "this is not a fixed-panel trend or a WFD compliance assessment. "
           f"The last year is partial: nitrogen observations end on {samples['date_time'].max():%Y-%m-%d}.")

    total = recent.loc[recent["parameter_id"].eq("Ntot_mgN/l")].copy()
    total["month"] = total["date_time"].dt.month
    fig, ax = plt.subplots(figsize=(10, 4))
    groups = [total.loc[total["month"].eq(month), "value"].to_numpy() for month in range(1, 13)]
    ax.boxplot(groups, showfliers=False, tick_labels=[str(month) for month in range(1, 13)])
    ax.set(xlabel="Month", ylabel="Total nitrogen (mg N/L)", title=f"Observed seasonality, from {recent_year}")
    finish(fig, "nitrogen_seasonality.png",
           "Pooled sample distributions; boxplots omit outlier markers, not data. Uneven sampling can bias seasonality.")

    stats = pd.read_csv(output / "nitrogen_location_summary.csv")
    locations = pd.read_csv(output / "monitoring_locations.csv")
    mapped = stats.loc[stats["parameter_id"].eq("Ntot_mgN/l") & stats["minimum_five_samples"]].merge(
        locations, on="location_code", validate="one_to_one",
    )
    mapped = mapped.loc[mapped["valid_rd_coordinate"] & mapped["metadata_variant_count"].eq(1)]
    fig, ax = plt.subplots(figsize=(9, 8))
    if not mapped.empty:
        points = ax.scatter(
            mapped["longitude"], mapped["latitude"], c=mapped["median_mg_n_l"],
            s=18 + np.minimum(mapped["sample_count"], 100), cmap="viridis", edgecolors="white", linewidths=.4,
        )
        fig.colorbar(points, ax=ax, label="Median total nitrogen (mg N/L)")
        for row in mapped.nlargest(5, "median_mg_n_l").itertuples():
            ax.annotate(row.location_code, (row.longitude, row.latitude), fontsize=7)
        ax.set_aspect(1 / np.cos(np.deg2rad(mapped["latitude"].median())))
    else:
        ax.text(.5, .5, "No sites meet the mapping criteria", transform=ax.transAxes, ha="center")
    ax.set(xlabel="Longitude (WGS84)", ylabel="Latitude (WGS84)",
           title=f"Monitoring-location map: total nitrogen, from {recent_year}")
    ax.grid(alpha=.25)
    save(mapped, output, "mapped_total_nitrogen_sites.csv")
    geojson = {
        "type": "FeatureCollection", "features": [
            {"type": "Feature", "geometry": {"type": "Point", "coordinates": [r.longitude, r.latitude]},
             "properties": {"location_code": r.location_code, "location_name": r.location_name,
                            "median_mg_n_l": r.median_mg_n_l, "sample_count": r.sample_count}}
            for r in mapped.itertuples()
        ],
    }
    (output / "monitoring_sites.geojson").write_text(json.dumps(geojson, indent=2), encoding="utf-8")
    finish(fig, "nitrogen_monitoring_map.png",
           "Offline coordinate map (no external tiles). RD New EPSG:28992 is assumed from Dutch x/y magnitudes; "
           "WGS84 EPSG:4326 conversion. At least five eligible samples; conflicting metadata excluded. "
           "Marker size indicates sample count. These are monitoring sites, NOT inferred pollution sources.")

    coverage = flows.assign(year=flows["date"].dt.year).groupby("year").agg(
        series_days=("complete_day", "size"), complete_days=("complete_day", "sum"),
    )
    fig, axes = plt.subplots(2, 1, figsize=(11, 6))
    axes[0].plot(coverage.index, coverage["complete_days"] / coverage["series_days"] * 100)
    axes[0].set(ylabel="Complete observed days (%)", title="Polder hourly-data completeness")
    axes[1].plot(regional["date"], regional["berlage_bridge__discharge_m3_day"], linewidth=.6)
    axes[1].axhline(0, color="black", linewidth=.5)
    axes[1].set(ylabel="Signed discharge (m3/day)", xlabel="Date", title="Berlage bridge: original sign retained")
    finish(fig, "hydrology_context.png",
           "Completeness denominator is series-days with at least one valid hour, not all calendar days. "
           "Daily volume is available only for 24 distinct hours with no duplicates. Discharge sign direction "
           "and hourly parameter semantics need confirmation from AGV.")
    return images


def write_report(output: Path, facts: dict, records: list[dict], images: list[tuple[str, str]],
                 recent_year: int) -> None:
    descriptions = {
        "Parameter_uitleg.csv": "Parameter definitions and source thresholds; used before selecting analytes.",
        CHEMISTRY: "Primary nitrogen observations and supporting chemistry; chunked extraction.",
        BIOLOGY: "Ecological response context; summarized by location/year/parameter/unit/quality. "
                 "Counts are observation rows, not abundance, richness, or WFD scores.",
        "polderdebieten_uur_fews.csv": "Primary pumping context; chunked into coverage-aware series/day summaries.",
        "poldergemalen_aan_uit.csv": "Binary indicator observations; cleaned without forward filling. "
                                   "Indicator semantics must be confirmed before treating them as pump runtime.",
        "Amstelsluizen_waterhoogte.csv": "Daily Amstel-locks water levels relative to NAP; two-row header, GMT+1.",
        "Berlagebrug_debiet_waterhoogte.csv": "Daily Berlage-bridge water levels and signed discharge; GMT+1.",
    }
    for part in range(1, 5):
        descriptions[f"polderdebieten_10min_fews_part{part}of4.csv"] = (
            f"Ten-minute pumping export, row partition {part}/4; own header, not a calendar partition. "
            "Sampled only; hourly export preferred. Full ten-minute counts/coverage/duplicates are not verified."
        )
    catalog = pd.DataFrame(records)
    catalog["purpose_and_processing"] = catalog["source_file"].map(descriptions)
    source_counts = {
        "Parameter_uitleg.csv": len(pd.read_csv(output / "parameter_dictionary.csv")),
        CHEMISTRY: facts["chemistry_source_rows"],
        BIOLOGY: facts["hydrobiology"]["source_rows"],
        "polderdebieten_uur_fews.csv": facts["hourly_flow"]["source_rows"],
        "poldergemalen_aan_uit.csv": facts["pump_indicators"]["source_rows"],
        **{name: data["source_rows"] for name, data in facts["regional_hydrology"].items()},
    }
    catalog["verified_source_rows"] = catalog["source_file"].map(source_counts).astype("Int64")
    periods = {
        CHEMISTRY: (facts["chemistry_source_start"], facts["chemistry_source_end"]),
        BIOLOGY: (str(int(facts["hydrobiology"]["first_year"])),
                  str(int(facts["hydrobiology"]["last_year"]))),
        "polderdebieten_uur_fews.csv": (facts["hourly_flow"]["start"], facts["hourly_flow"]["end"]),
        "poldergemalen_aan_uit.csv": (facts["pump_indicators"]["start"], facts["pump_indicators"]["end"]),
        **{name: (data["start"], data["end"]) for name, data in facts["regional_hydrology"].items()},
    }
    catalog["verified_start"] = catalog["source_file"].map({key: value[0] for key, value in periods.items()})
    catalog["verified_end"] = catalog["source_file"].map({key: value[1] for key, value in periods.items()})
    save(catalog, output, "source_catalog.csv")
    table_rows = "".join(
        f"<tr><td>{html.escape(r['source_file'])}</td><td>{r['size_bytes'] / 1e6:,.1f}</td>"
        f"<td>{source_counts[r['source_file']]:,}</td>"
        f"<td>{html.escape(' to '.join(periods.get(r['source_file'], ('not applicable',))))}</td>"
        f"<td>{html.escape(descriptions[r['source_file']])}</td></tr>"
        if r["source_file"] in source_counts else
        f"<tr><td>{html.escape(r['source_file'])}</td><td>{r['size_bytes'] / 1e6:,.1f}</td>"
        f"<td>not fully counted</td><td>not fully scanned</td>"
        f"<td>{html.escape(descriptions[r['source_file']])}</td></tr>"
        for r in records
    )
    nitrogen_table = pd.read_csv(output / "nitrogen_parameter_summary.csv").drop(
        columns=["first_observation", "last_observation"],
    ).to_html(index=False, border=0, float_format=lambda value: f"{value:.3f}")
    panels = "".join(
        f"<figure><img alt='{html.escape(name)}' src='data:image/png;base64,"
        f"{base64.b64encode((output / 'figures' / name).read_bytes()).decode()}'/>"
        f"<figcaption>{html.escape(caption)}</figcaption></figure>" for name, caption in images
    )
    caveats = """
<ul>
<li>No source-location prediction is made. High concentration is not proof of a nearby leak;
upstream transport, resuspension, dilution, sampling bias and biogeochemical processes remain alternatives.</li>
<li>To distinguish local inputs from upstream pollution, obtain pump/outfall coordinates, asset/series
relationships, directed river connectivity and flow direction, catchment boundaries, matched upstream/downstream
nitrogen samples, and rainfall/land-use/wastewater inputs. Use travel-time-aware mass balance and spatial/temporal
holdouts before fitting a source model. Do not equate geographically nearest sites with hydraulic connectivity.</li>
<li>No chemistry-to-pump or chemistry-to-flow join is invented. All timestamps are interpreted as fixed
GMT+1 (UTC+01:00, no daylight-saving changes), as requested by the user. This is an assumption for chemistry
and pumping files, whose headers do not declare a timezone; regional files already declare GMT+1. Regional levels/discharge
are outer-joined to each other on their daily date, not treated as measurements at every chemistry station.</li>
<li>Original Dutch place names, taxon names, technical IDs and codes are retained. Column titles are translated;
selected nitrogen/context parameter names are English. Other parameter names remain explicitly marked untranslated
in the full dictionary. Source H/Z thresholds are not interpreted as legal WFD limits.</li>
<li>All nitrogen rows, raw values, detection-limit symbols and quality codes are preserved. No limit/2 substitution,
interpolation or zero-filling is performed. Eligible exploratory values require OW, quality code 0, no inequality,
a finite nonnegative value and a valid date. Code 0 is a conservative selection, NOT a verified definition of quality;
other codes are excluded, not declared invalid. Nitrogen unit mg N/L follows the parameter definition, not the
ambiguous reported mg/l string. Replicates are median-aggregated in wide/sample summaries only.</li>
<li>Q.m3.uur is interpreted provisionally as an hourly rate/integrated hourly value. The raw hourly-value sum is kept
separately. A conditional daily volume is published only with 24 distinct hour-aligned readings and no duplicates;
partial days are not scaled up. Days are 24 hours under the fixed GMT+1 assumption. Negative values
are retained. Missing calendar days remain absent (unknown), not zero. Series IDs, including _Nieuw/_N/_D variants,
are never collapsed to an asset total because overlap and replacement semantics are unknown.</li>
<li>Ten-minute parts are not physically concatenated or substituted for the hourly export. Process each with its own
CSV header if sub-hourly event analysis becomes necessary. Temporal equivalence between the exports is unverified.
Pump indicators are preserved as observations without inferring durations or stale forward-filled states.</li>
<li>Location metadata variants are retained. RD coordinate validity uses a broad Netherlands bounding box;
the CRS is an explicit assumption requiring provider confirmation. Conflicting metadata is excluded from mapping.</li>
</ul>"""
    page = f"""<!doctype html><html lang="en"><meta charset="utf-8">
<title>Amstel nitrogen: data preparation and exploratory evidence</title>
<style>body{{font:16px system-ui;max-width:1150px;margin:40px auto;padding:0 20px;line-height:1.55}}
table{{border-collapse:collapse;font-size:14px}}td,th{{border:1px solid #ccc;padding:8px;text-align:left}}
img{{max-width:100%}}figure{{margin:30px 0}}figcaption{{color:#444}}pre{{white-space:pre-wrap}}</style>
<h1>Amstel nitrogen: data preparation and exploratory evidence</h1>
<p>AGV sources only. Originals unchanged. Exact selected-data counts come from chunked processing;
the four large ten-minute parts receive bounded inspection only. Recent plots start in {recent_year};
this is an exploratory display window, not a regulatory threshold.</p>
<h2>Source tables</h2><table><tr><th>Table</th><th>MB (decimal)</th><th>Verified rows</th>
<th>Observed period</th><th>Use</th></tr>
{table_rows}</table><h2>Nitrogen parameters</h2><p>All-history counts and medians below;
the charts use a recent window. Censored measurements are not exact concentrations and are excluded from
these medians. Medians use one eligible value per sample/analyte.</p>{nitrogen_table}
<h2>Verified processing counts</h2><pre>{html.escape(json.dumps(facts, indent=2))}</pre>
<h2>Visualizations</h2>{panels}<h2>Interpretation and constraints</h2>{caveats}
<h2>Output guide</h2><p>source_catalog.csv records source schemas and inspection scope;
column_translations.csv maps Dutch headers to English. parameter_dictionary.csv retains the full guide;
relevant_parameters.csv selects the translated analysis parameters. nitrogen_observations.csv and
supporting_chemistry.csv retain raw values and QC flags; nitrogen_samples_wide.csv is sample-level.
monitoring_locations.csv and location_metadata_variants.csv provide spatial metadata.
nitrogen_parameter_summary.csv describes analytes; nitrogen_location_summary.csv and nitrogen_annual_summary.csv support the plots.
hydrobiology_coverage.csv contains observation counts only. polder_flow_daily.csv and pump_series_inventory.csv
provide coverage-aware hydrology. pump_indicator_observations.csv preserves original indicator observations.
The regional daily files preserve raw readings and their GMT+1 declaration. monitoring_sites.geojson can be
opened locally in a GIS. quality_audit.json and the chemistry audit CSVs expose exclusions and issues.</p>
</html>"""
    (output / "report.html").write_text(page, encoding="utf-8")


def validate_outputs(output: Path, nitrogen: pd.DataFrame, flows: pd.DataFrame, facts: dict) -> None:
    assert len(nitrogen) == facts["nitrogen_rows"]
    assert flows["observed_hours"].between(1, 24).all()
    assert flows["duplicate_hour_rows"].ge(0).all()
    assert flows.loc[~flows["complete_day"], "volume_m3_assuming_hourly_rates"].isna().all()
    assert flows.loc[flows["complete_day"], "observed_hours"].eq(24).all()
    summary = pd.read_csv(output / "hydrobiology_coverage.csv")
    assert int(summary["observation_count"].sum()) == facts["hydrobiology"]["source_rows"]
    catalog = pd.read_csv(output / "source_catalog.csv")
    assert len(catalog) == 11
    assert catalog.loc[catalog["source_file"].str.contains("10min"), "inspection_scope"].eq(
        "bounded sample only",
    ).all()
    geo = json.loads((output / "monitoring_sites.geojson").read_text(encoding="utf-8"))
    assert all(-180 <= f["geometry"]["coordinates"][0] <= 180
               and -90 <= f["geometry"]["coordinates"][1] <= 90 for f in geo["features"])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT / "datasets" / "AGV")
    parser.add_argument("--output", type=Path, default=ROOT / "datasets" / "nitrogen_source_analysis")
    parser.add_argument("--chunk-size", type=int, default=250_000)
    parser.add_argument("--sample-size", type=int, default=1000)
    parser.add_argument("--recent-year", type=int, default=2015)
    args = parser.parse_args()
    if args.chunk_size < 1 or args.sample_size < 1:
        parser.error("chunk-size and sample-size must be positive")
    source, output = args.source.resolve(), args.output.resolve()
    if output == source or output.is_relative_to(source) or source.is_relative_to(output):
        parser.error("output must be separate from the source directory")
    output.mkdir(parents=True, exist_ok=True)
    records = inventory(source, output, args.sample_size)
    prepare_dictionary(source, output)
    print("Extracting chemistry...", flush=True)
    nitrogen, facts = prepare_chemistry(source, output, args.chunk_size)
    facts["time_zone_assumption"] = "Fixed GMT+1 (UTC+01:00), no daylight-saving changes; user-specified."
    print("Aggregating hourly pump flows...", flush=True)
    flows, facts["hourly_flow"] = prepare_flows(source, output, args.chunk_size)
    print("Preserving pump indicators...", flush=True)
    facts["pump_indicators"] = prepare_pumps(source, output, args.chunk_size)
    print("Summarizing hydrobiology...", flush=True)
    facts["hydrobiology"] = prepare_biology(source, output, args.chunk_size)
    regional, facts["regional_hydrology"] = prepare_regional(source, output)
    samples = summarize_nitrogen(nitrogen, output, args.recent_year)
    images = make_plots(samples, flows, regional, output, args.recent_year)
    write_report(output, facts, records, images, args.recent_year)
    validate_outputs(output, nitrogen, flows, facts)
    facts["validation"] = "passed"
    facts["run_configuration"] = {
        "source": str(source), "output": str(output), "chunk_size": args.chunk_size,
        "bounded_sample_rows_per_file": args.sample_size, "recent_year": args.recent_year,
    }
    (output / "quality_audit.json").write_text(json.dumps(facts, indent=2), encoding="utf-8")
    print(json.dumps(facts, indent=2), flush=True)
    print(f"Report: {output / 'report.html'}", flush=True)


if __name__ == "__main__":
    main()
