"""Conservative centreline topology and measurement-point network matching.

Coordinates must be metres in RD New (EPSG:28992). Only shared line endpoints
create junctions: geometric crossings alone do not prove hydraulic connectivity.
"""
from __future__ import annotations

from dataclasses import dataclass
from itertools import pairwise

import networkx as nx
import pandas as pd
from shapely.geometry import LineString, Point
from shapely.ops import substring
from shapely.strtree import STRtree


@dataclass(frozen=True)
class Reach:
    identifier: str
    geometry: LineString
    direction: str = "unknown"

    def __post_init__(self):
        if self.direction not in {"forward", "reverse", "reversible", "unknown"}:
            raise ValueError(f"Unrecognized normalized direction: {self.direction}")
        if self.geometry.is_empty or self.geometry.length <= 0 or not self.geometry.is_valid:
            raise ValueError(f"Invalid watercourse geometry: {self.identifier}")


def endpoint(point: tuple) -> tuple[float, float]:
    return round(point[0], 2), round(point[1], 2)


def snap_locations(locations: pd.DataFrame, reaches: list[Reach], maximum_distance: float = 50,
                   ambiguity_margin: float = 2) -> pd.DataFrame:
    if not reaches:
        raise ValueError("No watercourse centreline features.")
    if maximum_distance <= 0 or ambiguity_margin < 0:
        raise ValueError("Snap distance must be positive and ambiguity margin nonnegative.")
    geometries = [reach.geometry for reach in reaches]
    tree = STRtree(geometries)
    rows = []
    for location in locations.itertuples(index=False):
        record = {"location_code": location.location_code, "snap_status": "unmatched",
                  "reach_id": None, "distance_to_watercourse_m": None, "distance_along_reach_m": None,
                  "snapped_rd_x": None, "snapped_rd_y": None}
        if pd.isna(location.rd_x) or pd.isna(location.rd_y):
            record["snap_status"] = "invalid_coordinate"
            rows.append(record)
            continue
        point = Point(location.rd_x, location.rd_y)
        candidates = sorted(
            ((float(point.distance(geometries[index])), int(index))
             for index in tree.query(point.buffer(maximum_distance))),
            key=lambda item: (item[0], reaches[item[1]].identifier),
        )
        candidates = [(distance, index) for distance, index in candidates if distance <= maximum_distance]
        if candidates:
            distance, index = candidates[0]
            along = geometries[index].project(point)
            projected = geometries[index].interpolate(along)
            record.update(
                reach_id=reaches[index].identifier, distance_to_watercourse_m=distance,
                distance_along_reach_m=along, snapped_rd_x=projected.x, snapped_rd_y=projected.y,
                snap_status="matched",
            )
            for other_distance, other_index in candidates[1:]:
                if other_distance > distance + ambiguity_margin:
                    break
                other_projected = geometries[other_index].interpolate(geometries[other_index].project(point))
                if projected.distance(other_projected) > .02:
                    record["snap_status"] = "ambiguous"
                    break
        rows.append(record)
    return pd.DataFrame(rows)


def build_network(reaches: list[Reach], matches: pd.DataFrame) -> tuple[nx.MultiGraph, dict]:
    graph = nx.MultiGraph()
    station_nodes = {}
    accepted = matches.loc[matches["snap_status"].eq("matched")]
    for reach in reaches:
        split_points = [(0., endpoint(reach.geometry.coords[0])),
                        (reach.geometry.length, endpoint(reach.geometry.coords[-1]))]
        for match in accepted.loc[accepted["reach_id"].eq(reach.identifier)].itertuples(index=False):
            node = endpoint((match.snapped_rd_x, match.snapped_rd_y))
            station_nodes[match.location_code] = node
            split_points.append((match.distance_along_reach_m, node))
        ordered = sorted(set(split_points))
        for (start_distance, start_node), (end_distance, end_node) in pairwise(ordered):
            if start_node == end_node or end_distance <= start_distance:
                continue
            geometry = substring(reach.geometry, start_distance, end_distance)
            graph.add_edge(
                start_node, end_node, key=f"{reach.identifier}:{start_distance:.8f}",
                weight=float(geometry.length), reach_id=reach.identifier,
                direction=reach.direction, digitized_from=start_node, digitized_to=end_node,
                coordinates=list(geometry.coords),
            )
    return graph, station_nodes


def adjacent_measurements(graph: nx.MultiGraph, station_nodes: dict) -> list[dict]:
    """Find next measurement sites along each network branch, not straight lines."""
    stations_at_node = {}
    for code, node in station_nodes.items():
        stations_at_node.setdefault(node, []).append(code)
    relations = []
    for source_code, source in station_nodes.items():
        # A terminal sink prevents paths through another measurement location.
        terminal_graph = nx.DiGraph()
        for node in graph:
            for neighbor in graph.neighbors(node):
                attributes = min(graph[node][neighbor].values(), key=lambda edge: edge["weight"])
                if node == source or node not in stations_at_node:
                    terminal_graph.add_edge(node, neighbor, **attributes)
        if source not in terminal_graph:
            terminal_graph.add_node(source)
        lengths, paths = nx.single_source_dijkstra(terminal_graph, source, weight="weight")
        for target, path in paths.items():
            for target_code in stations_at_node.get(target, []):
                if target_code == source_code:
                    continue
                coordinates, directions, reach_ids = [], [], []
                for start, end in pairwise(path):
                    edge = terminal_graph[start][end]
                    forward = start == edge["digitized_from"]
                    line = edge["coordinates"] if forward else list(reversed(edge["coordinates"]))
                    coordinates.extend(line if not coordinates else line[1:])
                    reach_ids.append(edge["reach_id"])
                    if edge["direction"] in {"unknown", "reversible"}:
                        directions.append(None)
                    else:
                        directions.append(forward == (edge["direction"] == "forward"))
                if not directions:
                    relation = "same_network_location"
                elif all(direction is True for direction in directions):
                    relation = "nominal_downstream"
                elif all(direction is False for direction in directions):
                    relation = "nominal_upstream"
                else:
                    relation = "connected_direction_unresolved"
                relations.append({
                    "from_location": source_code, "to_location": target_code,
                    "relation": relation, "network_distance_m": float(lengths[target]),
                    "reach_ids": list(dict.fromkeys(reach_ids)), "coordinates_rd": coordinates,
                })
    return relations
