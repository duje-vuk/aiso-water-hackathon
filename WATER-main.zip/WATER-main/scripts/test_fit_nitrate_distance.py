import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
from scipy.optimize import check_grad

from fit_nitrate_distance import (
    candidate_grid, distance_kernel, fit_sources, objective, prepare_observations, run,
    spatial_validation,
)


class DistanceModelTests(unittest.TestCase):
    def observations(self, values, upper=None, codes=None):
        return pd.DataFrame({
            "value": values,
            "value_kind": ["upper_bound" if flag else "exact" for flag in (upper or [False] * len(values))],
            "location_code": codes or [f"S{i}" for i in range(len(values))],
        })

    def test_distance_is_symmetric_in_metres_with_unit_response_at_zero(self):
        points = np.array([[0., 0.], [3000., 4000.]])
        kernel = distance_kernel(points, points, 5000)
        np.testing.assert_allclose(kernel, [[1, np.exp(-1)], [np.exp(-1), 1]])
        with self.assertRaisesRegex(ValueError, "positive"):
            distance_kernel(points, points, 0)

    def test_grid_is_coarse_inside_coverage_and_rejects_degenerate_geometry(self):
        points = np.array([[0., 0.], [4000., 0.], [0., 4000.], [4000., 4000.]])
        grid = candidate_grid(points, 2000)
        np.testing.assert_equal(grid, [[1000, 1000], [3000, 1000], [1000, 3000], [3000, 3000]])
        with self.assertRaisesRegex(ValueError, "non-collinear"):
            candidate_grid(points[:2], 2000)
        with self.assertRaisesRegex(ValueError, "10,000"):
            candidate_grid(points, 1)

    def test_analytic_gradient_including_upper_bound_hinge(self):
        design = np.array([[1., .2], [1., .8], [1., .5]])
        values = np.array([.5, .2, 4.])
        upper = np.array([False, True, True])
        weights = np.array([.5, .25, .25])
        args = (design, values, upper, weights, .01)
        error = check_grad(lambda p: objective(p, *args)[0], lambda p: objective(p, *args)[1],
                           np.array([.3, .7]))
        self.assertLess(error, 1e-6)

    def test_upper_bound_is_not_an_exact_value_and_nonnegativity_is_enforced(self):
        data = self.observations([.1, 10.], [False, True])
        result = fit_sources(np.empty((2, 0)), data, .01)
        self.assertAlmostEqual(result["offset"], .1, places=6)
        data = self.observations([2., .1], [False, True])
        result = fit_sources(np.empty((2, 0)), data, .01)
        self.assertAlmostEqual(result["offset"], 1.05, places=6)
        with self.assertRaisesRegex(ValueError, "Upper bounds alone"):
            fit_sources(np.ones((1, 1)), self.observations([.1], [True]), .01)

    def test_repeated_observations_do_not_increase_a_sites_total_weight(self):
        data = self.observations([1., 3.], codes=["A", "B"])
        repeated = pd.concat([data.iloc[[0]]] * 10 + [data.iloc[[1]]], ignore_index=True)
        first = fit_sources(np.empty((2, 0)), data, .01)
        second = fit_sources(np.empty((11, 0)), repeated, .01)
        self.assertAlmostEqual(first["offset"], second["offset"], places=6)

    def test_recovers_synthetic_source_and_retains_all_site_dates_in_one_fold(self):
        x, y = np.meshgrid(np.linspace(0, 8000, 5), np.linspace(0, 8000, 5))
        points = np.column_stack([x.ravel(), y.ravel()])
        candidates = np.array([[2000., 2000.], [6000., 6000.]])
        kernel = distance_kernel(points, candidates, 2000)
        data = self.observations(.3 + kernel @ np.array([2., 0.]))
        fitted = fit_sources(kernel, data, 1e-7)
        np.testing.assert_allclose(fitted["sources"], [2., 0.], atol=.002)
        self.assertGreaterEqual(fitted["offset"], 0)
        self.assertTrue((fitted["sources"] >= 0).all())
        sites = pd.DataFrame({"location_code": data["location_code"], "rd_x": points[:, 0], "rd_y": points[:, 1]})
        repeated = pd.concat([data, data], ignore_index=True)
        validation, info = spatial_validation(repeated, sites, np.vstack([kernel, kernel]), 1e-7)
        self.assertTrue(validation.groupby("location_code")["spatial_fold"].nunique().eq(1).all())
        self.assertLess(info["distance_model"]["exact_rmse_mg_n_l"], .01)
        self.assertLess(info["distance_model"]["exact_rmse_mg_n_l"], info["offset_only"]["exact_rmse_mg_n_l"])

    def fixtures(self):
        points = np.array([[120000, 470000], [124000, 470000], [120000, 474000], [124000, 474000]])
        locations = pd.DataFrame({
            "location_code": ["A", "B", "C", "D"], "location_name": ["Alpha", "Beta", "Gamma", "Delta"],
            "rd_x": points[:, 0], "rd_y": points[:, 1], "longitude": [4.9] * 4, "latitude": [52.3] * 4,
            "valid_rd_coordinate": True, "metadata_variant_count": 1,
        })
        observations = pd.DataFrame({
            "sample_id": ["s1", "s2", "s3", "s4"], "location_code": locations["location_code"],
            "date_time": ["2024-01-01 00:01:00+01:00", "2024-04-15 12:00:00+01:00",
                          "2024-07-15 12:00:00+01:00", "2024-12-31 23:59:00+01:00"],
            "parameter_id": "NO3_mgN/l_nf", "limit_symbol": ["", "<", "", ""],
            "reported_unit": "mg/l", "quality_code": "0", "compartment": "OW",
            "value": ["1.0", "0.05", "0.8", "0.4"], "source_record_number": [1, 2, 3, 4],
        })
        return observations, locations

    def test_preparation_preserves_dates_limits_and_audits_exclusions(self):
        observations, locations = self.fixtures()
        observations.loc[2, "quality_code"] = "9"
        locations.loc[3, "metadata_variant_count"] = 2
        prepared = prepare_observations(observations, locations, 2024)
        self.assertEqual(prepared["use_in_model"].tolist(), [True, True, False, False])
        self.assertEqual(prepared.loc[1, "value_kind"], "upper_bound")
        self.assertEqual(prepared.loc[1, "value"], .05)
        self.assertTrue(prepared.loc[0, "date_time"].startswith("2024-01-01"))
        self.assertTrue(prepared["date_time"].str.endswith("+01:00").all())
        self.assertIn("quality_not_zero", prepared.loc[2, "exclusion_reason"])
        self.assertIn("coordinates", prepared.loc[3, "exclusion_reason"])

    def test_persistent_outputs_with_real_csv_io_and_no_report_plot_dependency(self):
        import json
        observations, locations = self.fixtures()
        with tempfile.TemporaryDirectory() as directory:
            data = Path(directory) / "input"
            output = Path(directory) / "output"
            data.mkdir()
            observations.to_csv(data / "nitrogen_observations.csv", index=False)
            locations.to_csv(data / "monitoring_locations.csv", index=False)
            with patch("fit_nitrate_distance.write_report"):
                metadata = run(data, output)
            self.assertEqual(metadata["observation_count"], 4)
            self.assertEqual(metadata["upper_bound_count"], 1)
            saved = pd.read_csv(output / "observations_with_predictions.csv")
            self.assertTrue(np.isfinite(saved["held_out_prediction_mg_n_l"]).all())
            self.assertTrue(saved.loc[saved["value_kind"].eq("upper_bound"), "exact_residual_mg_n_l"].isna().all())
            source_data = json.loads((output / "candidate_sources.geojson").read_text())
            self.assertEqual(len(source_data["features"]), metadata["candidate_count"])
            self.assertEqual(len(pd.read_csv(output / "seasonal_diagnostics.csv")), 4)
            self.assertEqual(json.loads((output / "model_metadata.json").read_text())["time_zone"],
                             "UTC+01:00, fixed; no DST")


if __name__ == "__main__":
    unittest.main()
