import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from bootstrap_nitrate_daily import bootstrap_day, hotspot_mask, resample_sites, run
from fit_nitrate_daily import run as fit_daily, write_report
from fit_nitrate_distance import fit_sources
import test_fit_nitrate_daily as daily_tests


class BootstrapDailyTests(unittest.TestCase):
    def test_cluster_multiplicity_is_not_cancelled_by_equal_site_weights(self):
        original = pd.DataFrame({"location_code": ["A", "A", "B"], "value": [1., 1., 4.],
                                 "value_kind": ["exact"] * 3})
        sample, indices = resample_sites(original, ["A", "A", "B"])
        self.assertEqual(indices.tolist(), [0, 1, 0, 1, 2])
        self.assertEqual(sample["location_code"].nunique(), 3)
        fitted = fit_sources(np.empty((len(sample), 0)), sample, .01)
        self.assertAlmostEqual(fitted["offset"], 2., places=6)
        self.assertEqual(original["location_code"].tolist(), ["A", "A", "B"])

    def test_hotspot_rank_ties_and_zero_draws(self):
        np.testing.assert_equal(hotspot_mask(np.zeros(4)), [False] * 4)
        np.testing.assert_equal(hotspot_mask(np.array([1., 2., 0., 0.]), .5), [True, True, False, False])
        np.testing.assert_equal(hotspot_mask(np.array([1., 1., 1., 1.]), .1), [True] * 4)
        with self.assertRaisesRegex(ValueError, "fraction"):
            hotspot_mask(np.ones(2), 0)

    def test_reproducibility_and_paired_kernels(self):
        frame, kernels = daily_tests.DailyModelTests().fixture()
        frame, kernels = frame.iloc[:4], {key: value[:4] for key, value in kernels.items()}
        first = bootstrap_day(frame, kernels, "2024-01-01", .01, 20, 2024)
        second = bootstrap_day(frame, kernels, "2024-01-01", .01, 20, 2024)
        self.assertEqual(first, second)
        self.assertEqual(first["validReplicates"], 20)
        self.assertEqual(first["models"]["network"], first["models"]["euclidean"])
        values = first["models"]["network"]
        self.assertTrue(all(0 <= value <= 1 for value in values["selectionFrequency"]))
        self.assertTrue((np.array(values["coefficientP025"]) <= values["coefficientMedian"]).all())
        self.assertTrue((np.array(values["coefficientMedian"]) <= values["coefficientP975"]).all())

    def test_all_censored_draws_are_counted_not_silently_redrawn(self):
        frame, kernels = daily_tests.DailyModelTests().fixture()
        frame = frame.iloc[:4].copy()
        frame.loc[1:, "value_kind"] = "upper_bound"
        result = bootstrap_day(frame, {key: value[:4] for key, value in kernels.items()},
                               "2024-01-01", .01, 20, 2024)
        self.assertGreater(result["rejectedNoExactResults"], 0)
        self.assertEqual(result["validReplicates"] + result["rejectedNoExactResults"], 20)
        self.assertEqual(result["status"] == "available", result["validReplicates"] >= 16)
        if result["status"] != "available":
            self.assertIsNone(result["models"])

    def test_persistence_freshness_and_embedded_report(self):
        frame, kernels = daily_tests.DailyModelTests().fixture()
        with tempfile.TemporaryDirectory() as directory:
            baseline, daily = Path(directory) / "baseline", Path(directory) / "daily"
            baseline.mkdir()
            frame.to_csv(baseline / "observations_with_predictions.csv", index=False)
            pd.DataFrame({"candidate_id": ["N1", "N2"], "longitude": [4.9, 5.], "latitude": [52.3, 52.4]}).to_csv(
                baseline / "candidate_sources.csv", index=False)
            pd.DataFrame([
                {"location_code": code, "candidate_id": candidate, "network_kernel": kernels["network"][i, j],
                 "euclidean_kernel": kernels["euclidean"][i, j]}
                for i, code in enumerate(["A", "B", "C", "D"]) for j, candidate in enumerate(["N1", "N2"])
            ]).to_csv(baseline / "source_receptor_distances.csv", index=False)
            (baseline / "model_metadata.json").write_text(json.dumps({
                "start": "2024-01-01", "end": "2024-01-03", "time_zone": "UTC+01:00",
                "observation_count": 8, "candidate_count": 2, "regularization": .01,
                "decay_length_m": 2000, "grid_spacing_m": 2000,
            }))
            with patch("fit_nitrate_daily.write_report"):
                metadata = fit_daily(baseline, daily, 3, 2)
            core_names = ["model_map.json", "observations_with_predictions.csv", "model_metadata.json", "daily_sources.csv"]
            hashes = {name: hashlib.sha256((daily / name).read_bytes()).hexdigest() for name in core_names}
            write_report(daily, pd.read_csv(daily / "daily_summary.csv"),
                         pd.read_csv(daily / "comparison.csv"), metadata)
            uncomputed = (daily / "report.html").read_text(encoding="utf-8")
            self.assertIn("Bootstrap computation was skipped", uncomputed)
            self.assertNotIn('href="bootstrap_stability.csv"', uncomputed)
            self.assertNotIn('href="bootstrap_metadata.json"', uncomputed)
            self.assertIn('"bootstrapReady": false', uncomputed)
            with patch("bootstrap_nitrate_daily.write_report"):
                details = run(daily, 20)
            self.assertEqual(details["available_day_count"], 2)
            self.assertEqual(hashes, {name: hashlib.sha256((daily / name).read_bytes()).hexdigest() for name in core_names})
            saved = json.loads((daily / "stability_map.json").read_text())
            self.assertEqual(saved["days"]["2024-01-03"]["status"], "not_fitted")
            self.assertIsNone(saved["days"]["2024-01-03"]["models"])
            self.assertEqual(len(pd.read_csv(daily / "bootstrap_stability.csv")), 8)
            write_report(daily, pd.read_csv(daily / "daily_summary.csv"),
                         pd.read_csv(daily / "comparison.csv"), metadata)
            report = (daily / "report.html").read_text(encoding="utf-8")
            self.assertIn('id="geoMap"', report)
            self.assertIn('id="stabilityMap"', report)
            self.assertIn('id="reportDay"', report)
            self.assertIn("NOT the probability", report)
            self.assertIn('"bootstrapReady": true', report)


if __name__ == "__main__":
    unittest.main()
