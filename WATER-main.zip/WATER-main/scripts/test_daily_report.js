"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { reportSelection, reportMessage } = require("./daily_report.js");
const data = {
  start: "2024-01-01", end: "2024-01-03",
  days: {
    "2024-01-01": { status: "fitted", siteCount: 12 },
    "2024-01-02": { status: "insufficient_data", siteCount: 2 },
    "2024-01-03": { status: "no_data", siteCount: 0 },
  },
  stabilityDays: {
    "2024-01-01": { status: "available", validReplicates: 200, attemptedReplicates: 200 },
    "2024-01-02": { status: "not_fitted", validReplicates: 0, attemptedReplicates: 0 },
    "2024-01-03": { status: "not_fitted", validReplicates: 0, attemptedReplicates: 0 },
  },
};
test("report sends the same model/day to both maps, differing only in view", () => {
  const selected = reportSelection(data, "2024-01-01", "network");
  assert.deepEqual(reportMessage(selected, "strength"),
    { type: "nitrogen-report-filter", model: "daily-network", day: "2024-01-01", view: "strength" });
  assert.deepEqual(reportMessage(selected, "stability"),
    { type: "nitrogen-report-filter", model: "daily-network", day: "2024-01-01", view: "stability" });
  assert.equal(reportSelection(data, "2024-01-01", "euclidean").model, "daily-distance");
});
test("unsupported report days remain selectable without annual or neighboring-day fallback", () => {
  assert.equal(reportSelection(data, "2024-01-02", "network").entry.status, "insufficient_data");
  assert.equal(reportSelection(data, "2024-01-03", "network").stability.status, "not_fitted");
  assert.equal(reportSelection(data, "2024-01-01", "network").previous, false);
  assert.equal(reportSelection(data, "2024-01-03", "network").next, false);
});
test("invalid calendar/model/view values are rejected", () => {
  assert.throws(() => reportSelection(data, "2025-01-01", "network"), RangeError);
  assert.throws(() => reportSelection(data, "2024-01-01", "other"), RangeError);
  assert.throws(() => reportMessage(reportSelection(data, "2024-01-01", "network"), "other"), RangeError);
});
