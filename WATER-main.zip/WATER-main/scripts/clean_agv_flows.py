"""Clean AGV polder pumping station data (waterkwantiteit).

Input : datasets/AGV/polderdebieten_uur_fews.csv   (850 MB, 17.6M rows, Q.m3.uur, hourly)
        datasets/AGV/poldergemalen_aan_uit.csv     (93 MB, 1.65M rows, pump on/off events)
Output: datasets/clean/polder_flows_hourly_wide.csv   date_time x station, m3/hour
        datasets/clean/polder_flows_daily_wide.csv    date x station, m3/day (sum)
        datasets/clean/pump_on_off_wide.csv           date_time x station, 0/1 (hourly, forward-filled)

The four 10-minute files (polderdebieten_10min_fews_part1-4) cover the same 83 stations
and period (1996-2025); the hourly aggregate is kept as the analysis product.
"""
import pandas as pd

# --- hourly flows ---
df = pd.read_csv(r"datasets/AGV/polderdebieten_uur_fews.csv",
                 dtype={"waarde": "float32"}, parse_dates=["datum"])
df = df.rename(columns={"datum": "date_time", "waarde": "discharge_m3_h",
                        "locatie": "station_id", "parameter": "parameter"})
df = df.drop(columns=["parameter"]).dropna(subset=["date_time"])
wide = df.pivot_table(index="date_time", columns="station_id",
                      values="discharge_m3_h", aggfunc="mean").sort_index()
wide.to_csv(r"datasets/clean/polder_flows_hourly_wide.csv")
daily = (wide * 1.0).resample("D").sum(min_count=12)  # m3/day, require >=12 h of data
daily.to_csv(r"datasets/clean/polder_flows_daily_wide.csv")
print("hourly flows:", df.shape[0], "rows |", wide.shape[1], "stations |",
      wide.index.min(), "->", wide.index.max())

# --- pump on/off indicator ---
on = pd.read_csv(r"datasets/AGV/poldergemalen_aan_uit.csv",
                 dtype={"waarde": "float32"}, parse_dates=["datum"])
on = on.rename(columns={"datum": "date_time", "waarde": "pump_on",
                        "locatie": "station_id", "parameter": "parameter"})
on = on.drop(columns=["parameter"]).dropna(subset=["date_time"])
owide = on.pivot_table(index="date_time", columns="station_id",
                       values="pump_on", aggfunc="last").sort_index()
# align to the hourly flow grid and forward-fill the event-based 0/1 signal
owide = owide.reindex(owide.index.union(wide.index)).sort_index().ffill().reindex(wide.index)
owide.to_csv(r"datasets/clean/pump_on_off_wide.csv")
print("pump on/off:", on.shape[0], "events |", owide.shape[1], "stations")
