import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import networkx as nx
import numpy as np
import pandas as pd
from shapely.geometry import LineString

from fit_nitrate_distance import run as run_baseline
from fit_nitrate_network_distance import network_candidates, network_distances, network_kernel, run
import test_fit_nitrate_distance as baseline_tests
from water_connectivity import Reach, build_network, snap_locations


class NetworkDistanceTests(unittest.TestCase):
    def test_bent_routes_are_longer_than_straight_distance_and_undirected(self):
        graph = nx.MultiGraph()
        graph.add_edge((0., 0.), (0., 10.), weight=10)
        graph.add_edge((0., 10.), (10., 10.), weight=10)
        distances = network_distances(graph, [(0., 0.), (10., 10.)], [(10., 10.), (0., 0.)])
        np.testing.assert_equal(distances, [[20, 0], [0, 20]])
        self.assertGreater(distances[0, 0], np.sqrt(200))
        np.testing.assert_allclose(network_kernel(distances, 20), [[np.exp(-1), 1], [1, np.exp(-1)]])
        with self.assertRaisesRegex(ValueError, "undirected"):
            network_distances(graph.to_directed(), [(0., 0.)], [(10., 10.)])

    def test_disconnected_channels_have_no_source_influence_not_euclidean_fallback(self):
        graph = nx.Graph()
        graph.add_edge((0., 0.), (10., 0.), weight=10)
        graph.add_edge((0., 1.), (10., 1.), weight=10)
        distances = network_distances(graph, [(0., 0.)], [(0., 1.), (10., 0.)])
        self.assertTrue(np.isinf(distances[0, 0]))
        self.assertEqual(network_kernel(distances, 20)[0, 0], 0)
        with self.assertRaisesRegex(ValueError, "nonnegative"):
            network_kernel(np.array([[-1.]]), 20)
        with self.assertRaisesRegex(ValueError, "positive"):
            network_kernel(distances, 0)

    def test_crossings_without_endpoint_junctions_remain_disconnected(self):
        reaches = [Reach("horizontal", LineString([(0, 0), (10, 0)])),
                   Reach("vertical", LineString([(5, -5), (5, 5)]))]
        locations = pd.DataFrame({"location_code": ["A", "B"], "rd_x": [1, 5], "rd_y": [0, 4]})
        matches = snap_locations(locations, reaches, maximum_distance=.1)
        graph, stations = build_network(reaches, matches)
        distances = network_distances(graph, [stations["A"]], [stations["B"]])
        self.assertTrue(np.isinf(distances[0, 0]))

    def test_candidate_nodes_keep_components_separate_inside_same_cell(self):
        graph = nx.Graph()
        graph.add_edge((0., 0.), (3., 0.), weight=3)
        graph.add_edge((0., 3.), (3., 3.), weight=3)
        graph.add_edge((100., 100.), (101., 100.), weight=1)
        stations = {"A": (0., 0.), "B": (3., 0.), "C": (0., 3.), "D": (3., 3.)}
        candidates, components = network_candidates(graph, stations, 10)
        self.assertEqual(len(candidates), 2)
        self.assertEqual(candidates["network_component"].nunique(), 2)
        self.assertTrue(candidates["cell_x"].eq(0).all())
        self.assertTrue(all(tuple(row) in graph for row in candidates[["rd_x", "rd_y"]].to_numpy()))
        self.assertNotIn(components[(100., 100.)], set(candidates["network_component"]))

    def test_persistent_comparison_reuses_baseline_and_excludes_ambiguous_sites(self):
        observations, locations = baseline_tests.DistanceModelTests().fixtures()
        extra = observations.iloc[[0]].copy()
        extra["sample_id"] = "excluded-sample"
        extra["location_code"] = "E"
        observations = pd.concat([observations, extra], ignore_index=True)
        extra_location = locations.iloc[[0]].copy()
        extra_location["location_code"] = "E"
        extra_location["rd_x"], extra_location["rd_y"] = 122000, 472000
        locations = pd.concat([locations, extra_location], ignore_index=True)
        graph = nx.MultiGraph()
        nodes = {row.location_code: (float(row.rd_x), float(row.rd_y))
                 for row in locations.iloc[:4].itertuples(index=False)}
        for start, end in [("A", "B"), ("A", "C"), ("C", "D")]:
            graph.add_edge(nodes[start], nodes[end], weight=4000)
        matches = pd.DataFrame({
            "location_code": ["A", "B", "C", "D", "E"],
            "snap_status": ["matched"] * 4 + ["ambiguous"],
            "distance_to_watercourse_m": 0., "manual_review_recommended": False,
        })
        provenance = {"snap_distance_limit_m": 50, "ambiguous_match_margin_m": 2}
        with tempfile.TemporaryDirectory() as directory:
            data, baseline, output = [Path(directory) / name for name in ["data", "baseline", "network"]]
            data.mkdir()
            observations.to_csv(data / "nitrogen_observations.csv", index=False)
            locations.to_csv(data / "monitoring_locations.csv", index=False)
            with patch("fit_nitrate_distance.write_report"):
                run_baseline(data, baseline)
            before = {path.name: path.read_bytes() for path in baseline.iterdir()}
            with patch("fit_nitrate_network_distance.load_cached_network",
                       return_value=(graph, nodes, matches, provenance)), patch("fit_nitrate_network_distance.write_report"):
                metadata = run(data, baseline, output)
            self.assertEqual(before, {path.name: path.read_bytes() for path in baseline.iterdir()})
            self.assertEqual(metadata["site_count"], 4)
            self.assertEqual(metadata["excluded_site_count"], 1)
            self.assertEqual(len(pd.read_csv(output / "comparison.csv")), 3)
            excluded = pd.read_csv(output / "excluded_observations.csv")
            self.assertEqual(excluded.loc[0, "network_exclusion_reason"], "network_ambiguous")
            saved = pd.read_csv(output / "observations_with_predictions.csv")
            self.assertEqual(len(saved), 4)
            self.assertTrue(np.isfinite(saved["held_out_prediction_mg_n_l"]).all())
            source_data = json.loads((output / "model_map.json").read_text())
            self.assertEqual(source_data["metric"], "network")
            self.assertEqual(source_data["includedSites"], ["A", "B", "C", "D"])
            self.assertEqual(len(pd.read_csv(output / "seasonal_diagnostics.csv")), 12)


if __name__ == "__main__":
    unittest.main()
