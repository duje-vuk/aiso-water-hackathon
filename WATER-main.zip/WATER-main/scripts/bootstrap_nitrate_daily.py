"""Site-cluster bootstrap stability for daily nitrate candidates, not source probabilities."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from fit_nitrate_daily import write_report
from fit_nitrate_distance import fit_sources
from prepare_nitrogen import ROOT


def validate_settings(replicates: int, seed: int, fraction: float) -> None:
    if not isinstance(replicates, int) or replicates < 20 or not isinstance(seed, int) or seed < 0:
        raise ValueError("Bootstrap requires at least 20 replicates and a nonnegative integer seed.")
    if not np.isfinite(fraction) or not 0 < fraction <= 1:
        raise ValueError("Hotspot fraction must be in (0, 1].")


def hotspot_mask(coefficients: np.ndarray, fraction: float = .1) -> np.ndarray:
    if not np.isfinite(fraction) or not 0 < fraction <= 1:
        raise ValueError("Hotspot fraction must be in (0, 1].")
    if not len(coefficients) or not np.isfinite(coefficients).all() or (coefficients < 0).any():
        raise ValueError("Hotspot coefficients must be finite and nonnegative.")
    count = max(1, int(np.ceil(len(coefficients) * fraction)))
    cutoff = np.partition(coefficients, len(coefficients) - count)[len(coefficients) - count]
    return (coefficients >= cutoff) & (coefficients > max(1e-10, float(coefficients.max()) * 1e-8))


def resample_sites(observations: pd.DataFrame, draws: list[str]) -> tuple[pd.DataFrame, np.ndarray]:
    groups = observations.groupby("location_code", sort=True).indices
    if not draws or any(code not in groups for code in draws):
        raise ValueError("Bootstrap draws must reference observed sites.")
    indices = np.concatenate([groups[code] for code in draws])
    sample = observations.iloc[indices].copy().reset_index(drop=True)
    # Distinct draw IDs preserve cluster multiplicity under equal-total-site fitting weights.
    sample["location_code"] = [f"draw_{draw}" for draw, code in enumerate(draws) for _ in groups[code]]
    return sample, indices


def bootstrap_day(observations: pd.DataFrame, kernels: dict[str, np.ndarray], day: str,
                  regularization: float, replicates: int = 200, seed: int = 2024,
                  fraction: float = .1) -> dict:
    validate_settings(replicates, seed, fraction)
    if not np.isfinite(regularization) or regularization <= 0:
        raise ValueError("Bootstrap regularization must be finite and positive.")
    if (set(kernels) != {"network", "euclidean"}
            or kernels["network"].shape != kernels["euclidean"].shape
            or any(kernel.ndim != 2 or kernel.shape[0] != len(observations) or not np.isfinite(kernel).all()
                   or (kernel < 0).any() or (kernel > 1).any() for kernel in kernels.values())
            or not observations["value_kind"].isin(["exact", "upper_bound"]).all()):
        raise ValueError("Bootstrap inputs must have paired, valid kernels and eligible observations.")
    hotspot_mask(np.zeros(kernels["network"].shape[1]), fraction)
    if pd.Timestamp(day).strftime("%Y-%m-%d") != day:
        raise ValueError("Bootstrap dates must be ISO calendar days.")
    sites = sorted(observations["location_code"].unique())
    if not sites:
        raise ValueError("Bootstrap requires observed sites.")
    rng = np.random.default_rng(np.random.SeedSequence([seed, int(day.replace("-", ""))]))
    coefficients = {model: [] for model in kernels}
    unique_counts, no_exact = [], 0
    for _ in range(replicates):
        draws = rng.choice(sites, size=len(sites), replace=True).tolist()
        sample, indices = resample_sites(observations, draws)
        if not sample["value_kind"].eq("exact").any():
            no_exact += 1
            continue
        unique_counts.append(len(set(draws)))
        for model, kernel in kernels.items():
            coefficients[model].append(fit_sources(kernel[indices], sample, regularization)["sources"])
    valid = replicates - no_exact
    minimum_valid = int(np.ceil(.8 * replicates))
    available = valid >= minimum_valid
    result = {
        "status": "available" if available else "insufficient_bootstrap_support",
        "attemptedReplicates": replicates, "validReplicates": valid,
        "rejectedNoExactResults": no_exact, "minimumValidReplicates": minimum_valid,
        "meanUniqueSites": float(np.mean(unique_counts)) if unique_counts else None,
        "models": None,
    }
    if available:
        result["models"] = {}
        for model, estimates in coefficients.items():
            matrix = np.array(estimates)
            frequencies = np.mean([hotspot_mask(row, fraction) for row in matrix], axis=0)
            lower, median, upper = np.quantile(matrix, [.025, .5, .975], axis=0)
            result["models"][model] = {
                "selectionFrequency": frequencies.tolist(), "coefficientP025": lower.tolist(),
                "coefficientMedian": median.tolist(), "coefficientP975": upper.tolist(),
            }
    return result


def run(directory: Path, replicates: int = 200, seed: int = 2024, fraction: float = .1) -> dict:
    validate_settings(replicates, seed, fraction)
    daily_path, observation_path = directory / "model_map.json", directory / "observations_with_predictions.csv"
    daily = json.loads(daily_path.read_text())
    metadata = json.loads((directory / "model_metadata.json").read_text())
    observations = pd.read_csv(observation_path, dtype={"location_code": str})
    baseline = Path(metadata["baseline_directory"])
    for name, digest in metadata["baseline_sha256"].items():
        if hashlib.sha256((baseline / name).read_bytes()).hexdigest() != digest:
            raise ValueError("Annual baseline changed since daily fitting; regenerate daily models first.")
    pairs = pd.read_csv(baseline / "source_receptor_distances.csv")
    candidates = [feature["properties"]["candidate_id"] for feature in daily["candidates"]["features"]]
    if len(set(candidates)) != len(candidates) or len(observations) != metadata["observation_count"]:
        raise ValueError("Daily candidate support or observation snapshot is inconsistent.")
    codes = sorted(observations["location_code"].unique())
    indices = pd.Series(np.arange(len(codes)), index=codes).loc[observations["location_code"]].to_numpy()
    kernels = {
        model: pairs.pivot(index="location_code", columns="candidate_id", values=column).reindex(
            index=codes, columns=candidates).to_numpy()[indices]
        for model, column in [("network", "network_kernel"), ("euclidean", "euclidean_kernel")]
    }
    if any(not np.isfinite(kernel).all() or (kernel < 0).any() or (kernel > 1).any()
           for kernel in kernels.values()):
        raise ValueError("Bootstrap distance kernels must be finite and in [0, 1].")
    days, rows = {}, []
    completed = 0
    for day, entry in daily["days"].items():
        if entry["status"] != "fitted":
            days[day] = {"status": "not_fitted", "reason": entry["status"], "models": None,
                         "validReplicates": 0, "attemptedReplicates": 0}
            continue
        mask = observations["slot_date"].eq(day).to_numpy()
        group = observations.loc[mask].reset_index(drop=True)
        if (len(group) != entry["sampleCount"] or group["location_code"].nunique() != entry["siteCount"]
                or not observations.loc[mask, "daily_fit_status"].eq("fitted").all()):
            raise ValueError("Daily source maps and bootstrap observations disagree.")
        result = bootstrap_day(group, {model: kernel[mask] for model, kernel in kernels.items()},
                               day, metadata["regularization"], replicates, seed, fraction)
        days[day] = result
        completed += 1
        if result["status"] == "available":
            for model, values in result["models"].items():
                for index, code in enumerate(candidates):
                    rows.append({
                        "date": day, "model": model, "candidate_id": code,
                        "selection_frequency": values["selectionFrequency"][index],
                        "coefficient_p025_mg_n_l": values["coefficientP025"][index],
                        "coefficient_median_mg_n_l": values["coefficientMedian"][index],
                        "coefficient_p975_mg_n_l": values["coefficientP975"][index],
                        "valid_replicates": result["validReplicates"],
                        "attempted_replicates": result["attemptedReplicates"],
                    })
        if completed % 10 == 0:
            print(f"Bootstrapped {completed} supported days", flush=True)
    model_hash = hashlib.sha256(daily_path.read_bytes()).hexdigest()
    observation_hash = hashlib.sha256(observation_path.read_bytes()).hexdigest()
    details = {
        "method": "Paired within-day site-cluster bootstrap, sampling sites with replacement.",
        "replicates": replicates, "seed": seed, "hotspot_fraction": fraction,
        "hotspot_rule": "Top ceil(candidate_count*fraction) coefficients, including cutoff ties; numerical zeros never qualify.",
        "numerical_zero": "coefficient <= max(1e-10, draw_maximum*1e-8)",
        "candidate_resolution": "Existing coarse grid cells per connected component, represented by on-network candidate points.",
        "weights": "All readings/limits at each sampled site retained; duplicate draws have distinct cluster IDs to retain multiplicity.",
        "invalid_draws": "All-censored draws are rejected, counted, and excluded from frequency denominator; no silent redraw.",
        "availability": "At least 80% of attempted draws must contain exact results and fit successfully. Solver failures raise errors.",
        "intervals": "2.5/50/97.5 bootstrap coefficient percentiles; conditional resampling ranges, not calibrated confidence or Bayesian intervals.",
        "interpretation": "Hotspot selection frequency is robustness to site resampling, NOT probability of a real pollution source.",
        "limitations": "Fixed kernel, grid, regularization, measured values and GIS topology; no hydraulic/model-form uncertainty or causal validation.",
        "daily_model_map_sha256": model_hash, "daily_observations_sha256": observation_hash,
        "available_day_count": sum(entry["status"] == "available" for entry in days.values()),
        "fitted_day_count": completed,
    }
    map_data = {
        "start": daily["start"], "end": daily["end"], "candidateIds": candidates,
        "replicates": replicates, "hotspotFraction": fraction, "days": days,
        "dailyModelMapSha256": model_hash, "dailyObservationsSha256": observation_hash,
    }
    columns = ["date", "model", "candidate_id", "selection_frequency", "coefficient_p025_mg_n_l",
               "coefficient_median_mg_n_l", "coefficient_p975_mg_n_l", "valid_replicates", "attempted_replicates"]
    pd.DataFrame(rows, columns=columns).to_csv(directory / "bootstrap_stability.csv", index=False)
    for name, data in [("bootstrap_metadata.json", details), ("stability_map.json", map_data)]:
        (directory / name).write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    write_report(directory, pd.read_csv(directory / "daily_summary.csv"),
                 pd.read_csv(directory / "comparison.csv"), metadata)
    if (hashlib.sha256(daily_path.read_bytes()).hexdigest() != model_hash
            or hashlib.sha256(observation_path.read_bytes()).hexdigest() != observation_hash):
        raise RuntimeError("Daily input snapshots changed during bootstrapping.")
    return details


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--daily-dir", type=Path, default=ROOT / "datasets" / "nitrate_daily_2024")
    parser.add_argument("--replicates", type=int, default=200)
    parser.add_argument("--seed", type=int, default=2024)
    parser.add_argument("--hotspot-fraction", type=float, default=.1)
    args = parser.parse_args()
    print(json.dumps(run(args.daily_dir.resolve(), args.replicates, args.seed, args.hotspot_fraction), indent=2))


if __name__ == "__main__":
    main()
