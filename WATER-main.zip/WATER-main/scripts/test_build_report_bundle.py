import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

from build_nitrogen_map import ASSETS
from build_report_bundle import REPORTS, build, collect_files, local_reference, validate_bundle
from fit_nitrate_daily import main as daily_main


class ReportBundleTests(unittest.TestCase):
    def test_dependency_closure_keeps_queries_fragments_and_css_assets_portable(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)
            report = source / "nitrogen_source_analysis" / "report.html"
            report.parent.mkdir()
            report.write_text('<a href="other.html?model=daily-network#map">map</a>'
                              '<a href="https://example.com">external</a>'
                              '<img src="plot%20one.png"><a href="#section">anchor</a>', encoding="utf-8")
            other = report.with_name("other.html")
            other.write_text('<link href="map.css"><a href="report.html">back</a>', encoding="utf-8")
            css = report.with_name("map.css")
            css.write_text("a{background:url('plot%20one.png?version=1')}b{background:url(data:image/png;base64,abc)}")
            image = report.with_name("plot one.png")
            image.write_bytes(b"image")
            self.assertEqual(set(collect_files(source, [report])), {report, other, css, image})

    def test_missing_dependency_is_an_explicit_error(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)
            with self.assertRaisesRegex(FileNotFoundError, "Missing report dependency"):
                local_reference(source / "report.html", "missing.csv?download=1", source)

    def test_escaping_and_absolute_references_are_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory) / "datasets"
            root.mkdir()
            for url in ["../outside.csv", "/absolute.csv", "file:///C:/raw.csv", "file://server/share/raw.csv"]:
                with self.subTest(url=url), self.assertRaises(ValueError):
                    local_reference(root / "report.html", url, root)

    def test_original_table_directories_are_not_copied(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory)
            raw = source / "AGV" / "large.csv"
            raw.parent.mkdir()
            raw.write_text("raw")
            with self.assertRaisesRegex(ValueError, "Only prepared report"):
                collect_files(source, [raw])

    def test_bundle_survives_relocation_and_preserves_input_bytes(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output = root / "datasets", root / "report"
            for _, folder, filename, _ in REPORTS:
                report = source / folder / filename
                report.parent.mkdir(parents=True, exist_ok=True)
                map_path = "../../nitrogen_source_analysis/nitrogen_map.html" if Path(filename).parent != Path(".") else (
                    "../nitrogen_source_analysis/nitrogen_map.html")
                report.write_text(f'<a href="{map_path}?model=daily-network">map</a>', encoding="utf-8")
            maps = source / "nitrogen_source_analysis"
            (maps / "nitrogen_map.html").write_text(
                '<link href="vendor/leaflet/leaflet.css"><script src="vendor/leaflet/leaflet.js"></script>')
            (maps / "nitrogen_map_data.json").write_text("{}")
            for name in ASSETS:
                asset = maps / "vendor" / "leaflet" / name
                asset.parent.mkdir(parents=True, exist_ok=True)
                asset.write_bytes(b"asset")
            (maps / "vendor" / "leaflet" / "leaflet.css").write_text(
                "a{background:url(images/layers.png)}")
            daily = source / "nitrate_daily_2024"
            metadata = {
                "evaluated_observation_count": 4, "evaluated_exact_count": 3,
                "evaluated_upper_bound_count": 1, "evaluated_day_count": 1,
                "fitted_day_count": 1, "insufficient_day_count": 2, "no_data_day_count": 363,
            }
            (daily / "model_metadata.json").write_text(json.dumps(metadata))
            (daily / "comparison.csv").write_text("model,exact_rmse_mg_n_l\ndaily_network,0.5\n")
            before = {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in source.rglob("*") if path.is_file()}
            manifest = build(source, output)
            self.assertIn("bootstrap was skipped", manifest["bootstrap"])
            self.assertNotIn("AGV", [record["path"].split("/")[0] for record in manifest["files"]])
            self.assertIn("No confidence probabilities", (output / "index.html").read_text())
            self.assertEqual(before, {path: hashlib.sha256(path.read_bytes()).hexdigest() for path in before})
            moved = root / "moved report"
            shutil.copytree(output, moved)
            self.assertGreater(validate_bundle(moved, [record["path"] for record in manifest["files"]] + ["index.html"]), 5)
            for record in manifest["files"]:
                self.assertEqual(hashlib.sha256((moved / record["path"]).read_bytes()).hexdigest(), record["sha256"])

    def test_report_only_does_not_fit_models(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory)
            for name in ["daily_summary.csv", "comparison.csv"]:
                (output / name).write_text("column\nvalue\n")
            (output / "model_metadata.json").write_text("{}")
            with (
                patch("sys.argv", ["fit_nitrate_daily.py", "--report-only", "--output", str(output)]),
                patch("fit_nitrate_daily.run") as fit,
                patch("fit_nitrate_daily.write_report") as report,
            ):
                daily_main()
            fit.assert_not_called()
            report.assert_called_once()


if __name__ == "__main__":
    unittest.main()
