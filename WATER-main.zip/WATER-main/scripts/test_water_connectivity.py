import unittest

import pandas as pd
from shapely.geometry import LineString

from water_connectivity import Reach, adjacent_measurements, build_network, snap_locations


class ConnectivityTests(unittest.TestCase):
    def locations(self, rows):
        return pd.DataFrame(rows, columns=["location_code", "rd_x", "rd_y"])

    def relations(self, reaches, rows):
        matches = snap_locations(self.locations(rows), reaches, maximum_distance=1, ambiguity_margin=.01)
        graph, nodes = build_network(reaches, matches)
        return adjacent_measurements(graph, nodes)

    def test_digitization_order_is_not_flow_direction(self):
        reaches = [Reach("r1", LineString([(0, 0), (10, 0)]))]
        relations = self.relations(reaches, [("A", 2, 0), ("B", 8, 0)])
        self.assertEqual(len(relations), 2)
        self.assertTrue(all(row["relation"] == "connected_direction_unresolved" for row in relations))

    def test_documented_forward_and_reverse_directions(self):
        for direction, expected in [("forward", "nominal_downstream"), ("reverse", "nominal_upstream")]:
            reaches = [Reach("r1", LineString([(0, 0), (10, 0)]), direction)]
            relation = next(row for row in self.relations(reaches, [("A", 2, 0), ("B", 8, 0)])
                            if row["from_location"] == "A")
            self.assertEqual(relation["relation"], expected)
            self.assertAlmostEqual(relation["network_distance_m"], 6)

    def test_crossings_without_shared_endpoints_do_not_connect(self):
        reaches = [Reach("horizontal", LineString([(0, 0), (10, 0)])),
                   Reach("vertical", LineString([(5, -5), (5, 5)]))]
        self.assertEqual(self.relations(reaches, [("A", 1, 0), ("B", 5, 4)]), [])

    def test_shared_endpoints_connect_and_next_station_stops_traversal(self):
        reaches = [Reach("r1", LineString([(0, 0), (10, 0)]), "forward"),
                   Reach("r2", LineString([(10, 0), (20, 0)]), "forward")]
        relations = self.relations(reaches, [("A", 2, 0), ("B", 8, 0), ("C", 18, 0)])
        pairs = {(row["from_location"], row["to_location"]) for row in relations}
        self.assertEqual(pairs, {("A", "B"), ("B", "A"), ("B", "C"), ("C", "B")})

    def test_ambiguous_parallel_channels_are_not_automatically_assigned(self):
        reaches = [Reach("r1", LineString([(0, 0), (10, 0)])),
                   Reach("r2", LineString([(0, 2), (10, 2)]))]
        matches = snap_locations(self.locations([("A", 5, 1)]), reaches, maximum_distance=5)
        self.assertEqual(matches["snap_status"].iloc[0], "ambiguous")
        _, nodes = build_network(reaches, matches)
        self.assertEqual(nodes, {})

    def test_distant_locations_remain_unmatched(self):
        reaches = [Reach("r1", LineString([(0, 0), (10, 0)]))]
        matches = snap_locations(self.locations([("A", 5, 100)]), reaches, maximum_distance=5)
        self.assertEqual(matches["snap_status"].iloc[0], "unmatched")

    def test_network_distance_and_geometry_follow_bends(self):
        reaches = [Reach("r1", LineString([(0, 0), (0, 10), (10, 10)]), "forward")]
        relation = next(row for row in self.relations(reaches, [("A", 0, 2), ("B", 8, 10)])
                        if row["from_location"] == "A")
        self.assertEqual(relation["network_distance_m"], 16)
        self.assertIn((0., 10.), relation["coordinates_rd"])


if __name__ == "__main__":
    unittest.main()
