(function (root) {
  "use strict";
  function reportSelection(data, day, metric) {
    if (!data.days[day] || !["network", "euclidean"].includes(metric)) {
      throw new RangeError("Choose an available calendar day and distance model.");
    }
    return {
      day, metric, entry: data.days[day], stability: data.stabilityDays[day],
      model: metric === "network" ? "daily-network" : "daily-distance",
      previous: day > data.start, next: day < data.end,
    };
  }
  function reportMessage(selection, view) {
    if (!["strength", "stability"].includes(view)) throw new RangeError("Unknown report map view.");
    return { type: "nitrogen-report-filter", model: selection.model, day: selection.day, view };
  }
  const api = { reportSelection, reportMessage };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (typeof document === "undefined") return;
  const $ = id => document.getElementById(id);
  const data = JSON.parse($("daily-report-data").textContent);
  const query = new URLSearchParams(root.location.search);
  let day = query.get("day") || data.defaultDate, metric = query.get("metric") || "network";
  function render() {
    const selection = reportSelection(data, day, metric);
    const entry = selection.entry, stability = selection.stability;
    $("reportDay").value = day;
    $("reportMetric").value = metric;
    $("reportPrevious").disabled = !selection.previous;
    $("reportNext").disabled = !selection.next;
    $("reportError").textContent = "";
    $("reportMapStatus").textContent = `${day}, fixed GMT+1: ${entry.siteCount} matched sites, `
      + `${entry.exactCount} exact results, ${entry.upperBoundCount} upper bounds. `
      + (entry.status === "fitted" ? "Independent daily fit. " : entry.status === "no_data"
        ? "No matched observations; no source or stability estimates. "
        : "Insufficient data; no source or stability estimates. ")
      + (stability.status === "available"
        ? `Bootstrap: ${stability.validReplicates}/${stability.attemptedReplicates} valid site-resampling draws.`
        : `Bootstrap status: ${stability.status.replace(/_/g, " ")}.`);
    $("stabilityMap").hidden = !data.bootstrapReady;
    $("bootstrapMissing").hidden = data.bootstrapReady;
    $("geoMap").contentWindow.postMessage(reportMessage(selection, "strength"), "*");
    if (data.bootstrapReady) $("stabilityMap").contentWindow.postMessage(reportMessage(selection, "stability"), "*");
    $("geoFullLink").href = `${data.mapPath}?model=${selection.model}&day=${day}`;
    $("stabilityFullLink").href = `${data.mapPath}?model=${selection.model}&day=${day}&view=stability`;
  }
  function change(newDay, newMetric) {
    try { reportSelection(data, newDay, newMetric); }
    catch (error) { $("reportError").textContent = error.message; return; }
    day = newDay;
    metric = newMetric;
    render();
  }
  $("reportDay").min = data.start;
  $("reportDay").max = data.end;
  $("reportDay").addEventListener("change", () => change($("reportDay").value, metric));
  $("reportMetric").addEventListener("change", () => change(day, $("reportMetric").value));
  for (const [id, step] of [["reportPrevious", -1], ["reportNext", 1]]) {
    $(id).addEventListener("click", () => {
      const date = new Date(day + "T00:00:00Z");
      date.setUTCDate(date.getUTCDate() + step);
      change(date.toISOString().slice(0, 10), metric);
    });
  }
  for (const id of ["geoMap", "stabilityMap"]) $(id).addEventListener("load", render);
  try { render(); }
  catch (error) { console.error("Daily report initialization failed", error); $("reportError").textContent = error.message; }
})(typeof globalThis !== "undefined" ? globalThis : this);
