# AGV nitrogen preparation

Use the existing conda `play` environment. No original data or existing cleaning
scripts are modified. The new workflow is independent of the earlier exports in
`datasets\clean`.

From the repository root in PowerShell:

```powershell
conda run -n play python -m unittest discover -s scripts -p test_prepare_nitrogen.py
conda run -n play python scripts\prepare_nitrogen.py
```

Dependencies already available in `play`: pandas, numpy, matplotlib and pyproj.
No web service, map tile service or data upload is used.

The source is `datasets\AGV`; the default output is
`datasets\nitrogen_source_analysis`. Open its `report.html` for the English table
overview, verified counts, plots, offline monitoring map, methodological choices
and limitations. This folder is already covered by the repository's dataset ignore
rule. Generated CSVs, PNGs, GeoJSON and HTML persist locally but are not committed.

Options: `--source`, `--output`, `--chunk-size` (default 250000),
`--sample-size` (default 1000), `--recent-year` (default 2015).
Chemistry, hydrobiology, hourly flows and pump indicators are processed in chunks;
the four ten-minute parts are sampled only, each with its own header. They are
row partitions, not non-overlapping date windows. The hourly export is used
instead; equivalence of the two exports has not been established.

## Important output semantics

- Long chemistry outputs preserve raw values, dates, source record numbers,
  inequality symbols, quality codes and exclusions. `OW` is provisionally treated
  as surface water. Code `0` is an explicit conservative exploratory filter,
  not a verified interpretation of the provider's quality-code taxonomy.
- Only the seven explicitly defined nitrogen analytes are normalized to
  `mg N/L`; no generic `mg/l` conversion is inferred for other parameters.
- Wide/sample products use median values for eligible replicates; wide columns
  retain replicate counts. Long rows are never silently deduplicated.
- Daily pump products retain partial observed sums, distinct-hour counts and
  cross-chunk duplicate-hour counts. Conditional volume is missing unless all
  24 hours are present without duplicates. Pump series are not summed by asset.
- Pump indicator observations are not forward-filled or converted to runtime.
  Their exact operational meaning and the sign of discharge need confirmation.
- All timestamps are interpreted as **fixed GMT+1 (UTC+01:00)** by user request,
  without daylight-saving changes. Original wall-clock timestamps are retained;
  cleaned datetime columns now carry `+01:00`. This convention is an assumption
  for chemistry and polder files; the regional files explicitly declare GMT+1.
- Hydrobiology coverage counts observation rows by location/year/parameter/unit/
  quality code. It does not sum mixed biological measurements or claim species
  richness, ecological scores, or nitrogen-source attribution.
- Full source column translations and the original parameter dictionary are
  retained. English names are supplied for selected analysis parameters; all
  other dictionary names are explicitly marked as untranslated.
- RD New (`EPSG:28992`) is an explicit coordinate assumption. Locations with
  conflicting metadata are excluded from the map, with variants preserved.
- The base chemistry preparation alone contains no river network or pump
  coordinates. The optional official-GIS enrichment below adds those surfaces
  and a user-selected outlet scenario, not verified event-specific flow.
  Monitoring hotspots are not pollution-source predictions.

The pipeline runs output invariants after generation. Focused standard-library
unit tests cover censoring, quality filtering, unit checks, malformed timestamps,
replicates, partial days, signed flows and cross-chunk duplicate hours.

## Interactive nitrogen map

To adapt the supplied map to the real, already-prepared AGV data:

```powershell
conda run -n play python -m unittest discover -s scripts -p "test_*nitrogen*.py"
node --test scripts\test_nitrogen_map.js
conda run -n play python scripts\build_nitrogen_map.py
```

Open `datasets\nitrogen_source_analysis\nitrogen_map.html`. It retains the grey
PDOK/Kadaster basemap, location search, orange markers, filter popup and EN/NL
controls from the supplied design. The attachment itself remains unchanged.
Select one of seven nitrogen analytes and exact inclusive start/end dates, then
apply the filters. Presets cover all observations, 2015 onward, and the last
12 months relative to the latest observation (not today's date).
The default window is 2015 through the latest mappable observation, with at least
five eligible samples per site. The minimum sample count is adjustable.
Search includes historical sites; a site without eligible data in the selected
window displays an explicit no-data popup rather than a zero concentration.

Markers show the median of sample-level eligible measurements **within the
selected window**, with counts, range and actual first/last sample dates in the
popup. Even-sized medians average both central values. Fixed per-analyte color
scales use the 95th percentile of all mappable eligible sample concentrations;
scales do not change between time windows. Colors are not regulatory classes.
Different nitrogen analytes are not summed or judged against the attachment's
dummy thresholds. Dummy sites, mock thresholds and administrative-area
exceedance shading are deliberately not carried over to the real-data map.

The builder reads `nitrogen_samples_wide.csv` and `monitoring_locations.csv`,
plus optional prepared GIS and distance-model overlays; it does not reprocess
the large raw tables.
Dates retain the source calendar day in the user-specified fixed GMT+1 timezone.
Coordinates with ambiguous metadata are excluded and counted in the embedded
metadata. `nitrogen_map_data.json` contains the exact browser data for reuse and
validation. All analyte samples remain embedded, so arbitrary date windows are
computed exactly rather than combining precomputed yearly medians.

The first map build downloads pinned Leaflet 1.9.4 JS/CSS and its license to
`vendor\leaflet` alongside the generated map. JS/CSS SHA-256 integrity is checked;
subsequent builds reuse and verify local assets. Keep that folder with the HTML.
Unlike the original offline report, this interactive map requests public PDOK
background tiles. Measurement values, location names and searches stay local;
there is no analytics, geocoding or measurement upload. A visible warning reports
tile failures; points and filtering continue without background tiles. Leaflet
load failures are explicit. No silent switch to another tile provider occurs.

## Distance-only nitrate inversion (first baseline)

The user selected **straight-line distance**, not water-network distance.
This intentionally non-Bayesian baseline fits 2024 nitrate-N using:

```text
prediction[i] = offset + sum_j s[j] * exp(-RD_distance(i,j) / 2000 metres)
offset >= 0; s[j] >= 0
loss = mean_over_sites(mean_over_results(squared_error_or_upper_bound_violation))
       + 0.01 * sum_j s[j]^2
```

Candidate points are centres of a regular **2 km grid** within the convex hull
of usable monitoring sites. The distance decay, spacing and regularization are
transparent, arbitrary initial settings, not calibrated transport parameters.
Each site has equal total fitting weight. Exact readings use squared residuals;
`<`/`<=` results use `max(prediction - reported_limit, 0)^2`. This soft upper-bound
penalty is not a censored likelihood, and does not substitute zero or limit/2.
Source laboratory records are retained; any repeated sample keys are counted.
Unsupported qualifiers, invalid values, nonzero quality codes, non-surface-water
samples, unexpected units and invalid/ambiguous coordinates are explicitly audited.

```powershell
conda run -n play python -m unittest discover -s scripts -p test_fit_nitrate_distance.py
conda run -n play python scripts\fit_nitrate_distance.py
conda run -n play python scripts\build_nitrogen_map.py
```

Uses existing numpy, pandas, scipy, pyproj and matplotlib in `play`; no new
dependency or internet download is needed for fitting. Results persist under
`datasets\nitrate_distance_baseline_2024`:

- `report.html` and `distance_diagnostics.png`: assumptions, candidate scores,
  geographic held-out predictions and comparison with an offset-only baseline.
- `candidate_sources.csv` / `.geojson`: grid coordinates, kernel coefficients
  and relative scores (coefficient divided by the maximum; **not probability**).
- `observations_with_predictions.csv`: original timestamps/qualifiers, full-fit
  predictions, geographic-fold held-out predictions and appropriate residuals.
  Censored results never receive an exact-value residual.
- `excluded_observations.csv`: explicitly excluded in-year rows and reasons.
- `seasonal_diagnostics.csv`: quarterly diagnostics using held-out predictions.
- `model_metadata.json`: settings, counts, optimizer status, validation and
  limitations; `model_map.json`: compact interactive-map overlay.

Open the report's map link, or use **Use model nitrate/date window** on the
existing nitrogen map. Purple candidates display beneath orange measured-site
markers. The overlay appears only for nitrate and exactly its fitted date
window; changing filters never silently refits or temporally repurposes it.
Ordinary map defaults and the seven measured-analyte filters remain unchanged.
The measured markers remain uncensored medians, unlike the model's individual
exact readings and limits; sites with only censored readings constrain the
model but have no eligible measured marker.

Validation holds out entire geographic quadrants (split at median site RD
x/y), keeping all samples from a site together. The candidate grid is fixed
from coordinates only, without using held-out concentrations. Quadrant
boundaries have no spatial buffer. RMSE/MAE describe exact individual results;
upper-bound violation RMSE is reported separately. A failure to improve on
the offset-only model is displayed explicitly rather than hiding weak results.
Seasonal variation is diagnosed, not fitted.

Options: `--data-dir`, `--output`, `--year`, `--grid-spacing-m`,
`--decay-length-m`, `--regularization`. The bounding-box grid is capped at
10,000 cells to reject accidentally excessive allocations before generation.
For another model directory/year, pass its `model_map.json` explicitly with
the map builder's `--distance-model` option.

**Interpretation:** coefficients are concentration amplitudes for an arbitrary
dimensionless distance kernel, not emission rates or kg N/day. The offset is
not measured upstream background. Neither water connectivity/direction nor
pumping, dilution, reactions, source inventories, land-delivery pathways or
Bayesian uncertainty enter this baseline. Candidate cells are not confirmed
water-entry points or original land sources. Correlated cells need not be
separately identifiable; ridge tends to spread scores. No credible intervals,
parcel attribution or source probabilities are produced.

## Version 2: water-connectivity distance

The original Euclidean baseline folder is preserved. The second version reads
its audited observation snapshot and reuses the same optimizer, censoring loss,
equal-total-site weights and default grid spacing/decay/regularization settings.
It uses **shortest undirected path length along the cached official watercourse
and culvert graph**, not assumed AMS011 flow direction:

```text
A[i,j] = exp(-shortest_water_network_distance(i,j) / decay_length)
A[i,j] = 0 if no graph path exists
```

```powershell
conda run -n play python -m unittest discover -s scripts -p "test_fit_nitrate*.py"
conda run -n play python scripts\fit_nitrate_network_distance.py
conda run -n play python scripts\build_nitrogen_map.py
```

The existing baseline outputs and cached GIS enrichment must be present.
No new download or dependency installation is needed in `play`. The source
watercourse/culvert snapshots rebuild the same graph as GIS provenance; a count
mismatch fails explicitly. Only existing unambiguous station matches are used.
Unmatched and ambiguous sites are **excluded and audited**, not linked by a
straight-line fallback or treated as zero readings.

Candidates are actual graph nodes: choose the node nearest the centre of each
occupied grid cell **per observed connected component**, inside the matched-site
convex hull. Nodes from different components in the same cell remain separate.
All candidates lie on the water network; this is not evidence that they are
actual entry points or original land sources. Off-water station snap distances
are recorded, not appended as invented water routes.

For a fair comparison, the script also refits a **same-support Euclidean model**
using the identical snapped sensor coordinates, on-network candidate points,
observations, geographic folds and regularization. A constant-only comparison
uses the same observations and censor treatment. Do not compare the original
all-site baseline's RMSE directly against the smaller matched subset.
Candidate selection uses coordinates, never held-out concentration values.
Components absent from a fold's training set receive no learned source
contribution; these held-out rows are flagged and receive only the fitted
shared constant offset.

Outputs persist under `datasets\nitrate_network_distance_2024`:

- `report.html` / `network_distance_diagnostics.png`: same-support comparison,
  scores for both kernels, coverage and limitations.
- `comparison.csv`: held-out exact RMSE/MAE and separate upper-bound violation
  RMSE for network, same-support Euclidean and constant-only models.
- `candidate_sources.csv` / `.geojson`: graph-node coordinates, component IDs
  and separately normalized coefficients for both distance models.
- `observations_with_predictions.csv`: original timestamps/values/qualifiers,
  snap offsets, projected model coordinates, components, full-fit and held-out
  predictions for both distance models, and unseen-training-component flags.
- `excluded_observations.csv`: baseline-eligible rows omitted for network
  assignment reasons. Earlier chemistry exclusions remain in the original baseline.
- `source_receptor_distances.csv`: every site/candidate pair, connectivity flag,
  both distances and kernels. Disconnected network distances are blank, explicitly
  marked `connected=False`, and have kernel zero (never a zero-length route).
- `seasonal_diagnostics.csv`, `model_metadata.json`, `model_map.json`: quarterly
  comparison, settings, original-baseline input hashes, provenance and map data.

On the existing map, choose **Water-connectivity distance** in the model-version
selector and **Use model nitrate/date window**, or use the report's direct map
link. The previous straight-line baseline remains selectable. Ordinary map
defaults are unchanged. Orange measurement markers may include non-modelled
sites; coverage is stated explicitly and monitor popups indicate fit inclusion.
Model overlays remain fixed to their nitrate/date window and do not silently
refit when filters change.

Options: `--data-dir`, `--baseline-dir`, `--output`, `--grid-spacing-m`,
`--decay-length-m`, `--regularization`. The three numerical settings default to
the preserved baseline metadata. Use a separate output directory for another
baseline/year, and pass its overlay to the map builder with `--connectivity-model`.
The original overlay path remains controlled independently by `--distance-model`.

**Limitations:** the graph is a conservative geometric hypothesis. Only shared
endpoints rounded to 0.01 m create junctions, not line crossings; missing links
can create artificial disconnections. A graph disconnection does not establish
real hydraulic isolation. Structure passability, historical topology, pump
operations and actual flow direction remain unverified. A global constant
offset is a statistical nuisance term, not upstream transport across components.
This version still adds no Bayesian inference, calibrated travel time, mass
balance, reaction/dilution model, source inventory or land-origin attribution.

## Version 3: independent daily source maps

The user chose **24-hour daily slots with separate source estimates per day**,
not shared persistent sources with a time-varying background. Calendar boundaries
are fixed GMT+1, including all 366 days of 2024. The fitting uses individual
results and limits, never monthly or seasonal averages. Multiple readings at a
site retain their timestamps and equal-total-site fitting weights. Samples
within a day need not have been collected simultaneously.

```powershell
conda run -n play python -m unittest discover -s scripts -p "test_fit_nitrate*.py"
node --test scripts\test_nitrogen_map.js
conda run -n play python scripts\fit_nitrate_daily.py
conda run -n play python scripts\build_nitrogen_map.py
```

Requires the preserved annual matched-network comparison outputs from Version 2.
Both DAILY distance versions use the identical 134 network-matched sites,
113 on-network candidate points, distance kernels and regularization from that
comparison. The all-site Euclidean annual baseline remains available separately;
it is not mixed into like-for-like evaluation of the smaller matched subset.
No new dependency, GIS refresh or download is required.

The default coverage screen requires **10 distinct sites**, including **3 sites
with exact results**, for a day to be fitted. This is an explicit heuristic,
**not a guarantee of identifiability or confidence**: daily candidate counts
typically exceed available monitoring sites. Days below the screen have status
`insufficient_data`; days without matched readings have status `no_data`.
Neither has source estimates, substituted annual maps, zero-imputed readings,
interpolation or carry-forward from adjacent dates.

Each fitted day receives fresh nonnegative source coefficients AND a fresh
constant offset, using the existing soft upper-bound loss and L2 penalty.
No temporal smoothing or monthly/seasonal background model is added.

### Daily-versus-annual validation

- Preserve the annual geographic station folds. All samples at a held-out site
  remain held out, not just individual timestamps.
- Daily training uses **only other sites on the same calendar day**.
- Apply the same coverage screen to TRAINING rows alone. Unsupported folds have
  explicitly missing daily predictions, never fallback annual predictions.
- Compare daily network, daily Euclidean, daily constant-only, annual network,
  annual same-support Euclidean and annual constant-only on **exactly the same
  supported holdout observations**.
- Annual references are the preserved **held-out** predictions, not annual
  full-fit predictions. This is retrospective spatial validation, not forecasting.
- Count and disclose excluded validation rows/days. A result on well-sampled
  days must not be interpreted as full-year or unsampled-day performance.

The DAILY constant-only comparator matters: improvements from adapting the
daily background must not be mistaken for successful source localization.
Exact-result RMSE/MAE and upper-bound violation RMSE remain separate metrics.
No confidence intervals, Bayesian probabilities or calibrated source confidence
are inferred from these scores.

### Daily map filter and outputs

Open `datasets\nitrate_daily_2024\report.html` and follow either daily map link,
or select **Daily straight-line (matched sites)** / **Daily water-connectivity**
in the existing map's model-version selector. A calendar date filter and
previous/next-day buttons let you visit **every calendar day**, including empty
and unsupported days. Date selection sets the measured-analyte filter to nitrate,
the chosen single day, and minimum **one** uncensored sample per location.
Measured markers still show within-window medians, not model predictions;
only-censored sites can constrain fitting without an orange measured marker.

Per-day model status shows site/result/limit counts, the screening rule and
validation availability. Sparse days display an explicit explanation and no
purple candidates. A single-day selection in the existing date-filter panel
also selects that daily model slot; multi-day or other-analyte filters hide the
overlay instead of silently averaging or reusing it.

Source-score scaling is **fixed across all fitted days within each distance
version**: coefficient divided by that version's maximum daily coefficient
over the analysis period. Different dates do not each reset their highest
coefficient to one. The score is a relative amplitude, not confidence.
The annual model versions and ordinary map defaults remain unchanged.

Persistent outputs under `datasets\nitrate_daily_2024`:

- `report.html` / `daily_coverage.png`: coverage, limitations and the six-model
  same-observation comparison.
- `daily_summary.csv`: every calendar date, fit status, sampled/uncensored-site
  counts, exact/limit counts and validated-row count.
- `daily_sources.csv`: candidate coefficients and fixed-scale relative scores
  for each supported day and distance version.
- `observations_with_predictions.csv`: original measurements, timestamps,
  full daily fits, preserved annual holdout predictions, daily holdout
  predictions and explicit fit/validation status. Unsupported predictions
  are blank, not zero.
- `validation_folds.csv`: date, fold, training coverage, held-out rows and
  eligibility status; `comparison.csv`: metrics on the shared evaluation mask.
- `model_metadata.json`: settings, counts, comparison and SHA-256 hashes of
  the untouched annual input snapshots; `model_map.json`: compact calendar,
  daily coefficients and fixed candidate geometry for the map.

Options: `--baseline-dir`, `--output`, `--report-only`, `--minimum-sites` (default 10),
`--minimum-exact-sites` (default 3). The map builder accepts `--daily-model`
for a different generated `model_map.json`. Lower screening thresholds allow
more maps but do not manufacture identifying evidence.

### Consolidated portable reports (no bootstrap)

The root `report` folder collects all five reports, the interactive nitrogen map,
local Leaflet assets, figures and linked CSV/GeoJSON/metadata downloads. Open
`report\index.html` directly, or move the entire folder to another location.
It does not require the repository, Python, the original AGV files or a web server.
Background PDOK tiles still need internet; report data and map controls stay local.

Refresh the saved daily report and map, then package them without refitting any
model or computing bootstrap estimates:

```powershell
conda run -n play python -B scripts\fit_nitrate_daily.py --report-only
conda run -n play python -B scripts\build_nitrogen_map.py
conda run -n play python -B scripts\build_report_bundle.py
conda run -n play python -B -m unittest discover -s scripts -p "test_build_report_bundle.py"
node --test scripts\test_daily_report.js scripts\test_nitrogen_map.js
```

The daily report embeds a geographic map with shared day/model filters. Bootstrap
was skipped at the user's request: the confidence panel explicitly says estimates
are not computed, and no nonexistent bootstrap downloads are linked. Relative
source scores are never relabeled as confidence. Existing optional, fresh
bootstrap outputs can be displayed, but neither `--report-only` nor the packager
runs bootstrap or changes stored model coefficients.

The packager follows local HTML/CSS references, preserves their relative layout,
includes Leaflet's license and image assets, and fails on missing dependencies,
absolute local links or traversal outside the prepared report directories.
`report\manifest.json` records copied-file sizes and SHA-256 checksums. Original
multi-gigabyte AGV tables and unlinked GIS snapshots are excluded. Both `datasets`
and the generated `report` folder are ignored by Git. Do not publish the data
externally without checking the source-data redistribution rights.

Options: `--source` (default `datasets`) and `--output` (default `report`).
The output must be separate from the source tree. Custom source trees must keep
the same prepared-report folder names. Packaging overwrites its named outputs
but does not delete unrelated existing files.

## Official GIS and an assumed upstream/downstream scenario

The user selected **AMS011 (Amstel at Berlage bridge)** as an assumed outlet.
This is not a claim that AMS011 is the physical outlet under all conditions.

```powershell
conda run -n play python -m pip install -r scripts\requirements-gis.txt
conda run -n play python -m unittest discover -s scripts -p "test_*.py"
conda run -n play python scripts\enrich_agv_gis.py --outlet AMS011
conda run -n play python scripts\build_nitrogen_map.py
```

The enrichment downloads official Waternet/Waterschap Amstel, Gooi en Vecht
ArcGIS layers: current primary watercourses, pumps, culverts/siphons, weirs,
fixed dams, and current water-level areas. It uses layer 2, **In werking getreden**,
of the Legger services, rather than draft layer 0. Water-level areas use layer 0.
The source service base is:

`https://services-eu1.arcgis.com/nN7Fv7YeT1qPGzBX/arcgis/rest/services/`

The exact service/layer URLs, queried fields, CRS, edit timestamps, download time,
regional bounding box, and feature counts are recorded in
`gis\provenance.json` and `gis\source\*.metadata.json`.
Public service access does not imply a verified redistribution license: the
portal license fields were empty. Confirm reuse conditions before redistributing
snapshots; attribution is Waternet / Waterschap Amstel, Gooi en Vecht.

Original downloaded GeoJSON is cached in `gis\source`; use `--refresh` to update
it explicitly. Object-ID batches are sent using POST, avoiding URL length limits,
and every returned ID is checked against the requested snapshot. No monitoring
data is uploaded. All spatial joins and routing happen locally in RD New metres.

### Direction and matching assumptions

- The primary-watercourse layer supplies **no hydraulic flow direction**.
  Pump/weir `richting` is a numeric angle with no documented hydraulic meaning,
  so it is retained as a symbol angle, not used as flow direction. Culvert invert
  elevations do not establish geometry orientation or instantaneous flow.
- Monitoring points are matched within 50 m to watercourse or culvert centrelines.
  Competing channels within 2 m of the best distance are marked ambiguous unless
  their projected points coincide. Unmatched/ambiguous points are not connected
  by invented straight-line links. Offsets over 25 m require manual review.
- **AMS011's centreline offset is about 43.2 m and requires review.** It remains
  the explicitly user-selected scenario outlet, not a confirmed hydraulic anchor.
- Network junctions require shared endpoints rounded to 1 cm. Crossings alone
  do not prove a connection. Measurements split their matched line at the
  projected location. Routes follow line geometry rather than Euclidean distance.
- Scenario direction follows decreasing shortest network distance to AMS011.
  It is an assumption, not measured discharge or a DEM-derived direction.
  Disconnected components remain unresolved. Connected points on different
  branches can lack a monotone upstream/downstream path.
- Relations identify next reachable measurement sites along each branch,
  stopping at intervening monitoring sites. The long table includes both
  upstream and downstream reciprocal rows and unresolved connections.
- Pumps, weirs and dams within 10 m of routes are flagged. Hydraulic passability
  and operating state are **not verified**; the topology represents potential
  geometric connectivity, not a calibrated hydraulic model.
- Current GIS is applied to historical sites. Neither historical network changes
  nor event-specific reversals are established. Secondary ditches and paths
  outside the bounded download may be missing. Do not use the scenario as ground
  truth for pollution-source attribution.
- One invalid water-level polygon (`7.3-3`) is repaired with `shapely.make_valid`
  for spatial membership and audited in provenance; the original snapshot is kept.
- Every time series uses fixed GMT+1 (UTC+01:00), including summer observations.
  Cleaned timestamp columns carry the offset; raw source strings are preserved.

### Enrichment outputs and map

Open `gis\report.html` for source links, counts, assumptions and file descriptions.
`measurement_network_matches.csv` retains all nitrogen monitoring sites, match
status and offset, water-level area codes, network component, and distance to the
assumed outlet. `measurement_relations.csv` / `.geojson` retain route geometry,
distance, relation classification and nearby structures. `pump_series_gis.csv`
matches the 83 flow-series IDs to official asset codes without summing variants.
Separate watercourse, pumping-station, hydraulic-structure and water-level-area
GeoJSON exports support GIS reuse.

Rebuilding the map automatically embeds the enrichment when provenance exists.
Toggle the official water network, pumps and barriers. Click or search a
monitoring point for scenario upstream/downstream neighbors and highlighted
network paths: blue toward the outlet and purple for upstream neighbors.
Arrows are explicitly labelled **scenario assumptions**. Unknown-direction
connections remain in the relationship table, not displayed as false arrows.
Full geometry stays in the GIS exports; the map embeds only downstream route
geometry (the upstream relation is reciprocal) and rounds display coordinates
to six decimal places. Analysis coordinates and original snapshots are preserved.
