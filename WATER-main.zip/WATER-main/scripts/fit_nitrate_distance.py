"""Fit an exploratory, non-Bayesian Euclidean-distance nitrate source baseline."""
from __future__ import annotations

import argparse
import html
import json
from pathlib import Path

import numpy as np
import pandas as pd
from pyproj import Transformer
from scipy.optimize import minimize
from scipy.spatial import Delaunay
from scipy.spatial.distance import cdist

from prepare_nitrogen import ROOT, parse_dates


PARAMETER = "NO3_mgN/l_nf"
COLUMNS = [
    "sample_id", "location_code", "date_time", "parameter_id", "limit_symbol",
    "reported_unit", "quality_code", "compartment", "value", "source_record_number",
]


def prepare_observations(observations: pd.DataFrame, locations: pd.DataFrame, year: int) -> pd.DataFrame:
    if locations["location_code"].duplicated().any():
        raise ValueError("Monitoring location codes must be unique.")
    frame = observations.loc[observations["parameter_id"].eq(PARAMETER)].copy()
    dates = parse_dates(frame["date_time"])
    frame = frame.loc[dates.dt.year.eq(year)].copy()
    frame["date_time"] = dates.loc[frame.index].astype(str)
    if frame.empty:
        raise ValueError(f"No nitrate observations with valid dates in {year}.")
    frame = frame.merge(locations[[
        "location_code", "location_name", "rd_x", "rd_y", "longitude", "latitude",
        "valid_rd_coordinate", "metadata_variant_count",
    ]], on="location_code", how="left", validate="many_to_one")
    frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
    symbol = frame["limit_symbol"].fillna("").str.strip()
    frame["value_kind"] = np.where(symbol.isin(["", "="]), "exact",
                                   np.where(symbol.isin(["<", "<="]), "upper_bound", "unsupported"))
    reasons = pd.Series("", index=frame.index)
    checks = [
        ("not_surface_water", frame["compartment"].eq("OW")),
        ("quality_not_zero", frame["quality_code"].astype(str).eq("0")),
        ("unexpected_unit", frame["reported_unit"].eq("mg/l")),
        ("invalid_value", np.isfinite(frame["value"]) & frame["value"].ge(0)),
        ("unsupported_qualifier", frame["value_kind"].ne("unsupported")),
        ("invalid_or_ambiguous_coordinates",
         frame["valid_rd_coordinate"].eq(True) & frame["metadata_variant_count"].eq(1)
         & np.isfinite(frame["rd_x"]) & np.isfinite(frame["rd_y"])
         & np.isfinite(frame["longitude"]) & np.isfinite(frame["latitude"])),
    ]
    for reason, valid in checks:
        reasons.loc[~valid] += reason + ";"
    frame["exclusion_reason"] = reasons.str.rstrip(";")
    frame["use_in_model"] = reasons.eq("")
    return frame


def candidate_grid(coordinates: np.ndarray, spacing: float) -> np.ndarray:
    if not np.isfinite(spacing) or spacing <= 0:
        raise ValueError("Grid spacing must be finite and positive.")
    if len(coordinates) < 3 or np.linalg.matrix_rank(coordinates - coordinates.mean(axis=0)) < 2:
        raise ValueError("The grid requires at least three non-collinear monitoring locations.")
    lower = np.floor(coordinates.min(axis=0) / spacing).astype(int)
    upper = np.ceil(coordinates.max(axis=0) / spacing).astype(int)
    if int(np.prod(upper - lower)) > 10000:
        raise ValueError("Grid exceeds 10,000 bounding-box cells; increase grid spacing.")
    xs = (np.arange(lower[0], upper[0]) + .5) * spacing
    ys = (np.arange(lower[1], upper[1]) + .5) * spacing
    x, y = np.meshgrid(xs, ys)
    points = np.column_stack([x.ravel(), y.ravel()])
    points = points[Delaunay(coordinates).find_simplex(points) >= 0]
    if not len(points):
        raise ValueError("No grid centres fall inside monitoring coverage; reduce grid spacing.")
    return points


def distance_kernel(sensors: np.ndarray, candidates: np.ndarray, decay_length: float) -> np.ndarray:
    if not np.isfinite(decay_length) or decay_length <= 0:
        raise ValueError("Decay length must be finite and positive.")
    if not np.isfinite(sensors).all() or not np.isfinite(candidates).all():
        raise ValueError("Distances require finite RD-metre coordinates.")
    return np.exp(-cdist(sensors, candidates) / decay_length)


def objective(parameters: np.ndarray, design: np.ndarray, values: np.ndarray,
              upper: np.ndarray, weights: np.ndarray, regularization: float) -> tuple[float, np.ndarray]:
    residual = design @ parameters - values
    residual = np.where(upper, np.maximum(residual, 0), residual)
    penalty = parameters.copy()
    penalty[0] = 0
    loss = np.dot(weights, residual ** 2) + regularization * np.dot(penalty, penalty)
    gradient = 2 * design.T @ (weights * residual) + 2 * regularization * penalty
    return float(loss), gradient


def fit_sources(kernel: np.ndarray, observations: pd.DataFrame, regularization: float) -> dict:
    if not np.isfinite(regularization) or regularization <= 0:
        raise ValueError("Regularization must be finite and positive.")
    if kernel.shape[0] != len(observations) or not np.isfinite(kernel).all() or (kernel < 0).any():
        raise ValueError("Kernel rows must match observations and be finite and nonnegative.")
    values = observations["value"].to_numpy(dtype=float)
    upper = observations["value_kind"].eq("upper_bound").to_numpy()
    if (not len(values) or not np.isfinite(values).all() or (values < 0).any()
            or not observations["value_kind"].isin(["exact", "upper_bound"]).all()):
        raise ValueError("Fit inputs must be valid nonnegative exact values or upper bounds.")
    if upper.all():
        raise ValueError("Upper bounds alone cannot identify source scores; exact observations are required.")
    counts = observations.groupby("location_code")["location_code"].transform("size").to_numpy()
    weights = 1 / (counts * observations["location_code"].nunique())
    design = np.column_stack([np.ones(len(values)), kernel])
    initial = np.zeros(design.shape[1])
    initial[0] = np.min(values[~upper])
    result = minimize(
        objective, initial, args=(design, values, upper, weights, regularization),
        method="L-BFGS-B", jac=True, bounds=[(0, None)] * len(initial),
        options={"maxiter": 5000, "ftol": 1e-12, "gtol": 1e-8},
    )
    if not result.success:
        raise RuntimeError(f"Distance inversion did not converge: {result.message}")
    return {"offset": float(result.x[0]), "sources": result.x[1:],
            "prediction": design @ result.x, "objective": float(result.fun),
            "iterations": int(result.nit)}


def metrics(observations: pd.DataFrame, predictions: np.ndarray) -> dict:
    exact = observations["value_kind"].eq("exact").to_numpy()
    residual = predictions - observations["value"].to_numpy(dtype=float)
    upper = ~exact
    return {
        "exact_count": int(exact.sum()), "upper_bound_count": int(upper.sum()),
        "exact_rmse_mg_n_l": float(np.sqrt(np.mean(residual[exact] ** 2))) if exact.any() else None,
        "exact_mae_mg_n_l": float(np.mean(np.abs(residual[exact]))) if exact.any() else None,
        "upper_bound_violation_rmse_mg_n_l":
            float(np.sqrt(np.mean(np.maximum(residual[upper], 0) ** 2))) if upper.any() else None,
    }


def spatial_validation(observations: pd.DataFrame, sites: pd.DataFrame, kernel: np.ndarray,
                       regularization: float) -> tuple[pd.DataFrame, dict]:
    # Hold out entire geographic quadrants, never random samples from the same site.
    mid = sites[["rd_x", "rd_y"]].median()
    folds = (sites["rd_x"].ge(mid["rd_x"]).astype(int)
             + 2 * sites["rd_y"].ge(mid["rd_y"]).astype(int))
    site_folds = pd.Series(folds.to_numpy(), index=sites["location_code"])
    row_folds = observations["location_code"].map(site_folds).to_numpy()
    if len(np.unique(row_folds)) < 2:
        raise ValueError("At least two populated geographic holdout quadrants are required.")
    result = observations.copy()
    result["spatial_fold"] = row_folds
    model_predictions = np.full(len(result), np.nan)
    offset_predictions = np.full(len(result), np.nan)
    fold_info = []
    for fold in sorted(np.unique(row_folds)):
        test = row_folds == fold
        train = ~test
        training = observations.loc[train]
        fitted = fit_sources(kernel[train], training, regularization)
        offset = fit_sources(np.empty((int(train.sum()), 0)), training, regularization)
        model_predictions[test] = fitted["offset"] + kernel[test] @ fitted["sources"]
        offset_predictions[test] = offset["offset"]
        fold_info.append({
            "fold": int(fold), "training_sites": int(training["location_code"].nunique()),
            "held_out_sites": int(observations.loc[test, "location_code"].nunique()),
            "distance_model": metrics(observations.loc[test], model_predictions[test]),
            "offset_only": metrics(observations.loc[test], offset_predictions[test]),
        })
    if not np.isfinite(model_predictions).all() or not np.isfinite(offset_predictions).all():
        raise RuntimeError("Every observation must receive a held-out prediction.")
    result["held_out_prediction_mg_n_l"] = model_predictions
    result["held_out_offset_only_mg_n_l"] = offset_predictions
    return result, {
        "method": "Geographic quadrants split at median site RD x/y; all dates at a site stay together.",
        "candidate_domain": "Fixed grid from all site coordinates, never held-out concentration values.",
        "limitations": "No buffer at quadrant boundaries; one fixed hyperparameter setting, not a tuning exercise.",
        "distance_model": metrics(observations, model_predictions),
        "offset_only": metrics(observations, offset_predictions), "folds": fold_info,
    }


def write_report(output: Path, sources: pd.DataFrame, observations: pd.DataFrame, metadata: dict) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    cloud = axes[0].scatter(sources["rd_x"] / 1000, sources["rd_y"] / 1000,
                           c=sources["relative_score"], cmap="Reds", marker="s", s=65, vmin=0, vmax=1)
    sites = observations.drop_duplicates("location_code")
    axes[0].scatter(sites["rd_x"] / 1000, sites["rd_y"] / 1000, s=5, c="black", label="Monitoring sites")
    axes[0].set(xlabel="RD east (km)", ylabel="RD north (km)", title="Distance-only candidate scores")
    axes[0].set_aspect("equal")
    axes[0].legend(fontsize=8)
    fig.colorbar(cloud, ax=axes[0], label="Coefficient / maximum coefficient (not probability)")
    exact = observations.loc[observations["value_kind"].eq("exact")]
    means = exact.groupby("location_code")[["value", "held_out_prediction_mg_n_l"]].mean()
    axes[1].scatter(means["value"], means["held_out_prediction_mg_n_l"], s=14)
    limit = float(means.max().max())
    axes[1].plot([0, limit], [0, limit], color="grey", linestyle="--")
    axes[1].set(xlabel="Observed site mean (uncensored, mg N/L)",
                ylabel="Held-out prediction (mg N/L)", title="Geographic holdout, not training fit")
    fig.tight_layout()
    fig.savefig(output / "distance_diagnostics.png", dpi=150)
    plt.close(fig)
    validation = metadata["spatial_validation"]
    model_rmse = validation["distance_model"]["exact_rmse_mg_n_l"]
    baseline_rmse = validation["offset_only"]["exact_rmse_mg_n_l"]
    verdict = ("The distance model improves held-out RMSE over the constant-only baseline."
               if model_rmse < baseline_rmse else
               "The distance model DOES NOT improve held-out RMSE over the constant-only baseline. "
               "Do not interpret the mapped scores as evidence of actual sources.")
    top = sources.sort_values("coefficient_mg_n_l", ascending=False).head(10)
    document = f"""<!doctype html><html lang="en"><meta charset="utf-8">
<title>Nitrate distance-only baseline</title>
<style>body{{font:16px system-ui;max-width:1100px;margin:32px auto;padding:16px}}
table{{border-collapse:collapse;font-size:14px}}td,th{{border:1px solid #ddd;padding:6px}}
img{{max-width:100%}}.warning{{background:#fff3cd;padding:16px}}</style>
<h1>Nitrate distance-only baseline: {metadata['year']}</h1>
<p>Fixed GMT+1, {metadata['observation_count']} results at {metadata['site_count']} sites:
{metadata['exact_count']} exact values and {metadata['upper_bound_count']} below-detection limits.</p>
<p class="warning">{html.escape(verdict)} These are statistical candidate scores, not confirmed
polluters, water-entry locations, original land sources, probabilities, credible intervals or kg N/day.</p>
<p>C = offset + sum(s[j] * exp(-straight_line_distance / {metadata['decay_length_m']:g} m)).
Nonnegative coefficients on a {metadata['grid_spacing_m']:g} m grid inside the monitoring-site convex hull.
L2 regularization = {metadata['regularization']:g}. The constant offset is fitted, not measured upstream background.</p>
<p>Each site has equal total fitting weight. Exact values use squared residuals. Below-detection
results only penalize predictions above the reported limit: max(prediction - limit, 0)^2.
This is a soft inequality, not a censored likelihood. No zero or limit/2 substitution is used.
The map's measured concentration markers still use uncensored medians; the model uses individual
results and limits, so the two are not the same statistic.</p>
<p>The response is constant over the analysis year. Source timestamps are retained for quarterly
held-out residual diagnostics; seasonal transport is not fitted. All physical directions, water
connectivity, pumping, dilution, reactions, source inventories and Bayesian priors are omitted.
Distance decay, grid resolution and regularization are explicit uncalibrated baseline choices.
Grid centres represent candidate cells, not independently identifiable real-world sources.</p>
<p>Held-out exact-result RMSE: distance {model_rmse:.4f}, constant-only {baseline_rmse:.4f} mg N/L.
The held-out values were not used to fit either model. No hyperparameter search was performed.</p>
<img src="distance_diagnostics.png" alt="Candidate scores and geographic holdout predictions">
<h2>Highest fitted candidate coefficients</h2>{top.to_html(index=False, float_format=lambda x: f'{x:.5g}')}
<p>Relative score is the coefficient divided by the largest coefficient, not a probability.
Coefficients have concentration-amplitude units for this arbitrary kernel, not emission-rate units.
Ridge regularization tends to spread correlated scores; individual cell rankings can be unstable.</p>
<p><a href="../nitrogen_source_analysis/nitrogen_map.html?model=distance">Interactive measurement map with model overlay</a>
 | <a href="candidate_sources.geojson">Candidate GeoJSON</a>
 | <a href="model_metadata.json">Full assumptions and validation</a>
 | <a href="observations_with_predictions.csv">Audited observations and predictions</a>
 | <a href="seasonal_diagnostics.csv">Quarterly held-out diagnostics</a></p></html>"""
    (output / "report.html").write_text(document, encoding="utf-8")


def run(data_dir: Path, output: Path, year: int = 2024, spacing: float = 2000,
        decay_length: float = 2000, regularization: float = .01) -> dict:
    chunks = []
    for chunk in pd.read_csv(data_dir / "nitrogen_observations.csv", usecols=COLUMNS,
                             dtype=str, keep_default_na=False, chunksize=100000):
        chunks.append(chunk.loc[chunk["parameter_id"].eq(PARAMETER)])
    nitrate = pd.concat(chunks, ignore_index=True)
    locations = pd.read_csv(data_dir / "monitoring_locations.csv", dtype={"location_code": str})
    audited = prepare_observations(nitrate, locations, year)
    observations = audited.loc[audited["use_in_model"]].copy().reset_index(drop=True)
    sites = observations[["location_code", "rd_x", "rd_y"]].drop_duplicates("location_code").reset_index(drop=True)
    candidates = candidate_grid(sites[["rd_x", "rd_y"]].to_numpy(dtype=float), spacing)
    site_kernel = distance_kernel(sites[["rd_x", "rd_y"]].to_numpy(dtype=float), candidates, decay_length)
    site_index = pd.Series(np.arange(len(sites)), index=sites["location_code"])
    kernel = site_kernel[observations["location_code"].map(site_index).to_numpy()]
    fitted = fit_sources(kernel, observations, regularization)
    predictions, validation = spatial_validation(observations, sites, kernel, regularization)
    predictions["fitted_prediction_mg_n_l"] = fitted["prediction"]
    predictions["exact_residual_mg_n_l"] = np.where(
        predictions["value_kind"].eq("exact"), fitted["prediction"] - predictions["value"], np.nan)
    predictions["upper_bound_violation_mg_n_l"] = np.where(
        predictions["value_kind"].eq("upper_bound"),
        np.maximum(fitted["prediction"] - predictions["value"], 0), np.nan)
    transform = Transformer.from_crs(28992, 4326, always_xy=True)
    lon, lat = transform.transform(candidates[:, 0], candidates[:, 1])
    coefficients = fitted["sources"]
    maximum = float(coefficients.max())
    sources = pd.DataFrame({
        "candidate_id": [f"GRID{i:04d}" for i in range(len(candidates))],
        "rd_x": candidates[:, 0], "rd_y": candidates[:, 1], "longitude": lon, "latitude": lat,
        "coefficient_mg_n_l": coefficients,
        "relative_score": coefficients / maximum if maximum > 0 else np.zeros(len(coefficients)),
    })
    metadata = {
        "model": "Nonnegative regularized exponential Euclidean-distance inversion",
        "parameter_id": PARAMETER, "unit": "mg N/L", "year": year,
        "start": f"{year}-01-01", "end": f"{year}-12-31", "time_zone": "UTC+01:00, fixed; no DST",
        "coordinate_crs": "EPSG:28992 (assumed RD New), distances in metres",
        "grid_spacing_m": spacing, "decay_length_m": decay_length, "regularization": regularization,
        "candidate_domain": "Grid centres inside convex hull of usable monitoring coordinates; no water or land routing.",
        "kernel": "A[i,j] = exp(-Euclidean_RD_distance(i,j) / decay_length_m)",
        "objective": "mean_over_sites(mean_over_results(exact_residual^2 or max(prediction-limit,0)^2)) + lambda*sum(s^2)",
        "offset": "Nonnegative unpenalized constant; not a measured upstream/background concentration.",
        "offset_mg_n_l": fitted["offset"], "candidate_count": len(candidates),
        "site_count": len(sites), "observation_count": len(observations),
        "exact_count": int(observations["value_kind"].eq("exact").sum()),
        "upper_bound_count": int(observations["value_kind"].eq("upper_bound").sum()),
        "excluded_in_year": audited.loc[~audited["use_in_model"], "exclusion_reason"].value_counts().to_dict(),
        "nitrate_rows_with_invalid_dates_all_years": int(parse_dates(nitrate["date_time"]).isna().sum()),
        "duplicate_sample_key_rows_retained": int(observations.duplicated(["sample_id", "location_code", "date_time"], keep=False).sum()),
        "fitting_weights": "Each site has equal total weight; laboratory records are retained, not deduplicated.",
        "censoring": "Reported < or <= limits are soft upper bounds, not exact readings, zeros or limit/2.",
        "quality_filter": "Surface water OW, quality code 0 (exploratory taxonomy), reported unit mg/l for nitrate-N.",
        "uncertainty": "None estimated; not Bayesian. Relative scores are not probabilities.",
        "physical_limitations": "No connectivity/direction, pump routing, reactions, dilution, land attribution or source-load calibration.",
        "identifiability": "Fixed arbitrary grid/decay/regularization; correlated candidate cells need not be separately identifiable.",
        "solver": {"method": "L-BFGS-B, analytic gradient, nonnegative bounds",
                   "objective": fitted["objective"], "iterations": fitted["iterations"]},
        "training_metrics": metrics(observations, fitted["prediction"]), "spatial_validation": validation,
        "input_files": [str(data_dir / "nitrogen_observations.csv"), str(data_dir / "monitoring_locations.csv")],
    }
    features = [{
        "type": "Feature", "geometry": {"type": "Point", "coordinates": [float(row.longitude), float(row.latitude)]},
        "properties": {"candidate_id": row.candidate_id, "coefficient_mg_n_l": float(row.coefficient_mg_n_l),
                       "relative_score": float(row.relative_score), "grid_spacing_m": spacing},
    } for row in sources.itertuples(index=False)]
    geojson = {"type": "FeatureCollection", "features": features}
    map_data = {"start": metadata["start"], "end": metadata["end"], "parameter": PARAMETER,
                "gridSpacing": spacing, "decayLength": decay_length, "sources": geojson,
                "validationImproved": validation["distance_model"]["exact_rmse_mg_n_l"]
                < validation["offset_only"]["exact_rmse_mg_n_l"]}
    output.mkdir(parents=True, exist_ok=True)
    sources.to_csv(output / "candidate_sources.csv", index=False)
    predictions.to_csv(output / "observations_with_predictions.csv", index=False)
    audited.loc[~audited["use_in_model"]].to_csv(output / "excluded_observations.csv", index=False)
    for filename, data in [("candidate_sources.geojson", geojson), ("model_metadata.json", metadata),
                           ("model_map.json", map_data)]:
        (output / filename).write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    quarters = parse_dates(predictions["date_time"]).dt.quarter
    seasonal = [{"quarter": int(quarter), **metrics(group, group["held_out_prediction_mg_n_l"].to_numpy())}
                for quarter, group in predictions.groupby(quarters)]
    pd.DataFrame(seasonal).to_csv(output / "seasonal_diagnostics.csv", index=False)
    write_report(output, sources, predictions, metadata)
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "datasets" / "nitrogen_source_analysis")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--year", type=int, default=2024)
    parser.add_argument("--grid-spacing-m", type=float, default=2000)
    parser.add_argument("--decay-length-m", type=float, default=2000)
    parser.add_argument("--regularization", type=float, default=.01)
    args = parser.parse_args()
    output = args.output or ROOT / "datasets" / f"nitrate_distance_baseline_{args.year}"
    metadata = run(args.data_dir.resolve(), output.resolve(), args.year, args.grid_spacing_m,
                   args.decay_length_m, args.regularization)
    print(json.dumps({key: metadata[key] for key in [
        "site_count", "observation_count", "exact_count", "upper_bound_count", "candidate_count",
        "offset_mg_n_l", "training_metrics", "spatial_validation",
    ]}, indent=2))
    print(f"Report: {output.resolve() / 'report.html'}")


if __name__ == "__main__":
    main()
