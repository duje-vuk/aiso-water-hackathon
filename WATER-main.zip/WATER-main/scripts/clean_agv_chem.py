"""Clean AGV FYCHEM chemistry: extract nitrogen parameters, translate to English,
build a locations table with WGS84 coordinates.

Input : datasets/AGV/FYCHEM_alleParamtrs_alleJaren_Amstelland_1900tmjuni.csv (740 MB, 2.1M rows)
Output: datasets/clean/nitrogen_chemistry_long.csv
        datasets/clean/locations.csv
"""
import pandas as pd
from pyproj import Transformer

SRC = r"datasets/AGV/FYCHEM_alleParamtrs_alleJaren_Amstelland_1900tmjuni.csv"
OUT_CHEM = r"datasets/clean/nitrogen_chemistry_long.csv"
OUT_LOC = r"datasets/clean/locations.csv"

# Nitrogen parameters (FEWS parameter id -> English name)
N_PARAMS = {
    "Ntot_mgN/l":        "total nitrogen",
    "NKj_mgN/l":         "Kjeldahl nitrogen",
    "NO3_mgN/l_nf":      "nitrate (filtered)",
    "NO2_mgN/l_nf":      "nitrite (filtered)",
    "NH4_mgN/l_nf":      "ammonium (filtered)",
    "NH3_mgN/l_nf":      "ammonia (filtered)",
    "sNO3NO2_mgN/l_nf":  "nitrate + nitrite (filtered)",
}

COLS = ["monsterident", "locatiecode", "locatie omschrijving", "locatie x", "locatie y",
        "locatie KRW watertype", "locatie EAG", "compartiment", "datum",
        "fewsparameter", "limietsymbool", "meetwaarde", "eenheid", "kwaliteitsoordeelcode"]

RENAME = {
    "monsterident": "sample_id",
    "locatiecode": "location_code",
    "locatie omschrijving": "location_name",
    "locatie x": "rd_x",
    "locatie y": "rd_y",
    "locatie KRW watertype": "krw_water_type",
    "locatie EAG": "eag_area",
    "compartiment": "compartment",
    "datum": "date_time",
    "fewsparameter": "parameter_id",
    "limietsymbool": "limit_symbol",
    "meetwaarde": "value",
    "eenheid": "unit",
    "kwaliteitsoordeelcode": "quality_code",
}

chunks, locations = [], {}
compartments = set()

for ch in pd.read_csv(SRC, usecols=COLS, dtype=str, chunksize=400_000):
    # collect location metadata from every row
    meta = ch[["locatiecode", "locatie omschrijving", "locatie x", "locatie y",
               "locatie KRW watertype", "locatie EAG"]].drop_duplicates("locatiecode")
    for r in meta.itertuples(index=False):
        locations.setdefault(r[0], r[1:])
    compartments.update(ch["compartiment"].dropna().unique())
    sub = ch[ch["fewsparameter"].isin(N_PARAMS)]
    if len(sub):
        chunks.append(sub)

chem = pd.concat(chunks, ignore_index=True).rename(columns=RENAME)
chem["parameter_en"] = chem["parameter_id"].map(N_PARAMS)
chem["value"] = pd.to_numeric(chem["value"], errors="coerce")
chem["date_time"] = pd.to_datetime(chem["date_time"], errors="coerce")
chem = chem.sort_values(["location_code", "date_time", "parameter_id"])
chem.to_csv(OUT_CHEM, index=False)

print("compartments found:", sorted(compartments))
print("nitrogen rows:", len(chem), "| locations with N data:", chem["location_code"].nunique())
print("date range:", chem["date_time"].min(), "->", chem["date_time"].max())
print(chem.groupby("parameter_en")["value"].agg(["count", "median"]).to_string())

# --- locations table with lat/lon (RD New EPSG:28992 -> WGS84) ---
loc = pd.DataFrame([(k,) + tuple(v) for k, v in locations.items()],
                   columns=["location_code", "location_name", "rd_x", "rd_y",
                            "krw_water_type", "eag_area"])
loc["rd_x"] = pd.to_numeric(loc["rd_x"], errors="coerce")
loc["rd_y"] = pd.to_numeric(loc["rd_y"], errors="coerce")
tr = Transformer.from_crs("EPSG:28992", "EPSG:4326", always_xy=True)
ok = loc["rd_x"].notna() & loc["rd_y"].notna()
lon, lat = tr.transform(loc.loc[ok, "rd_x"].values, loc.loc[ok, "rd_y"].values)
loc.loc[ok, "longitude"] = lon
loc.loc[ok, "latitude"] = lat
loc["has_nitrogen_data"] = loc["location_code"].isin(chem["location_code"].unique())
loc = loc.sort_values("location_code")
loc.to_csv(OUT_LOC, index=False)
print("locations:", len(loc), "| with coords:", int(ok.sum()),
      "| with N data:", int(loc["has_nitrogen_data"].sum()))
