"""Collect existing AGV reports and their local dependencies into a portable report folder."""
from __future__ import annotations

import argparse
from collections import deque
from datetime import datetime, timezone
import hashlib
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
from urllib.parse import unquote, urlsplit

import pandas as pd

from build_nitrogen_map import ASSETS
from prepare_nitrogen import ROOT


REPORTS = [
    ("Data preparation and catalogue", "nitrogen_source_analysis", "report.html",
     "Source-table overview, nitrogen cleaning, data coverage and exploratory plots."),
    ("GIS and assumed connectivity", "nitrogen_source_analysis", Path("gis") / "report.html",
     "Official GIS provenance, conservative matching and the hypothetical AMS011 outlet scenario."),
    ("Annual straight-line baseline", "nitrate_distance_baseline_2024", "report.html",
     "Original 224-site distance-only analysis; preserved unchanged."),
    ("Annual water-connectivity comparison", "nitrate_network_distance_2024", "report.html",
     "Undirected network distance versus straight-line distance on identical matched support."),
    ("Daily models and geographic maps", "nitrate_daily_2024", "report.html",
     "Independent daily fits, date filters, coverage gates and annual-baseline comparisons."),
]


class AssetLinks(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.links.extend(value for key, value in attrs if key in {"href", "src"} and value)


def local_reference(parent: Path, url: str, root: Path) -> Path | None:
    parts = urlsplit(url)
    if parts.scheme in {"http", "https", "data", "mailto", "about", "tel", "javascript"} or (
        not parts.scheme and parts.netloc
    ):
        return None
    if parts.scheme or parts.path.startswith(("/", "\\")):
        raise ValueError(f"Nonportable absolute local reference in {parent.name}: {url}")
    if not parts.path:
        return None
    target = (parent.parent / unquote(parts.path)).resolve()
    if not target.is_relative_to(root.resolve()):
        raise ValueError(f"Report reference escapes the report source tree: {url}")
    if not target.is_file():
        raise FileNotFoundError(f"Missing report dependency: {parent} -> {url}")
    return target


def references(path: Path) -> list[str]:
    if path.suffix.lower() in {".html", ".htm"}:
        parser = AssetLinks()
        parser.feed(path.read_text(encoding="utf-8"))
        return parser.links
    if path.suffix.lower() == ".css":
        return re.findall(r"url\(\s*['\"]?([^'\"\)\s]+)", path.read_text(encoding="utf-8"))
    return []


def collect_files(source: Path, seeds: list[Path]) -> list[Path]:
    queue, seen = deque(path.resolve() for path in seeds), set()
    while queue:
        path = queue.popleft()
        if path in seen:
            continue
        if not path.is_relative_to(source.resolve()) or not path.is_file():
            raise FileNotFoundError(f"Missing or out-of-tree report input: {path}")
        if path.relative_to(source.resolve()).parts[0] not in {entry[1] for entry in REPORTS}:
            raise ValueError("Only prepared report directories may be copied; original tables are excluded.")
        seen.add(path)
        for url in references(path):
            target = local_reference(path, url, source)
            if target is not None:
                queue.append(target)
    return sorted(seen)


def validate_bundle(output: Path, paths: list[str]) -> int:
    count = 0
    for relative in paths:
        path = output / relative
        for url in references(path):
            if local_reference(path, url, output) is not None:
                count += 1
    return count


def build(source: Path, output: Path) -> dict:
    source, output = source.resolve(), output.resolve()
    if source == output or source.is_relative_to(output) or output.is_relative_to(source):
        raise ValueError("The portable report folder must be separate from the source dataset tree.")
    seeds = [source / directory / filename for _, directory, filename, _ in REPORTS]
    seeds += [
        source / "nitrogen_source_analysis" / "nitrogen_map_data.json",
    ]
    seeds += [source / "nitrogen_source_analysis" / "vendor" / "leaflet" / name for name in ASSETS]
    files = collect_files(source, seeds)
    output.mkdir(parents=True, exist_ok=True)
    records = []
    for path in files:
        relative = path.relative_to(source)
        target = output / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        records.append({"path": relative.as_posix(), "bytes": target.stat().st_size,
                        "sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
    daily = json.loads((source / "nitrate_daily_2024" / "model_metadata.json").read_text())
    comparison = pd.read_csv(source / "nitrate_daily_2024" / "comparison.csv")
    copied = {record["path"] for record in records}
    bootstrap = "Included: bootstrap stability, not source probability." if (
        "nitrate_daily_2024/bootstrap_metadata.json" in copied) else (
        "Not computed: bootstrap was skipped. No confidence probabilities are claimed.")
    cards = "\n".join(
        f'<section><h2><a href="{html.escape((Path(directory) / filename).as_posix())}">'
        f'{html.escape(title)}</a></h2><p>{html.escape(description)}</p></section>'
        for title, directory, filename, description in REPORTS)
    total_bytes = sum(record["bytes"] for record in records)
    index = f"""<!doctype html><html lang="en"><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Amstel nitrate analysis - consolidated reports</title>
<style>body{{font:16px system-ui;max-width:1150px;margin:32px auto;padding:16px;color:#172033}}
h1{{color:#164e63}}section{{padding:8px 18px;margin:14px 0;border:1px solid #cbd5e1;border-radius:8px}}
h2{{font-size:1.15rem}}table{{border-collapse:collapse;font-size:14px}}td,th{{border:1px solid #ddd;padding:7px}}
.warning{{background:#fff3cd;padding:16px}}a{{color:#075985}}</style>
<h1>Amstel nitrate analysis: consolidated reports</h1>
<p>One portable folder containing preparation, GIS, annual-model and daily-model reports,
their local map libraries, figures and linked downloads. Open this page directly; no Python
environment, repository checkout or local server is required to read the reports.</p>
<p><a href="nitrate_daily_2024/report.html">Open daily report with geographic maps</a>
 | <a href="nitrogen_source_analysis/nitrogen_map.html?model=daily-network">Open full daily map</a></p>
<p class="warning">{html.escape(bootstrap)} Source amplitudes and normalized scores are not
confidence scores, source probabilities or pollution loads. These are exploratory inversions,
not confirmed pollution-source locations.</p>
{cards}
<h2>Daily versus annual: identical supported holdout observations</h2>
{comparison.to_html(index=False, na_rep="not available", float_format=lambda value: f'{value:.5g}')}
<p>RMSE/MAE units: mg N/L. {daily['evaluated_observation_count']} shared held-out results
({daily['evaluated_exact_count']} exact results and {daily['evaluated_upper_bound_count']} limits)
across {daily['evaluated_day_count']} dates. These are not full-year performance estimates.
The original annual reports also contain broader-coverage metrics that must not be compared
directly against this selected daily subset.</p>
<p>Daily calendar: {daily['fitted_day_count']} fitted days,
{daily['insufficient_day_count']} insufficient-data days, {daily['no_data_day_count']} days
without matched observations. Measurement times use fixed GMT+1 without DST.</p>
<h2>Portability, privacy and limitations</h2>
<ul><li>Move or copy this entire folder, keeping its internal layout. Do not copy just one HTML file.</li>
<li>Reports, measurements, filters and local map assets work without a server. Background PDOK
tiles require internet; offline, points remain available with an explicit tile warning.</li>
<li>No measurement values or searches are uploaded. Basemap requests reveal the viewed tile area.</li>
<li>Original multi-gigabyte AGV tables are excluded; only report-linked downloads and map assets
are included. Original input paths in metadata remain provenance text, not runtime dependencies.</li>
<li>Water-network topology, hydraulic passability and historical flow direction remain unverified.</li>
<li>Attribution: Waternet/Waterschap Amstel, Gooi en Vecht; Kadaster/PDOK; Leaflet.
Confirm data redistribution rights before publishing or sharing externally.</li></ul>
<p>{len(records)} source assets, {total_bytes / 1048576:.1f} MiB.
See <a href="manifest.json">manifest.json</a> for relative paths and SHA-256 checksums.</p></html>"""
    (output / "index.html").write_text(index, encoding="utf-8")
    manifest = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(), "entry_point": "index.html",
        "bootstrap": bootstrap, "raw_agv_tables_included": False,
        "external_runtime_dependency": "Optional PDOK background tiles; data and map controls stay local.",
        "files": records, "source_asset_bytes": total_bytes,
    }
    (output / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    count = validate_bundle(output, [record["path"] for record in records] + ["index.html"])
    print(f"Validated {count} local references across {len(records)} bundled assets.")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=ROOT / "datasets")
    parser.add_argument("--output", type=Path, default=ROOT / "report")
    args = parser.parse_args()
    manifest = build(args.source, args.output)
    print(f"Portable report: {args.output.resolve() / 'index.html'}")
    print(f"Bundled size: {manifest['source_asset_bytes'] / 1048576:.1f} MiB")


if __name__ == "__main__":
    main()
