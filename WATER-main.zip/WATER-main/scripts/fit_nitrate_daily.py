"""Independent daily nitrate inversions with like-for-like annual-baseline comparisons."""
from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path

import numpy as np
import pandas as pd

from fit_nitrate_distance import PARAMETER, fit_sources, metrics
from prepare_nitrogen import ROOT, parse_dates


ANNUAL_COLUMNS = {
    "network": "held_out_prediction_mg_n_l",
    "euclidean": "euclidean_held_out_prediction_mg_n_l",
    "offset": "held_out_offset_only_mg_n_l",
}


def support(frame: pd.DataFrame, minimum_sites: int, minimum_exact_sites: int) -> dict:
    sites = int(frame["location_code"].nunique())
    exact_sites = int(frame.loc[frame["value_kind"].eq("exact"), "location_code"].nunique())
    return {"siteCount": sites, "exactSiteCount": exact_sites,
            "sampleCount": len(frame), "exactCount": int(frame["value_kind"].eq("exact").sum()),
            "upperBoundCount": int(frame["value_kind"].eq("upper_bound").sum()),
            "supported": sites >= minimum_sites and exact_sites >= minimum_exact_sites}


def comparison_rows(frame: pd.DataFrame) -> list[dict]:
    rows = []
    for model in ["network", "euclidean", "offset"]:
        for period in ["daily", "annual"]:
            column = f"{period}_{model}_held_out_mg_n_l"
            rows.append({"model": f"{period}_{model}",
                         **metrics(frame, frame[column].to_numpy(dtype=float))})
    return rows


def fit_daily_slots(observations: pd.DataFrame, kernels: dict[str, np.ndarray],
                    start: str, end: str, regularization: float,
                    minimum_sites: int = 10, minimum_exact_sites: int = 3) -> tuple:
    if (not isinstance(minimum_sites, (int, np.integer)) or not isinstance(minimum_exact_sites, (int, np.integer))
            or minimum_sites < 3 or minimum_exact_sites < 2 or minimum_exact_sites > minimum_sites):
        raise ValueError("Support screening requires at least 3 sites and 2 exact sites, with exact <= total.")
    if not np.isfinite(regularization) or regularization <= 0 or pd.Timestamp(start) > pd.Timestamp(end):
        raise ValueError("Regularization must be finite and positive, and the calendar must be ordered.")
    if set(kernels) != {"network", "euclidean"} or any(
            kernel.ndim != 2 or kernel.shape[0] != len(observations)
            or not np.isfinite(kernel).all() or (kernel < 0).any() for kernel in kernels.values()):
        raise ValueError("Both distance kernels must have one row per observation.")
    if kernels["network"].shape != kernels["euclidean"].shape:
        raise ValueError("Daily kernels must use identical candidate support.")
    result = observations.copy().reset_index(drop=True)
    if not result["value_kind"].isin(["exact", "upper_bound"]).all():
        raise ValueError("Daily input must contain only eligible exact results or upper bounds.")
    dates = parse_dates(result["date_time"])
    if dates.isna().any() or not dates.dt.strftime("%Y-%m-%d").between(start, end).all():
        raise ValueError("Every observation must have a valid date inside the daily analysis period.")
    if result["spatial_fold"].isna().any() or result.groupby("location_code")["spatial_fold"].nunique().gt(1).any():
        raise ValueError("Each monitoring site must belong to exactly one annual spatial holdout fold.")
    result["slot_date"] = dates.dt.strftime("%Y-%m-%d")
    for model, column in ANNUAL_COLUMNS.items():
        values = pd.to_numeric(result[column], errors="coerce")
        if not np.isfinite(values).all() or values.lt(0).any():
            raise ValueError("Annual comparison predictions must be finite and nonnegative.")
        result[f"annual_{model}_held_out_mg_n_l"] = values
        result[f"daily_{model}_held_out_mg_n_l"] = np.nan
    for model in kernels:
        result[f"daily_{model}_fitted_mg_n_l"] = np.nan
    result["daily_fit_status"] = "insufficient_data"
    result["daily_cv_status"] = "no_daily_fit"
    days, fold_rows = {}, []
    for timestamp in pd.date_range(start, end, freq="D"):
        day = timestamp.strftime("%Y-%m-%d")
        mask = result["slot_date"].eq(day).to_numpy()
        group = result.loc[mask]
        coverage = support(group, minimum_sites, minimum_exact_sites)
        status = "fitted" if coverage["supported"] else ("no_data" if group.empty else "insufficient_data")
        entry = {"date": day, "status": status, **coverage,
                 "includedSites": sorted(group["location_code"].unique().tolist()),
                 "fits": None, "validation": None, "cvObservationCount": 0}
        days[day] = entry
        if status != "fitted":
            continue
        result.loc[mask, "daily_fit_status"] = "fitted"
        entry["fits"] = {}
        for model, kernel in kernels.items():
            fitted = fit_sources(kernel[mask], group, regularization)
            entry["fits"][model] = {
                "coefficients": fitted["sources"].tolist(), "offset_mg_n_l": fitted["offset"],
                "objective": fitted["objective"], "iterations": fitted["iterations"],
            }
            result.loc[mask, f"daily_{model}_fitted_mg_n_l"] = fitted["prediction"]
        for fold in sorted(group["spatial_fold"].unique()):
            test = mask & result["spatial_fold"].eq(fold).to_numpy()
            train = mask & ~result["spatial_fold"].eq(fold).to_numpy()
            training = result.loc[train]
            coverage = support(training, minimum_sites, minimum_exact_sites)
            valid = coverage["supported"]
            fold_rows.append({
                "slot_date": day, "fold": int(fold), "training_sites": coverage["siteCount"],
                "training_exact_sites": coverage["exactSiteCount"], "held_out_rows": int(test.sum()),
                "status": "evaluated" if valid else "insufficient_training_data",
            })
            if not valid:
                result.loc[test, "daily_cv_status"] = "insufficient_training_data"
                continue
            for model, kernel in kernels.items():
                fitted = fit_sources(kernel[train], training, regularization)
                result.loc[test, f"daily_{model}_held_out_mg_n_l"] = (
                    fitted["offset"] + kernel[test] @ fitted["sources"])
            offset = fit_sources(np.empty((int(train.sum()), 0)), training, regularization)
            result.loc[test, "daily_offset_held_out_mg_n_l"] = offset["offset"]
            result.loc[test, "daily_cv_status"] = "evaluated"
        evaluated = result.loc[mask & result["daily_cv_status"].eq("evaluated").to_numpy()]
        entry["cvObservationCount"] = len(evaluated)
        if not evaluated.empty:
            entry["validation"] = {row["model"]: row for row in comparison_rows(evaluated)}
    evaluated = result.loc[result["daily_cv_status"].eq("evaluated")]
    comparisons = pd.DataFrame(comparison_rows(evaluated))
    folds = pd.DataFrame(fold_rows, columns=[
        "slot_date", "fold", "training_sites", "training_exact_sites", "held_out_rows", "status",
    ])
    return days, result, folds, comparisons


def write_report(output: Path, summary: pd.DataFrame, comparison: pd.DataFrame, metadata: dict) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axis = plt.subplots(figsize=(12, 3.5))
    axis.plot(pd.to_datetime(summary["date"]), summary["siteCount"], label="Sampled matched sites")
    axis.axhline(metadata["minimum_sites"], color="grey", linestyle="--", label="Minimum-site screen")
    axis.set(xlabel="Daily slot (fixed GMT+1)", ylabel="Distinct sites", title="Daily evidence coverage")
    axis.legend()
    fig.tight_layout()
    fig.savefig(output / "daily_coverage.png", dpi=150)
    plt.close(fig)
    daily = json.loads((output / "model_map.json").read_text())
    stability_path = output / "stability_map.json"
    stability = json.loads(stability_path.read_text()) if stability_path.exists() else None
    ready = stability is not None and (
        stability["dailyModelMapSha256"] == hashlib.sha256((output / "model_map.json").read_bytes()).hexdigest()
        and stability["dailyObservationsSha256"] == hashlib.sha256(
            (output / "observations_with_predictions.csv").read_bytes()).hexdigest())
    report_data = {
        "start": daily["start"], "end": daily["end"], "defaultDate": daily["defaultDate"],
        "mapPath": "../nitrogen_source_analysis/nitrogen_map.html", "bootstrapReady": ready,
        "days": {day: {key: entry[key] for key in ["status", "siteCount", "exactCount", "upperBoundCount"]}
                 for day, entry in daily["days"].items()},
        "stabilityDays": {day: {key: entry[key] for key in ["status", "validReplicates", "attemptedReplicates"]}
                          for day, entry in stability["days"].items()} if ready else {
            day: {"status": "not_computed" if stability is None else "stale_estimates",
                  "validReplicates": 0, "attemptedReplicates": 0} for day in daily["days"]},
    }
    report_json = json.dumps(report_data, ensure_ascii=True, allow_nan=False).replace("<", "\\u003c")
    report_script = (Path(__file__).parent / "daily_report.js").read_text(encoding="utf-8")
    bootstrap_text = (
        f"{stability['replicates']} paired site-bootstrap draws per fitted day. "
        f"Hotspots are the top {100 * stability['hotspotFraction']:g}% of candidate coefficients "
        "(cutoff ties included; numerical zeros excluded). "
        "Selection frequency is conditional on valid draws; all-censored draws are rejected and counted. "
        "At least 80% of attempted draws must be valid. Candidate points represent coarse grid cells "
        "per connected component, not independently identified physical sources. Popup amplitude ranges "
        "are 2.5-97.5 bootstrap percentiles, not calibrated confidence or Bayesian intervals."
        if ready else "Bootstrap estimates are not computed or are stale. Bootstrap computation was "
        "skipped for this report refresh. No substitute confidence estimates are displayed.")
    bootstrap_downloads = (
        ' | <a href="bootstrap_stability.csv">Bootstrap frequencies and percentile ranges</a>'
        ' | <a href="bootstrap_metadata.json">Bootstrap method and limitations</a>' if ready else "")
    document = f"""<!doctype html><html lang="en"><meta charset="utf-8">
<title>Daily nitrate source models</title><style>body{{font:16px system-ui;max-width:1450px;margin:32px auto;padding:16px}}
table{{border-collapse:collapse;font-size:14px}}td,th{{border:1px solid #ddd;padding:6px}}
img{{max-width:100%}}.warning{{padding:16px;background:#fff3cd}}
.map-grid{{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}}
iframe{{width:100%;height:650px;border:1px solid #ccc;border-radius:6px}}
.map-controls{{display:flex;gap:12px;align-items:center;flex-wrap:wrap}}
button,input,select{{font:inherit;padding:6px}}#reportError{{color:#991b1b}}
@media(max-width:950px){{.map-grid{{grid-template-columns:1fr}}}}</style>
<h1>Independent daily nitrate source models: {metadata['start']} to {metadata['end']}</h1>
<p>Fixed GMT+1, 24-hour calendar slots. Individual measurements and detection limits are
retained; no monthly/seasonal averages, interpolation, temporal smoothing or annual-map fallback.</p>
<p>{metadata['day_count']} days: {metadata['fitted_day_count']} fitted,
{metadata['insufficient_day_count']} with insufficient data, {metadata['no_data_day_count']} with no matched data.</p>
<p class="warning">At least {metadata['minimum_sites']} distinct matched sites and
{metadata['minimum_exact_sites']} sites with exact results are required to fit a day.
This is a declared screening heuristic, NOT proof of source identifiability or confidence.
There are {metadata['candidate_count']} candidates, often far more than sampled sites.
Scores are exploratory and are NOT source probabilities or emission rates.</p>
<h2>Daily geographic and bootstrap-stability maps</h2>
<div class="map-controls">
<label>Distance model <select id="reportMetric"><option value="network">Water connectivity</option>
<option value="euclidean">Straight-line (same matched sites)</option></select></label>
<button id="reportPrevious" type="button" aria-label="Previous calendar day">&larr;</button>
<label>Day (GMT+1) <input id="reportDay" type="date"></label>
<button id="reportNext" type="button" aria-label="Next calendar day">&rarr;</button>
</div><p id="reportError" role="alert"></p><p id="reportMapStatus" role="status" aria-live="polite"></p>
<div class="map-grid">
<section><h3>Geographic map: fitted source scores</h3>
<iframe id="geoMap" title="Daily geographic source-score map"
src="../nitrogen_source_analysis/nitrogen_map.html?model=daily-network&amp;embedded=1"></iframe>
<p><a id="geoFullLink" href="../nitrogen_source_analysis/nitrogen_map.html?model=daily-network">Open full geographic map</a></p></section>
<section><h3>Confidence view: bootstrap hotspot stability</h3>
<p id="bootstrapMissing" class="warning">No fresh bootstrap estimates available. No confidence layer is substituted.</p>
<iframe id="stabilityMap" title="Daily bootstrap hotspot-stability map" {'hidden' if not ready else ''}
src="{'../nitrogen_source_analysis/nitrogen_map.html?model=daily-network&amp;view=stability&amp;embedded=1' if ready else 'about:blank'}"></iframe>
<p><a id="stabilityFullLink" href="../nitrogen_source_analysis/nitrogen_map.html?model=daily-network&amp;view=stability">Open full stability map</a></p></section>
</div><p>{html.escape(bootstrap_text)}</p>
<p class="warning">The confidence view measures ranking stability under resampling of the observed sites.
It is NOT the probability that a real pollution source exists. Fixed routing, grid, regularization,
measurement values and unverified hydraulic assumptions can produce stable but incorrect hotspots.
Grey points on the stability map are monitoring locations, not inferred sources.
Public PDOK background tiles require internet; measurements and calculations remain local.</p>
<h2>Like-for-like spatial holdout comparison (mg N/L)</h2>
{comparison.to_html(index=False, na_rep="not available", float_format=lambda x: f'{x:.5g}')}
<p>All six rows are evaluated on exactly the same {metadata['evaluated_observation_count']} results
across {metadata['evaluated_day_count']} dates
({metadata['evaluated_exact_count']} exact, {metadata['evaluated_upper_bound_count']} limits).
Rows lacking sufficient same-day training coverage are excluded from ALL comparison rows,
and are explicitly audited. Coverage selection is not evidence that these days are representative.</p>
<p>All dates at each held-out monitoring site are excluded from annual training. Daily training
uses only other sites sampled on the SAME date, with the same support screen applied to
training data alone. Annual references are the preserved geographic-holdout predictions,
not the annual full-fit predictions. This is retrospective spatial validation, not forecasting.</p>
<p>Daily straight-line and connectivity models both use the same
{metadata['site_count']} network-matched sites, {metadata['candidate_count']} on-network
candidates, site folds, distance decay and regularization as the annual matched comparison.
The original all-site straight-line baseline is preserved but is not mixed into this comparison.
Daily offsets are fitted afresh. Comparing daily sources against the DAILY constant-only
model helps distinguish spatial skill from simply adapting to daily background.</p>
<p>Censored readings remain soft upper bounds, not zeros or limit/2. Connectivity is undirected,
with zero influence between disconnected components; flow direction and passability remain
unverified. Same-day samples need not be simultaneous. Bootstrap stability does not provide
Bayesian intervals or calibrated source probabilities.</p>
<img src="daily_coverage.png" alt="Daily sampled-site coverage and screening threshold">
<p>The map provides a daily date filter and previous/next-day controls for both distance
versions. Unsupported and empty days show no source overlay. Relative scores use a fixed
maximum coefficient across all fitted days within each version, so day-to-day colors do not
silently renormalize every day's highest coefficient to one.</p>
<p><a href="../nitrogen_source_analysis/nitrogen_map.html?model=daily-network">Daily network map</a>
 | <a href="../nitrogen_source_analysis/nitrogen_map.html?model=daily-distance">Daily straight-line map</a>
 | <a href="daily_summary.csv">Daily coverage and statuses</a>
 | <a href="comparison.csv">Comparison CSV</a>
 | <a href="observations_with_predictions.csv">Audited predictions</a>
 | <a href="daily_sources.csv">Daily source coefficients</a>
 | <a href="validation_folds.csv">Validation support audit</a>
 | <a href="model_metadata.json">Settings and baseline hashes</a>{bootstrap_downloads}</p>
<script id="daily-report-data" type="application/json">{report_json}</script>
<script>{report_script}</script></html>"""
    (output / "report.html").write_text(document, encoding="utf-8")


def run(baseline_dir: Path, output: Path, minimum_sites: int = 10, minimum_exact_sites: int = 3) -> dict:
    if output.resolve() == baseline_dir.resolve():
        raise ValueError("Daily outputs must not overwrite the annual baseline.")
    required = ["model_metadata.json", "observations_with_predictions.csv",
                "candidate_sources.csv", "source_receptor_distances.csv"]
    hashes = {name: hashlib.sha256((baseline_dir / name).read_bytes()).hexdigest() for name in required}
    baseline = json.loads((baseline_dir / "model_metadata.json").read_text())
    observations = pd.read_csv(baseline_dir / "observations_with_predictions.csv",
                               dtype={"sample_id": str, "location_code": str})
    candidates = pd.read_csv(baseline_dir / "candidate_sources.csv")
    pairs = pd.read_csv(baseline_dir / "source_receptor_distances.csv")
    if (len(observations) != baseline["observation_count"] or len(candidates) != baseline["candidate_count"]
            or candidates["candidate_id"].duplicated().any()
            or not observations["parameter_id"].eq(PARAMETER).all()):
        raise ValueError("Annual matched-comparison snapshots disagree with their metadata.")
    codes = sorted(observations["location_code"].unique())
    if len(pairs) != len(codes) * len(candidates) or pairs.duplicated(["location_code", "candidate_id"]).any():
        raise ValueError("Every site/candidate pair must occur exactly once.")
    row_indices = pd.Series(np.arange(len(codes)), index=codes).loc[observations["location_code"]].to_numpy()
    kernels = {}
    for model, column in [("network", "network_kernel"), ("euclidean", "euclidean_kernel")]:
        matrix = pairs.pivot(index="location_code", columns="candidate_id", values=column).reindex(
            index=codes, columns=candidates["candidate_id"]).to_numpy()
        if not np.isfinite(matrix).all() or (matrix < 0).any() or (matrix > 1).any():
            raise ValueError("Saved source-receptor kernels must be finite and between zero and one.")
        kernels[model] = matrix[row_indices]
    days, predictions, folds, comparison = fit_daily_slots(
        observations, kernels, baseline["start"], baseline["end"], baseline["regularization"],
        minimum_sites, minimum_exact_sites)
    source_rows = []
    for day, entry in days.items():
        if entry["status"] != "fitted":
            continue
        for model, fitted in entry["fits"].items():
            source_rows.extend(
                {"date": day, "model": model, "candidate_id": code, "coefficient_mg_n_l": coefficient}
                for code, coefficient in zip(candidates["candidate_id"], fitted["coefficients"]))
    sources = pd.DataFrame(source_rows, columns=["date", "model", "candidate_id", "coefficient_mg_n_l"])
    maxima = {model: float(sources.loc[sources["model"].eq(model), "coefficient_mg_n_l"].max())
              if sources["model"].eq(model).any() else 0. for model in kernels}
    sources["relative_score"] = [
        row.coefficient_mg_n_l / maxima[row.model] if maxima[row.model] > 0 else 0.
        for row in sources.itertuples(index=False)]
    summary = pd.DataFrame([
        {key: value for key, value in entry.items() if key not in {"fits", "validation", "includedSites"}}
        for entry in days.values()])
    evaluated = predictions.loc[predictions["daily_cv_status"].eq("evaluated")]
    metadata = {
        "model": "Independent daily nonnegative Euclidean/network nitrate inversions",
        "parameter": PARAMETER, "start": baseline["start"], "end": baseline["end"],
        "time_zone": baseline["time_zone"], "minimum_sites": minimum_sites,
        "minimum_exact_sites": minimum_exact_sites, "screening": "Heuristic coverage screen, not identifiability/confidence.",
        "site_count": len(codes), "candidate_count": len(candidates), "observation_count": len(observations),
        "day_count": len(days), "fitted_day_count": int(summary["status"].eq("fitted").sum()),
        "insufficient_day_count": int(summary["status"].eq("insufficient_data").sum()),
        "no_data_day_count": int(summary["status"].eq("no_data").sum()),
        "evaluated_observation_count": len(evaluated),
        "evaluated_day_count": int(evaluated["slot_date"].nunique()),
        "evaluated_exact_count": int(evaluated["value_kind"].eq("exact").sum()),
        "evaluated_upper_bound_count": int(evaluated["value_kind"].eq("upper_bound").sum()),
        "validation": "Preserved annual geographic site folds; daily training uses same-day non-held-out sites only.",
        "comparison_mask": "Exactly rows with sufficient DAILY TRAINING coverage, shared by all six models.",
        "regularization": baseline["regularization"], "decay_length_m": baseline["decay_length_m"],
        "grid_spacing_m": baseline["grid_spacing_m"], "normalization_maxima": maxima,
        "uncertainty": "None estimated; relative scores are not confidence or probabilities.",
        "limitations": "Sparse, underdetermined daily fits; non-simultaneous sampling; no temporal smoothing, flow direction or passability validation.",
        "baseline_directory": str(baseline_dir), "baseline_sha256": hashes,
        "comparison": comparison.to_dict(orient="records"),
    }
    fitted_dates = [day for day, entry in days.items() if entry["status"] == "fitted"]
    observed_dates = [day for day, entry in days.items() if entry["sampleCount"]]
    default_date = (fitted_dates or observed_dates or list(days))[0]
    features = [{
        "type": "Feature", "geometry": {"type": "Point", "coordinates": [float(row.longitude), float(row.latitude)]},
        "properties": {"candidate_id": row.candidate_id},
    } for row in candidates.itertuples(index=False)]
    map_data = {
        "parameter": PARAMETER, "start": baseline["start"], "end": baseline["end"],
        "minimumSites": minimum_sites, "minimumExactSites": minimum_exact_sites,
        "defaultDate": default_date, "days": days, "normalizationMaxima": maxima,
        "candidates": {"type": "FeatureCollection", "features": features},
    }
    output.mkdir(parents=True, exist_ok=True)
    predictions.to_csv(output / "observations_with_predictions.csv", index=False)
    sources.to_csv(output / "daily_sources.csv", index=False)
    summary.to_csv(output / "daily_summary.csv", index=False)
    folds.to_csv(output / "validation_folds.csv", index=False)
    comparison.to_csv(output / "comparison.csv", index=False)
    for filename, data in [("model_metadata.json", metadata), ("model_map.json", map_data)]:
        (output / filename).write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    write_report(output, summary, comparison, metadata)
    if any(hashlib.sha256((baseline_dir / name).read_bytes()).hexdigest() != digest
           for name, digest in hashes.items()):
        raise RuntimeError("Annual baseline snapshots changed during daily fitting.")
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-dir", type=Path, default=ROOT / "datasets" / "nitrate_network_distance_2024")
    parser.add_argument("--output", type=Path, default=ROOT / "datasets" / "nitrate_daily_2024")
    parser.add_argument("--minimum-sites", type=int, default=10)
    parser.add_argument("--minimum-exact-sites", type=int, default=3)
    parser.add_argument("--report-only", action="store_true", help="Refresh the report from saved results; do not fit models.")
    args = parser.parse_args()
    if args.report_only:
        output = args.output.resolve()
        write_report(output, pd.read_csv(output / "daily_summary.csv"),
                     pd.read_csv(output / "comparison.csv"),
                     json.loads((output / "model_metadata.json").read_text()))
        print(f"Report refreshed without fitting: {output / 'report.html'}")
        return
    metadata = run(args.baseline_dir.resolve(), args.output.resolve(), args.minimum_sites, args.minimum_exact_sites)
    print(json.dumps(metadata, indent=2))
    print(f"Report: {args.output.resolve() / 'report.html'}")


if __name__ == "__main__":
    main()
