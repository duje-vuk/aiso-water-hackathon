import pandas as pd
import os
out = r"datasets/clean"
os.makedirs(out, exist_ok=True)

# --- Amstelsluizen water level: 2-line header ---
df = pd.read_csv(r"datasets/AGV/Amstelsluizen_waterhoogte.csv", skiprows=2,
                 names=["date_time","water_level_mNAP"])
df["date_time"] = pd.to_datetime(df["date_time"], format="%d-%m-%Y %H:%M", dayfirst=True)
df = df.dropna(subset=["date_time"]).sort_values("date_time")
df.to_csv(os.path.join(out,"amstel_locks_water_level.csv"), index=False)
print("amstel_locks:", len(df), df["date_time"].min(), "->", df["date_time"].max())

# --- Berlagebrug discharge + water level ---
df2 = pd.read_csv(r"datasets/AGV/Berlagebrug_debiet_waterhoogte.csv", skiprows=2,
                  names=["date_time","water_level_mNAP","discharge_m3_day"])
df2["date_time"] = pd.to_datetime(df2["date_time"], format="%d-%m-%Y %H:%M", dayfirst=True)
df2 = df2.dropna(subset=["date_time"]).sort_values("date_time")
df2.to_csv(os.path.join(out,"berlage_bridge_discharge_water_level.csv"), index=False)
print("berlagebrug:", len(df2), df2["date_time"].min(), "->", df2["date_time"].max())
print(df2.head(3).to_string())
