"use strict";
const test = require("node:test");
const assert = require("node:assert/strict");
const { isoDay, dayISO, validateWindow, siteStats, windowSummary, colorFor, searchSites, escapeHTML, modelMatchesWindow, availableDistanceModels, resolveDailyModel, adjacentModelDay, bootstrapFeatures, stabilityColor } = require("./nitrogen_map.js");

const start = isoDay("2020-01-01"), end = isoDay("2020-01-31");
const site = {
  code: "AGV001", name: "Amst\u00e9l test station",
  observations: { nitrate: [[start - 1, 1000], [start, 2], [start + 10, 4], [end, 6], [end + 1, 1000]] },
};

test("inclusive start/end exclude both outside boundary observations", () => {
  const stats = siteStats(site, "nitrate", start, end);
  assert.deepEqual(stats, { n: 3, median: 4, min: 2, max: 6, first: start, last: end });
});
test("even sample median averages both middle measurements", () => {
  assert.equal(siteStats(site, "nitrate", start, start + 10).median, 3);
});
test("one-day windows retain all observations on that date", () => {
  const sameDay = { observations: { nitrate: [[start, 2], [start, 8]] } };
  assert.equal(siteStats(sameDay, "nitrate", start, start).median, 5);
  assert.equal(siteStats(sameDay, "nitrate", start, start).n, 2);
});
test("missing analytes and empty windows are not zero concentrations", () => {
  assert.equal(siteStats(site, "ammonium", start, end), null);
  assert.equal(siteStats(site, "nitrate", end + 2, end + 3), null);
});
test("minimum sample filter and status use the same visible samples", () => {
  const empty = { code: "empty", observations: {} };
  const sparse = { code: "sparse", observations: { nitrate: [[start, 0]] } };
  const result = windowSummary([site, empty, sparse], "nitrate", start, end, 2);
  assert.equal(result.visible.length, 1);
  assert.equal(result.sampleCount, 3);
  assert.equal(result.noData, 1);
  assert.equal(result.insufficient, 1);
});
test("zero is a measurement, not missing data", () => {
  assert.equal(siteStats({ observations: { nitrate: [[start, 0]] } }, "nitrate", start, end).median, 0);
});
test("valid windows and leap dates are accepted without local timezone shifts", () => {
  assert.equal(validateWindow("2020-01-01", "2020-01-31", 1, "1963-01-01", "2025-06-05"), null);
  assert.equal(dayISO(isoDay("2020-02-29")), "2020-02-29");
  assert.equal(dayISO(isoDay("1963-06-10")), "1963-06-10");
});
test("malformed or impossible dates are rejected", () => {
  for (const value of ["", "not-a-date", "2020-02-31", "2021-02-29"]) assert.equal(isoDay(value), null);
  assert.equal(validateWindow("", "2020-01-01", 1, "1963-01-01", "2025-06-05"), "date");
});
test("reversed, out-of-bounds and noninteger filters return explicit errors", () => {
  assert.equal(validateWindow("2020-02-01", "2020-01-01", 1, "1963-01-01", "2025-06-05"), "order");
  assert.equal(validateWindow("1960-01-01", "2020-01-01", 1, "1963-01-01", "2025-06-05"), "bounds");
  for (const minimum of [0, -1, 1.5, NaN]) {
    assert.equal(validateWindow("2020-01-01", "2020-01-31", minimum, "1963-01-01", "2025-06-05"), "minimum");
  }
});
test("color scale is fixed for an analyte and caps high concentrations", () => {
  assert.equal(colorFor(0, 4), "#FDF0C2");
  assert.equal(colorFor(1, 4), "#FBC56A");
  assert.equal(colorFor(3, 4), "#C2410C");
  assert.equal(colorFor(400, 4), "#C2410C");
  assert.equal(colorFor(0, 0), "#FDF0C2");
});
test("search supports real identifiers, names, accents and no matches", () => {
  assert.equal(searchSites([site], "agv001")[0], site);
  assert.equal(searchSites([site], "amstel")[0], site);
  assert.deepEqual(searchSites([site], "not found"), []);
});
test("popup values are HTML-escaped", () => {
  assert.equal(escapeHTML('<script>"&\'</script>'), "&lt;script&gt;&quot;&amp;&#39;&lt;/script&gt;");
});
test("fixed-window model cannot silently follow different pollutants or date windows", () => {
  const model = { parameter: "NO3_mgN/l_nf", start: "2024-01-01", end: "2024-12-31" };
  assert.equal(modelMatchesWindow(model, model), true);
  assert.equal(modelMatchesWindow(model, { ...model, parameter: "Ntot_mgN/l" }), false);
  assert.equal(modelMatchesWindow(model, { ...model, start: "2023-01-01" }), false);
  assert.equal(modelMatchesWindow(model, { ...model, end: "2024-06-30" }), false);
  assert.equal(modelMatchesWindow(null, model), false);
});
test("connectivity model is a separate selectable version, not a replacement baseline", () => {
  const baseline = { parameter: "NO3_mgN/l_nf", start: "2024-01-01", end: "2024-12-31" };
  const network = { ...baseline, metric: "network" };
  assert.deepEqual(availableDistanceModels({ distanceModel: baseline, connectivityModel: network }),
    { distance: baseline, network });
  assert.deepEqual(availableDistanceModels({ connectivityModel: network }), { network });
  assert.deepEqual(availableDistanceModels({}), {});
  assert.equal(modelMatchesWindow(network, { ...baseline, end: "2024-06-30" }), false);
});
test("daily selection uses its own coefficients with a fixed cross-day scale and no annual fallback", () => {
  const daily = {
    parameter: "NO3_mgN/l_nf", start: "2024-01-01", end: "2024-01-03",
    minimumSites: 3, minimumExactSites: 2,
    normalizationMaxima: { network: 2, euclidean: 4 },
    candidates: { type: "FeatureCollection", features: [{
      geometry: { type: "Point", coordinates: [4.9, 52.3] }, properties: { candidate_id: "N1" },
    }] },
    days: {
      "2024-01-01": { status: "fitted", fits: { network: { coefficients: [1] }, euclidean: { coefficients: [1] } } },
      "2024-01-02": { status: "insufficient_data", fits: null },
      "2024-01-03": { status: "no_data", fits: null },
    },
  };
  const models = availableDistanceModels({ dailyModels: daily });
  assert.deepEqual(Object.keys(models), ["daily-distance", "daily-network"]);
  const network = resolveDailyModel(models["daily-network"], "2024-01-01");
  assert.equal(network.sources.features[0].properties.relative_score, .5);
  assert.equal(resolveDailyModel(models["daily-distance"], "2024-01-01").sources.features[0].properties.relative_score, .25);
  assert.equal(network.start, network.end);
  assert.equal(modelMatchesWindow(network, { parameter: daily.parameter, start: network.start, end: network.end }), true);
  for (const day of ["2024-01-02", "2024-01-03"]) {
    assert.deepEqual(resolveDailyModel(models["daily-network"], day).sources.features, []);
  }
  assert.throws(() => resolveDailyModel(models["daily-network"], "2025-01-01"), RangeError);
});
test("daily navigation includes empty dates and leap days without crossing calendar bounds", () => {
  assert.equal(adjacentModelDay("2024-02-28", 1, "2024-01-01", "2024-12-31"), "2024-02-29");
  assert.equal(adjacentModelDay("2024-03-01", -1, "2024-01-01", "2024-12-31"), "2024-02-29");
  assert.equal(adjacentModelDay("2024-01-01", -1, "2024-01-01", "2024-12-31"), null);
  assert.equal(adjacentModelDay("2024-12-31", 1, "2024-01-01", "2024-12-31"), null);
});
test("bootstrap view uses selection frequencies, not normalized source strengths", () => {
  const model = { isDaily: true, status: "fitted", start: "2024-01-03", dailyMetric: "network",
    sources: { features: [{ geometry: { type: "Point", coordinates: [4.9, 52.3] },
      properties: { candidate_id: "N1", relative_score: 1 } }] } };
  const stability = { days: { "2024-01-03": { status: "available", models: {
    network: { selectionFrequency: [.2], coefficientP025: [0], coefficientMedian: [.1], coefficientP975: [.5] },
  } } } };
  assert.equal(bootstrapFeatures(model, stability)[0].properties.selectionFrequency, .2);
  assert.equal(bootstrapFeatures(model, stability)[0].properties.relative_score, 1);
  assert.deepEqual(bootstrapFeatures(model, null), []);
  assert.deepEqual(bootstrapFeatures({ ...model, status: "insufficient_data" }, stability), []);
  stability.days["2024-01-03"].status = "insufficient_bootstrap_support";
  assert.deepEqual(bootstrapFeatures(model, stability), []);
  assert.equal(stabilityColor(0), "#f0f9e8");
  assert.equal(stabilityColor(1), "#0868ac");
});
