import csv, sys
csv.field_size_limit(10_000_000)
path = r"datasets/AGV/FYCHEM_alleParamtrs_alleJaren_Amstelland_1900tmjuni.csv"
params = {}
locs = {}
dates = [None, None]
n = 0
with open(path, newline='', encoding='utf-8-sig') as f:
    r = csv.DictReader(f)
    for row in r:
        n += 1
        p = row['fewsparameter']
        if p not in params:
            params[p] = (row['fewsparametercode'], row['fewsparameternaam'], row['fewsparametercategorie'], row['eenheid'])
        lc = row['locatiecode']
        if lc not in locs:
            locs[lc] = (row['locatie omschrijving'], row['locatie x'], row['locatie y'], row['locatie EAG'], row['locatie KRW watertype'])
        d = row['datum']
        if dates[0] is None or d < dates[0]: dates[0] = d
        if dates[1] is None or d > dates[1]: dates[1] = d
print("rows:", n, "| date range:", dates[0], "->", dates[1])
print("\n=== unique parameters (%d) ===" % len(params))
for p, v in sorted(params.items()):
    print(f"{p}\t{v[0]}\t{v[1]}\t{v[2]}\t{v[3]}")
print("\n=== unique locations (%d) ===" % len(locs))
for lc, v in sorted(locs.items()):
    print(f"{lc}\t{v[0]}\t{v[1]}\t{v[2]}\t{v[3]}\t{v[4]}")
