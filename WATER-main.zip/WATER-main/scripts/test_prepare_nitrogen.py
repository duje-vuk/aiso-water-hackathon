"""Focused tests; no large source files or extra test dependencies required."""
import unittest
import csv
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from prepare_nitrogen import clean_measurements, combine_flow_partials, flow_partial, inventory, nitrogen_wide, parse_dates


class PreparationTests(unittest.TestCase):
    def test_fixed_gmt_plus_one_in_winter_and_summer(self):
        dates = parse_dates(pd.Series(["2024-01-01 12:00", "2024-07-01 12:00"]))
        self.assertEqual(dates.dt.hour.tolist(), [12, 12])
        self.assertEqual([date.utcoffset().total_seconds() for date in dates], [3600, 3600])
        aware = parse_dates(pd.Series(["2024-07-01T11:00:00Z"]))
        self.assertEqual(aware.iloc[0].hour, 12)

    def measurement(self, **changes):
        row = {
            "monsterident": "sample1", "locatiecode": "site1", "datum": "2020-01-02 12:00",
            "fewsparameter": "NO3_mgN/l_nf", "meetwaarde": "2.5", "eenheid": "mg/l",
            "limietsymbool": "", "kwaliteitsoordeelcode": "0", "compartiment": "OW",
        }
        row.update(changes)
        return row

    def test_censoring_and_quality_are_not_exact_values(self):
        frame = clean_measurements(pd.DataFrame([
            self.measurement(), self.measurement(limietsymbool="<"),
            self.measurement(limietsymbool=">"), self.measurement(kwaliteitsoordeelcode="3"),
            self.measurement(kwaliteitsoordeelcode=""), self.measurement(compartiment="WB"),
            self.measurement(meetwaarde="-1"), self.measurement(eenheid="ug/l"),
            self.measurement(datum="bad date"), self.measurement(meetwaarde="inf"),
        ]))
        self.assertEqual(frame["analysis_eligible"].tolist(), [True] + [False] * 9)
        self.assertEqual(frame["is_censored"].sum(), 2)
        self.assertEqual(frame["analysis_unit"].iloc[0], "mg N/L")
        self.assertEqual(frame["date_time_raw"].iloc[8], "bad date")

    def test_replicates_use_median_and_keep_count(self):
        frame = clean_measurements(pd.DataFrame([
            self.measurement(meetwaarde="2"), self.measurement(meetwaarde="6"),
            self.measurement(meetwaarde="100", limietsymbool="<"),
        ]))
        wide = nitrogen_wide(frame)
        self.assertEqual(wide["NO3_mgN/l_nf"].iloc[0], 4)
        self.assertEqual(wide["NO3_mgN/l_nf__replicate_count"].iloc[0], 2)
        self.assertEqual(len(frame), 3)

    def flows(self, hours, date="2020-01-01", value="10"):
        return pd.DataFrame({
            "datum": [f"{date} {hour:02d}:00:00" for hour in hours],
            "waarde": value, "locatie": "pump1", "parameter": "Q.m3.uur",
        })

    def test_complete_day_across_chunks(self):
        first, _ = flow_partial(self.flows(range(12)))
        second, _ = flow_partial(self.flows(range(12, 24)))
        day = combine_flow_partials([first, second]).iloc[0]
        self.assertTrue(day["complete_day"])
        self.assertEqual(day["observed_hours"], 24)
        self.assertEqual(day["volume_m3_assuming_hourly_rates"], 240)

    def test_partial_day_is_not_complete_volume(self):
        partial, _ = flow_partial(self.flows(range(12)))
        day = combine_flow_partials([partial]).iloc[0]
        self.assertFalse(day["complete_day"])
        self.assertTrue(np.isnan(day["volume_m3_assuming_hourly_rates"]))
        self.assertEqual(day["hourly_value_sum"], 120)

    def test_cross_chunk_duplicate_hour_invalidates_volume(self):
        first, _ = flow_partial(self.flows(range(24)))
        second, _ = flow_partial(self.flows([0]))
        day = combine_flow_partials([first, second]).iloc[0]
        self.assertEqual(day["observed_hours"], 24)
        self.assertEqual(day["duplicate_hour_rows"], 1)
        self.assertFalse(day["complete_day"])

    def test_bad_dates_nonhour_values_and_signed_flow(self):
        source = self.flows([0], value="-10")
        extra = pd.DataFrame({
            "datum": ["", "not a date", "2020-01-01 01:10", "2020-01-01 02:00"],
            "waarde": ["1", "1", "1", "inf"], "locatie": "pump1", "parameter": "Q.m3.uur",
        })
        partial, audit = flow_partial(pd.concat([source, extra], ignore_index=True))
        self.assertEqual(audit["invalid_or_missing_dates"], 2)
        self.assertEqual(audit["non_hour_aligned_rows"], 1)
        self.assertEqual(audit["excluded_rows"], 4)
        self.assertEqual(partial["hourly_value_sum"].iloc[0], -10)

    def test_inventory_skips_each_header_and_translates_every_column(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source, output = root / "source", root / "output"
            source.mkdir()
            output.mkdir()
            for part in (1, 2):
                path = source / f"polderdebieten_10min_fews_part{part}of4.csv"
                with path.open("w", newline="", encoding="utf-8") as stream:
                    writer = csv.writer(stream)
                    writer.writerow(["datum", "waarde", "locatie", "parameter"])
                    writer.writerow(["2020-01-01", "10", "pump1", "Q.m3.10min"])
            (source / "level.csv").write_text(
                "GMT+1,station\n,WATHTE.mNAP.dag.gem\n1-1-2020 01:00,-0.4\n", encoding="utf-8",
            )
            records = inventory(source, output, 1000)
            self.assertEqual([r["sample_rows_read"] for r in records], [1, 1, 1])
            self.assertEqual([r["header_rows"] for r in records], [2, 1, 1])
            translations = pd.read_csv(output / "column_translations.csv")
            self.assertFalse(translations["english_column"].isna().any())
            self.assertFalse(translations.duplicated(["source_file", "english_column"]).any())


if __name__ == "__main__":
    unittest.main()
