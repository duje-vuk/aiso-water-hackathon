import unittest

import pandas as pd
from shapely.geometry import LineString, shape

from enrich_agv_gis import add_area_membership, normalize_reaches, outlet_scenario
from water_connectivity import Reach, adjacent_measurements, build_network, snap_locations


class GISEnrichmentTests(unittest.TestCase):
    def test_outlet_scenario_is_assumed_and_reverses_digital_direction_when_needed(self):
        reaches = [Reach("r", LineString([(0, 0), (20, 0)]))]
        locations = pd.DataFrame(
            [("A", 2., 0.), ("OUTLET", 18., 0.)], columns=["location_code", "rd_x", "rd_y"],
        )
        matches = snap_locations(locations, reaches)
        graph, nodes = build_network(reaches, matches)
        distances = outlet_scenario(graph, nodes, "OUTLET")
        self.assertEqual(distances[nodes["A"]], 16)
        relations = adjacent_measurements(graph, nodes)
        self.assertEqual(next(row["relation"] for row in relations if row["from_location"] == "A"),
                         "nominal_downstream")

    def test_disconnected_components_keep_direction_unknown(self):
        reaches = [Reach("r", LineString([(0, 0), (20, 0)])),
                   Reach("other", LineString([(0, 100), (20, 100)]))]
        locations = pd.DataFrame(
            [("OUTLET", 18., 0.), ("A", 2., 100.), ("B", 18., 100.)],
            columns=["location_code", "rd_x", "rd_y"],
        )
        matches = snap_locations(locations, reaches, maximum_distance=1)
        graph, nodes = build_network(reaches, matches)
        outlet_scenario(graph, nodes, "OUTLET")
        self.assertTrue(all(row["relation"] == "connected_direction_unresolved"
                            for row in adjacent_measurements(graph, nodes)))
        with self.assertRaisesRegex(ValueError, "not unambiguously matched"):
            outlet_scenario(graph, nodes, "missing")

    def test_source_geometry_order_or_symbol_angle_never_sets_observed_direction(self):
        collections = {
            "watercourses": {"features": [{
                "type": "Feature", "properties": {"OBJECTID": 1, "code": "r", "richting": 90},
                "geometry": {"type": "LineString", "coordinates": [[4.9, 52.3], [4.91, 52.3]]},
            }]},
            "culverts": {"features": []},
        }
        reaches, _, rejected = normalize_reaches(collections)
        self.assertEqual(reaches[0].direction, "unknown")
        self.assertEqual(rejected, [])

    def test_invalid_source_polygon_repair_is_explicitly_audited(self):
        areas = {"type": "FeatureCollection", "features": [{
            "type": "Feature", "properties": {"code": "invalid-test"},
            "geometry": {"type": "Polygon", "coordinates": [[
                [4.9, 52.3], [4.901, 52.301], [4.901, 52.3], [4.9, 52.301], [4.9, 52.3],
            ]]},
        }]}
        matches = pd.DataFrame({"rd_x": [0.], "rd_y": [0.]})
        result, repairs = add_area_membership(matches, areas)
        self.assertEqual(repairs[0]["area_code"], "invalid-test")
        self.assertEqual(repairs[0]["repair_method"], "shapely.make_valid")
        self.assertTrue(shape(areas["features"][0]["geometry"]).is_valid)
        self.assertEqual(result["water_level_area_count"].iloc[0], 0)


if __name__ == "__main__":
    unittest.main()
