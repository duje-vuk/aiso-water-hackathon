"""Build a local Leaflet nitrogen map from the prepared AGV sample table."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
from pathlib import Path
from urllib.request import urlopen

import numpy as np
import pandas as pd

from prepare_nitrogen import GMT_PLUS_ONE, NITROGEN, ROOT, parse_dates


NAMES_NL = {
    "Ntot_mgN/l": "Totaal stikstof",
    "NKj_mgN/l": "Kjeldahl-stikstof",
    "NO3_mgN/l_nf": "Nitraat (gefiltreerd)",
    "NO2_mgN/l_nf": "Nitriet (gefiltreerd)",
    "NH4_mgN/l_nf": "Ammonium (gefiltreerd)",
    "NH3_mgN/l_nf": "Ammoniak (gefiltreerd)",
    "sNO3NO2_mgN/l_nf": "Nitraat + nitriet (gefiltreerd)",
}
ASSETS = {
    "leaflet.js": (
        "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js",
        "20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=",
    ),
    "leaflet.css": (
        "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css",
        "p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=",
    ),
    "LICENSE": ("https://unpkg.com/leaflet@1.9.4/LICENSE", None),
    **{f"images/{name}": (f"https://unpkg.com/leaflet@1.9.4/dist/images/{name}", None) for name in [
        "layers.png", "layers-2x.png", "marker-icon.png", "marker-icon-2x.png", "marker-shadow.png",
    ]},
}


def build_payload(samples: pd.DataFrame, locations: pd.DataFrame) -> dict:
    if samples.empty:
        raise ValueError("The nitrogen sample table is empty.")
    if locations["location_code"].duplicated().any():
        raise ValueError("Monitoring location codes must be unique.")
    keys = ["sample_id", "location_code", "date_time", "compartment"]
    if samples.duplicated(keys).any():
        raise ValueError("Duplicate sample keys: regenerate the prepared sample table.")
    dates = parse_dates(samples["date_time"])
    if dates.isna().any():
        raise ValueError("Every map sample must have a valid date.")
    if not samples["compartment"].eq("OW").all():
        raise ValueError("Map inputs must contain surface-water samples only.")
    samples = samples.copy()
    samples["day"] = (dates.dt.normalize() - pd.Timestamp("1970-01-01", tz=GMT_PLUS_ONE)).dt.days
    valid_location = (
        locations["valid_rd_coordinate"].eq(True) & locations["metadata_variant_count"].eq(1)
        & np.isfinite(locations["latitude"]) & np.isfinite(locations["longitude"])
        & locations["latitude"].between(-90, 90) & locations["longitude"].between(-180, 180)
    )
    location_index = locations.loc[valid_location].set_index("location_code")
    mappable = samples["location_code"].isin(location_index.index)
    selected = samples.loc[mappable]
    if selected.empty:
        raise ValueError("No samples have unambiguous valid monitoring coordinates.")
    pollutants, sites = {}, []
    for parameter, name in NITROGEN.items():
        if parameter not in samples:
            raise ValueError(f"Missing nitrogen parameter column: {parameter}")
        values = samples[parameter].dropna()
        if (~np.isfinite(values) | values.lt(0)).any():
            raise ValueError(f"Invalid eligible nitrogen concentrations: {parameter}")
        mapped_values = selected[parameter].dropna()
        pollutants[parameter] = {
            "name": {"en": name[0].upper() + name[1:], "nl": NAMES_NL[parameter]},
            "unit": "mg N/L",
            "colorCap": float(mapped_values.quantile(.95)) if not mapped_values.empty else 0,
        }
    for code, group in selected.groupby("location_code", sort=True):
        location = location_index.loc[code]
        observations = {}
        for parameter in NITROGEN:
            values = group.loc[group[parameter].notna(), ["day", parameter]].sort_values("day")
            if not values.empty:
                observations[parameter] = [
                    [int(day), float(value)] for day, value in values.itertuples(index=False, name=None)
                ]
        if observations:
            sites.append({
                "code": str(code), "name": str(location["location_name"]),
                "lat": float(location["latitude"]), "lon": float(location["longitude"]),
                "wfd": "" if pd.isna(location["wfd_water_type"]) else str(location["wfd_water_type"]),
                "eag": "" if pd.isna(location["ecological_analysis_area"]) else str(location["ecological_analysis_area"]),
                "observations": observations,
            })
    if not sites:
        raise ValueError("No eligible measurements can be mapped.")
    first = selected["day"].min()
    last = selected["day"].max()
    iso = lambda day: (pd.Timestamp("1970-01-01") + pd.Timedelta(days=int(day))).strftime("%Y-%m-%d")
    default_start = max(int(first), int((pd.Timestamp("2015-01-01") - pd.Timestamp("1970-01-01")).days))
    default_start = min(default_start, int(last))
    return {
        "pollutants": pollutants, "sites": sites,
        "minDate": iso(first), "maxDate": iso(last), "defaultStart": iso(default_start),
        "meta": {
            "source": "AGV prepared nitrogen_samples_wide.csv",
            "sampleRowsRead": len(samples), "sampleRowsWithCoordinates": len(selected),
            "sampleRowsExcludedForCoordinates": int((~mappable).sum()),
            "mappedSiteCount": len(sites),
            "analyteSampleCount": sum(len(values) for site in sites for values in site["observations"].values()),
            "coordinateCrs": "EPSG:4326, transformed from assumed EPSG:28992",
            "timeZone": "UTC+01:00",
            "timeZoneAssumption": "All timestamps interpreted as fixed GMT+1 by user request; no daylight-saving changes.",
            "colorScale": "Per-analyte 95th percentile of all mappable eligible sample concentrations; fixed across date windows.",
        },
    }


def ensure_leaflet(output: Path) -> None:
    vendor = output / "vendor" / "leaflet"
    vendor.mkdir(parents=True, exist_ok=True)
    for name, (url, expected_hash) in ASSETS.items():
        target = vendor / name
        if target.exists():
            content = target.read_bytes()
        else:
            print(f"Downloading pinned public Leaflet asset: {name}", flush=True)
            with urlopen(url, timeout=60) as response:
                content = response.read()
        if expected_hash is not None:
            actual_hash = base64.b64encode(hashlib.sha256(content).digest()).decode()
            if actual_hash != expected_hash:
                raise ValueError(f"Leaflet integrity check failed: {name}")
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(content)


def write_map(payload: dict, output: Path) -> Path:
    script_dir = Path(__file__).resolve().parent
    data = json.dumps(payload, ensure_ascii=True, separators=(",", ":"), allow_nan=False)
    # Prevent a place name from terminating the JSON script element.
    safe_data = data.replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    template = (script_dir / "nitrogen_map.html").read_text(encoding="utf-8")
    if template.count("__NITROGEN_DATA__") != 1 or template.count("__NITROGEN_SCRIPT__") != 1:
        raise ValueError("Map template must contain exactly one data and one script placeholder.")
    document = template.replace("__NITROGEN_SCRIPT__", (script_dir / "nitrogen_map.js").read_text(encoding="utf-8"))
    document = document.replace("__NITROGEN_DATA__", safe_data)
    output.mkdir(parents=True, exist_ok=True)
    ensure_leaflet(output)
    target = output / "nitrogen_map.html"
    target.write_text(document, encoding="utf-8")
    (output / "nitrogen_map_data.json").write_text(data, encoding="utf-8")
    return target


def load_connectivity(data_dir: Path, payload: dict) -> None:
    directory = data_dir / "gis"
    if not (directory / "provenance.json").exists():
        return
    provenance = json.loads((directory / "provenance.json").read_text(encoding="utf-8"))
    matches = pd.read_csv(directory / "measurement_network_matches.csv").set_index("location_code")
    relations = pd.read_csv(directory / "measurement_relations.csv")
    links = {}
    for row in relations.itertuples(index=False):
        links.setdefault(row.from_location, []).append({
            "to": row.to_location, "relation": row.relation,
            "distance": float(row.network_distance_m),
            "structures": json.loads(row.nearby_hydraulic_structure_codes),
        })
    for site in payload["sites"]:
        match = matches.loc[site["code"]]
        site["network"] = {
            "status": match["snap_status"], "snapDistance": (
                None if pd.isna(match["distance_to_watercourse_m"]) else float(match["distance_to_watercourse_m"])),
            "connectedToOutlet": bool(match["connected_to_assumed_outlet"]),
            "distanceToOutlet": (None if pd.isna(match["distance_to_assumed_outlet_m"])
                                 else float(match["distance_to_assumed_outlet_m"])),
            "reviewRecommended": bool(match["manual_review_recommended"]),
            "areas": json.loads(match["water_level_area_codes"]), "links": links.get(site["code"], []),
        }

    def rounded_geometry(geometry: dict) -> dict:
        def rounded(coordinates):
            if isinstance(coordinates[0], (float, int)):
                return [round(value, 6) for value in coordinates]
            return [rounded(child) for child in coordinates]
        return {"type": geometry["type"], "coordinates": rounded(geometry["coordinates"])}

    watercourses = json.loads((directory / "watercourse_network.geojson").read_text(encoding="utf-8"))
    for feature in watercourses["features"]:
        feature["geometry"] = rounded_geometry(feature["geometry"])
    all_routes = json.loads((directory / "measurement_relations.geojson").read_text(encoding="utf-8"))
    routes = {"type": "FeatureCollection", "features": []}
    for feature in all_routes["features"]:
        if feature["properties"]["relation"] == "scenario_downstream":
            routes["features"].append({
                "type": "Feature", "geometry": rounded_geometry(feature["geometry"]),
                "properties": {key: feature["properties"][key] for key in
                               ("from_location", "to_location", "network_distance_m",
                                "nearby_hydraulic_structure_codes")},
            })
    structures = json.loads((directory / "hydraulic_structures.geojson").read_text(encoding="utf-8"))
    payload["gis"] = {
        "outlet": provenance["outlet_code"], "outletSnapDistance": provenance["outlet_snap_distance_m"],
        "connectedSites": provenance["measurements_connected_to_outlet"],
        "watercourses": watercourses, "structures": structures, "routes": routes,
        "note": "User-selected outlet scenario based on current GIS; not observed flow or verified hydraulic passability.",
    }


def validate_candidate_points(features: list, scores: bool = True) -> None:
    for feature in features:
        geometry, properties = feature["geometry"], feature["properties"]
        coordinates = geometry["coordinates"]
        if (geometry["type"] != "Point" or len(coordinates) != 2
                or not np.isfinite(coordinates).all()
                or not -180 <= coordinates[0] <= 180 or not -90 <= coordinates[1] <= 90):
            raise ValueError("Distance overlay contains invalid coordinates or candidate scores.")
        if scores:
            score, coefficient = properties["relative_score"], properties["coefficient_mg_n_l"]
            if not np.isfinite([score, coefficient]).all() or not 0 <= score <= 1 or coefficient < 0:
                raise ValueError("Distance overlay contains invalid coordinates or candidate scores.")


def load_distance_model(path: Path, payload: dict, key: str = "distanceModel") -> None:
    if not path.exists():
        return
    model = json.loads(path.read_text(encoding="utf-8"))
    if model["parameter"] != "NO3_mgN/l_nf" or model["sources"]["type"] != "FeatureCollection":
        raise ValueError("Distance overlay must contain nitrate candidate point features.")
    if pd.Timestamp(model["start"]) > pd.Timestamp(model["end"]):
        raise ValueError("Distance overlay has an invalid time window.")
    if key == "connectivityModel":
        required = {"metric", "includedSites", "siteCount", "excludedSiteCount", "comparison"}
        if (not required.issubset(model) or model["metric"] != "network"
                or not isinstance(model["includedSites"], list)
                or not all(isinstance(code, str) for code in model["includedSites"])
                or len(model["includedSites"]) != len(set(model["includedSites"]))
                or len(model["includedSites"]) != model["siteCount"]
                or model["excludedSiteCount"] < 0
                or not {"network", "euclidean_same_support", "offset_only"}.issubset(model["comparison"])
                or not all(np.isfinite(value) and value >= 0 for value in model["comparison"].values())):
            raise ValueError("Connectivity overlay must identify network coverage and same-support RMSE comparisons.")
    validate_candidate_points(model["sources"]["features"])
    payload[key] = model


def load_daily_models(path: Path, payload: dict) -> None:
    if not path.exists():
        return
    model = json.loads(path.read_text(encoding="utf-8"))
    expected = {day.strftime("%Y-%m-%d") for day in pd.date_range(model["start"], model["end"], freq="D")}
    if (model["parameter"] != "NO3_mgN/l_nf" or not expected or set(model["days"]) != expected
            or model["defaultDate"] not in expected or model["minimumSites"] < 3
            or not 2 <= model["minimumExactSites"] <= model["minimumSites"]
            or model["candidates"]["type"] != "FeatureCollection"):
        raise ValueError("Daily overlay must cover every calendar day with an explicit status.")
    features = model["candidates"]["features"]
    validate_candidate_points(features, scores=False)
    if not features:
        raise ValueError("Daily overlay requires fixed candidate support.")
    for metric in ("network", "euclidean"):
        maximum = model["normalizationMaxima"][metric]
        if not np.isfinite(maximum) or maximum < 0:
            raise ValueError("Daily overlay normalization maxima must be finite and nonnegative.")
    for day, entry in model["days"].items():
        supported = entry["siteCount"] >= model["minimumSites"] and entry["exactSiteCount"] >= model["minimumExactSites"]
        if (entry["date"] != day or entry["status"] not in {"fitted", "insufficient_data", "no_data"}
                or entry["sampleCount"] != entry["exactCount"] + entry["upperBoundCount"]
                or entry["siteCount"] != len(set(entry["includedSites"]))
                or (entry["status"] == "fitted") != supported
                or (entry["status"] == "no_data") != (entry["sampleCount"] == 0)):
            raise ValueError("Daily overlay has inconsistent date, coverage or fit status.")
        if entry["status"] != "fitted":
            if entry["fits"] is not None:
                raise ValueError("Unsupported days must not contain source estimates.")
            continue
        for metric in ("network", "euclidean"):
            fitted = entry["fits"][metric]
            coefficients = np.asarray(fitted["coefficients"])
            if (len(coefficients) != len(features) or not np.isfinite(coefficients).all()
                    or (coefficients < 0).any() or not np.isfinite(fitted["offset_mg_n_l"])
                    or fitted["offset_mg_n_l"] < 0
                    or coefficients.max() > model["normalizationMaxima"][metric] + 1e-10):
                raise ValueError("Daily source estimates must match fixed support and normalization.")
    payload["dailyModels"] = model


def load_daily_stability(path: Path, daily_path: Path, payload: dict) -> None:
    if not path.exists():
        return
    if "dailyModels" not in payload:
        raise ValueError("Bootstrap stability requires its matching daily source models.")
    stability = json.loads(path.read_text())
    daily = payload["dailyModels"]
    if (stability["dailyModelMapSha256"] != hashlib.sha256(daily_path.read_bytes()).hexdigest()
            or stability["dailyObservationsSha256"] != hashlib.sha256(
                (daily_path.parent / "observations_with_predictions.csv").read_bytes()).hexdigest()):
        raise ValueError("Stale bootstrap estimates: regenerate daily bootstrap stability.")
    expected_ids = [feature["properties"]["candidate_id"] for feature in daily["candidates"]["features"]]
    if (stability["candidateIds"] != expected_ids or set(stability["days"]) != set(daily["days"])
            or stability["start"] != daily["start"] or stability["end"] != daily["end"]
            or not 0 < stability["hotspotFraction"] <= 1 or stability["replicates"] < 20):
        raise ValueError("Bootstrap geometry, calendar or settings disagree with daily models.")
    for day, entry in stability["days"].items():
        if daily["days"][day]["status"] != "fitted":
            if entry["status"] != "not_fitted" or entry["models"] is not None:
                raise ValueError("Unsupported days cannot have bootstrap estimates.")
            continue
        if (entry["status"] not in {"available", "insufficient_bootstrap_support"}
                or entry["attemptedReplicates"] != stability["replicates"]
                or not 0 <= entry["validReplicates"] <= entry["attemptedReplicates"]
                or (entry["status"] == "available") != (
                    entry["validReplicates"] >= np.ceil(.8 * entry["attemptedReplicates"]))):
            raise ValueError("Bootstrap validity counts or availability are inconsistent.")
        if entry["status"] != "available":
            if entry["models"] is not None:
                raise ValueError("Insufficient bootstrap support must not expose stability estimates.")
            continue
        for metric in ("network", "euclidean"):
            values = entry["models"][metric]
            arrays = {key: np.asarray(values[key]) for key in [
                "selectionFrequency", "coefficientP025", "coefficientMedian", "coefficientP975"]}
            if (any(len(array) != len(expected_ids) or not np.isfinite(array).all() or (array < 0).any()
                    for array in arrays.values()) or (arrays["selectionFrequency"] > 1).any()
                    or (arrays["coefficientP025"] > arrays["coefficientMedian"]).any()
                    or (arrays["coefficientMedian"] > arrays["coefficientP975"]).any()):
                raise ValueError("Invalid bootstrap frequencies or coefficient percentile ranges.")
    payload["dailyStability"] = stability


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "datasets" / "nitrogen_source_analysis")
    parser.add_argument("--distance-model", type=Path,
                        default=ROOT / "datasets" / "nitrate_distance_baseline_2024" / "model_map.json")
    parser.add_argument("--connectivity-model", type=Path,
                        default=ROOT / "datasets" / "nitrate_network_distance_2024" / "model_map.json")
    parser.add_argument("--daily-model", type=Path,
                        default=ROOT / "datasets" / "nitrate_daily_2024" / "model_map.json")
    parser.add_argument("--daily-stability", type=Path,
                        default=ROOT / "datasets" / "nitrate_daily_2024" / "stability_map.json")
    args = parser.parse_args()
    data_dir = args.data_dir.resolve()
    samples = pd.read_csv(data_dir / "nitrogen_samples_wide.csv", dtype={"sample_id": str, "location_code": str})
    locations = pd.read_csv(data_dir / "monitoring_locations.csv", dtype={"location_code": str})
    payload = build_payload(samples, locations)
    load_connectivity(data_dir, payload)
    load_distance_model(args.distance_model.resolve(), payload)
    load_distance_model(args.connectivity_model.resolve(), payload, "connectivityModel")
    load_daily_models(args.daily_model.resolve(), payload)
    load_daily_stability(args.daily_stability.resolve(), args.daily_model.resolve(), payload)
    target = write_map(payload, data_dir)
    print(json.dumps(payload["meta"], indent=2))
    print(f"Date coverage: {payload['minDate']} to {payload['maxDate']}")
    print(f"Map: {target}")


if __name__ == "__main__":
    main()
