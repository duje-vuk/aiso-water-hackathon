import pandas as pd
for path, name in [(r"datasets/AGV/polderdebieten_uur_fews.csv","uur"),
                   (r"datasets/AGV/poldergemalen_aan_uit.csv","aanuit")]:
    locs = {}
    mind, maxd = None, None
    cnt = 0
    for ch in pd.read_csv(path, chunksize=2_000_000, dtype=str):
        cnt += len(ch)
        for loc, g in ch.groupby('locatie'):
            if loc not in locs:
                locs[loc] = (g['parameter'].iloc[0],)
            dmin, dmax = g['datum'].min(), g['datum'].max()
            mind = dmin if mind is None or dmin < mind else mind
            maxd = dmax if maxd is None or dmax > maxd else maxd
    print(f"=== {name}: rows={cnt}, stations={len(locs)}, dates {mind} -> {maxd}")
    for loc in sorted(locs):
        print(loc, locs[loc][0])
