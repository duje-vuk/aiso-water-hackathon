"""
Water Quality Explorer API + static frontend.  Python standard library only.

    python scripts/load_db.py        # once, builds datasets/water.sqlite
    python api/server.py             # then open http://localhost:8000

Endpoints (all GET, JSON, read-only):
    /api/meta                                   pollutants, types, years, reference level, data version
    /api/sites                                  every site with per-year aggregates (map, search, filters)
    /api/sites/{code}?pollutant=NO3&years=...   exact stats for one site from raw observations (popup)
    /api/areas?level=afv|eag&pollutant=&years=  share above reference per AGV area / sub-area
    /api/trends?pollutants=Ptot,NH4|all&area=   per pollutant per year: samples, above, share
    /api/composition?years=&pollutants=&group=pollutant|type&area=
    /api/geo/areas                              area polygons (approximate cells, or official GIS if provided)
    /api/export                                 one snapshot of meta + sites + areas (offline demo)
    /api/health

`years`: "2020", "2015-2025" or "2019,2021" (omit = all).  `pollutant(s)`: codes, "all", or omit = all combined.
"""
from __future__ import annotations

import argparse
import gzip
import json
import mimetypes
import sqlite3
import statistics
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

ROOT = Path(__file__).resolve().parents[1]
FRONTEND = ROOT / "frontend"


class BadRequest(Exception):
    pass


class Store:
    """Read-only access to the SQLite file; one connection per thread."""

    def __init__(self, db: Path, areas: Path):
        if not db.exists():
            raise SystemExit(f"Database not found: {db}\nRun: python scripts/load_db.py")
        self.db, self.areas_path = db, areas
        self.local = threading.local()
        c = self.con()
        self.meta = {k: v for k, v in c.execute("SELECT key, value FROM meta")}
        self.years = json.loads(self.meta["years"])
        self.pollutants = {r["code"]: dict(r) for r in c.execute("SELECT * FROM pollutants ORDER BY ord")}
        self.categories = {r["code"]: dict(r) for r in c.execute("SELECT * FROM categories ORDER BY ord")}
        self._sites_cache = None

    def con(self) -> sqlite3.Connection:
        c = getattr(self.local, "con", None)
        if c is None:
            c = sqlite3.connect(f"file:{self.db.as_posix()}?mode=ro", uri=True, check_same_thread=False)
            c.row_factory = sqlite3.Row
            self.local.con = c
        return c

    # ---- parameter parsing (whitelisted, so SQL stays parameterised) ----
    def parse_years(self, raw: str | None) -> list[int]:
        if not raw:
            return list(self.years)
        out: set[int] = set()
        try:
            for part in raw.split(","):
                part = part.strip()
                if "-" in part:
                    a, b = (int(x) for x in part.split("-", 1))
                    out.update(range(min(a, b), max(a, b) + 1))
                elif part:
                    out.add(int(part))
        except ValueError:
            raise BadRequest(f"bad years: {raw!r}")
        return sorted(y for y in out if y in set(self.years))

    def parse_pollutants(self, raw: str | None) -> list[str]:
        if not raw or raw == "all":
            return list(self.pollutants)
        codes = [c.strip() for c in raw.split(",") if c.strip()]
        bad = [c for c in codes if c not in self.pollutants]
        if bad:
            raise BadRequest(f"unknown pollutant(s): {bad}")
        return codes

    def envelope(self, data: dict) -> dict:
        return {"data_version": self.meta["data_version"], "reference": self.meta["reference"], **data}

    # ---- endpoints ----
    def meta_json(self) -> dict:
        cats = {c: {"en": v["name_en"], "nl": v["name_nl"]} for c, v in self.categories.items()}
        pols = {c: {"name": {"en": v["name_en"], "nl": v["name_nl"][:1].upper() + v["name_nl"][1:]}, "unit": v["unit"],
                    "threshold": v["ref_level"], "cat": v["cat"], "catName": cats[v["cat"]], "n": v["n_detected"]}
                for c, v in self.pollutants.items()}
        return self.envelope({"years": self.years, "categories": cats, "pollutants": pols,
                              "cleaning": self.meta["cleaning"], "audit": json.loads(self.meta["audit"])})

    def sites_json(self) -> dict:
        if self._sites_cache is None:
            c = self.con()
            rows = defaultdict_list()
            for r in c.execute("SELECT site, pollutant, year, n, above, median FROM site_year ORDER BY site, pollutant, year"):
                rows[r[0]].setdefault(r[1], []).append([r[2], r[3], r[4], r[5]])
            sites = [[s["code"], {"en": s["name"], "nl": s["name"]}, s["lat"], s["lng"], rows.get(s["code"], {}),
                      {"eag": s["eag"], "wfd": s["wfd"], "soil": {"en": s["soil_en"], "nl": s["soil_nl"]}, "last": s["last_date"]}]
                     for s in c.execute("SELECT * FROM sites ORDER BY code")]
            self._sites_cache = self.envelope({"sites": sites})
        return self._sites_cache

    def site_json(self, code: str, q: dict) -> dict:
        c = self.con()
        s = c.execute("SELECT * FROM sites WHERE code = ?", (code,)).fetchone()
        if s is None:
            raise LookupError(code)
        years = self.parse_years(q.get("years"))
        pol = q.get("pollutant")
        pols = self.parse_pollutants(pol) if pol else list(self.pollutants)
        marks = ",".join("?" * len(years)) or "NULL"
        pm = ",".join("?" * len(pols))
        rows = c.execute(f"SELECT pollutant, date, value, lim FROM observations WHERE site = ? AND pollutant IN ({pm}) "
                         f"AND year IN ({marks})", (code, *pols, *years)).fetchall()
        above = sum(1 for r in rows if r["lim"] != "<" and r["value"] > self.pollutants[r["pollutant"]]["ref_level"])
        stats = {"samples": len(rows), "above": above, "share": above / len(rows) if rows else None}
        if pol and len(pols) == 1 and rows:
            vals = [r["value"] for r in rows]
            stats.update(median=statistics.median(vals), min=min(vals), max=max(vals),
                         first=min(r["date"] for r in rows), last=max(r["date"] for r in rows), unit=self.pollutants[pols[0]]["unit"])
        return self.envelope({"site": {k: s[k] for k in s.keys()}, "pollutant": pol or "ALL", "years": [years[0], years[-1]] if years else [],
                              "stats": stats})

    def _site_year_filter(self, years: list[int], pols: list[str], area: str | None):
        sql = (" FROM site_year sy JOIN sites s ON s.code = sy.site WHERE sy.year IN ({}) AND sy.pollutant IN ({})"
               .format(",".join("?" * len(years)) or "NULL", ",".join("?" * len(pols)) or "NULL"))
        args = [*years, *pols]
        if area:
            sql += " AND s.afv = ?"
            args.append(area)
        return sql, args

    def areas_json(self, q: dict) -> dict:
        level = q.get("level", "afv")
        if level not in ("afv", "eag"):
            raise BadRequest("level must be afv or eag")
        years = self.parse_years(q.get("years"))
        pols = self.parse_pollutants(q.get("pollutant"))
        where, args = self._site_year_filter(years, pols, None)
        rows = self.con().execute(f"SELECT s.{level} AS area, SUM(sy.n) n, SUM(sy.above) above, COUNT(DISTINCT sy.site) sites"
                                  f"{where} GROUP BY s.{level} ORDER BY s.{level}", args).fetchall()
        return self.envelope({"level": level, "areas": [{"area": r["area"], "samples": r["n"], "above": r["above"],
                                                         "share": r["above"] / r["n"] if r["n"] else None, "sites": r["sites"]} for r in rows]})

    def trends_json(self, q: dict) -> dict:
        pols = self.parse_pollutants(q.get("pollutants"))
        where, args = self._site_year_filter(self.years, pols, q.get("area") or None)
        c = self.con()
        series: dict[str, list] = {}
        for r in c.execute(f"SELECT sy.pollutant p, sy.year y, SUM(sy.n) n, SUM(sy.above) a{where} GROUP BY sy.pollutant, sy.year ORDER BY sy.year", args):
            series.setdefault(r["p"], []).append([r["y"], r["n"], r["a"], r["a"] / r["n"] if r["n"] else None])
        combined = [[r["y"], r["n"], r["a"], r["a"] / r["n"] if r["n"] else None]
                    for r in c.execute(f"SELECT sy.year y, SUM(sy.n) n, SUM(sy.above) a{where} GROUP BY sy.year ORDER BY sy.year", args)]
        return self.envelope({"area": q.get("area") or None, "series": series, "combined": combined})

    def composition_json(self, q: dict) -> dict:
        group = q.get("group", "pollutant")
        if group not in ("pollutant", "type"):
            raise BadRequest("group must be pollutant or type")
        years = self.parse_years(q.get("years"))
        pols = self.parse_pollutants(q.get("pollutants")) if q.get("pollutants") != "" else []
        where, args = self._site_year_filter(years, pols, q.get("area") or None)
        key = "sy.pollutant" if group == "pollutant" else "(SELECT cat FROM pollutants WHERE code = sy.pollutant)"
        rows = self.con().execute(f"SELECT {key} k, SUM(sy.above) a, SUM(sy.n) n{where} GROUP BY k HAVING a > 0 ORDER BY a DESC", args).fetchall()
        total = sum(r["a"] for r in rows)
        slices = []
        for r in rows:
            if group == "pollutant":
                p = self.pollutants[r["k"]]
                slices.append({"key": r["k"], "cat": p["cat"], "name": {"en": p["name_en"], "nl": p["name_nl"]}, "above": r["a"], "samples": r["n"]})
            else:
                cdef = self.categories[r["k"]]
                slices.append({"key": r["k"], "cat": r["k"], "name": {"en": cdef["name_en"], "nl": cdef["name_nl"]}, "above": r["a"], "samples": r["n"]})
        return self.envelope({"group": group, "total": total, "slices": slices})

    def areas_geo(self) -> dict:
        if not self.areas_path.exists():
            return {"kind": "none", "cells": []}
        return json.loads(self.areas_path.read_text(encoding="utf-8"))

    def export_json(self) -> dict:
        m = self.meta_json()
        return {**m, "sites": self.sites_json()["sites"], "cells": self.areas_geo().get("cells", [])}


class defaultdict_list(dict):
    def __missing__(self, key):
        self[key] = {}
        return self[key]


def make_handler(store: Store):
    class Handler(BaseHTTPRequestHandler):
        server_version = "WaterQualityExplorer/1.0"

        def log_message(self, fmt, *args):  # quieter console
            if not self.path.startswith("/api/health"):
                super().log_message(fmt, *args)

        def send_bytes(self, body: bytes, ctype: str, status: int = 200, cache: str = "no-cache"):
            if "gzip" in self.headers.get("Accept-Encoding", "") and len(body) > 1024:
                body = gzip.compress(body, 6)
                self.send_response(status)
                self.send_header("Content-Encoding", "gzip")
            else:
                self.send_response(status)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", cache)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body)

        def send_json(self, obj, status: int = 200):
            self.send_bytes(json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8"),
                            "application/json; charset=utf-8", status)

        def do_GET(self):
            url = urlparse(self.path)
            q = {k: v[-1] for k, v in parse_qs(url.query, keep_blank_values=True).items()}
            path = unquote(url.path)
            try:
                if path == "/api/health":
                    return self.send_json({"ok": True, "data_version": store.meta["data_version"]})
                if path == "/api/meta":
                    return self.send_json(store.meta_json())
                if path == "/api/sites":
                    return self.send_json(store.sites_json())
                if path.startswith("/api/sites/"):
                    return self.send_json(store.site_json(path[len("/api/sites/"):], q))
                if path == "/api/areas":
                    return self.send_json(store.areas_json(q))
                if path == "/api/trends":
                    return self.send_json(store.trends_json(q))
                if path == "/api/composition":
                    return self.send_json(store.composition_json(q))
                if path == "/api/geo/areas":
                    return self.send_json(store.areas_geo())
                if path == "/api/export":
                    return self.send_json(store.export_json())
                if path.startswith("/api/"):
                    return self.send_json({"error": "not found"}, 404)
                return self.serve_static(path)
            except BadRequest as e:
                return self.send_json({"error": str(e)}, 400)
            except LookupError as e:
                return self.send_json({"error": f"not found: {e}"}, 404)

        def serve_static(self, path: str):
            rel = "index.html" if path in ("", "/") else path.lstrip("/")
            target = (FRONTEND / rel).resolve()
            if FRONTEND.resolve() not in target.parents and target != FRONTEND.resolve() or not target.is_file():
                return self.send_json({"error": "not found"}, 404)
            ctype = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype in ("application/javascript", "application/json"):
                ctype += "; charset=utf-8"
            self.send_bytes(target.read_bytes(), ctype)

    return Handler


def main():
    ap = argparse.ArgumentParser(description="Water Quality Explorer API")
    ap.add_argument("--db", type=Path, default=ROOT / "datasets" / "water.sqlite")
    ap.add_argument("--areas", type=Path, default=FRONTEND / "data" / "areas.json",
                    help="Area polygons served at /api/geo/areas (approximate cells by default)")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()
    store = Store(args.db, args.areas)
    srv = ThreadingHTTPServer((args.host, args.port), make_handler(store))
    print(f"Water Quality Explorer: http://{args.host}:{args.port}  (data {store.meta['data_version']}, "
          f"{len(store.pollutants)} pollutants, years {store.years[0]}-{store.years[-1]})")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    main()
