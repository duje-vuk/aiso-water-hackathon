import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd

from fit_nitrate_daily import fit_daily_slots, run


class DailyModelTests(unittest.TestCase):
    def fixture(self):
        frame = pd.DataFrame({
            "location_code": ["A", "B", "C", "D"] * 2,
            "date_time": ["2024-01-01 00:01:00+01:00"] * 4 + ["2024-01-02 23:59:00+01:00"] * 4,
            "value": [.2, .5, 1., 1.4, .4, .8, 1.3, 1.8],
            "value_kind": ["exact"] * 8, "spatial_fold": [0, 1, 2, 3] * 2,
            "held_out_prediction_mg_n_l": .6, "euclidean_held_out_prediction_mg_n_l": .7,
            "held_out_offset_only_mg_n_l": .5, "parameter_id": "NO3_mgN/l_nf",
        })
        kernel = np.array([[1., .1], [.7, .2], [.2, .7], [.1, 1.]])
        kernels = {"network": np.vstack([kernel, kernel]), "euclidean": np.vstack([kernel, kernel])}
        return frame, kernels

    def fit(self, frame, kernels):
        return fit_daily_slots(frame, kernels, "2024-01-01", "2024-01-03", .01, 3, 2)

    def test_calendar_slots_and_missing_day_are_not_interpolated(self):
        frame, kernels = self.fixture()
        days, predictions, folds, comparison = self.fit(frame, kernels)
        self.assertEqual(list(days), ["2024-01-01", "2024-01-02", "2024-01-03"])
        self.assertEqual(days["2024-01-01"]["status"], "fitted")
        self.assertEqual(days["2024-01-02"]["status"], "fitted")
        self.assertEqual(days["2024-01-03"]["status"], "no_data")
        self.assertIsNone(days["2024-01-03"]["fits"])
        self.assertEqual(predictions["slot_date"].tolist(), ["2024-01-01"] * 4 + ["2024-01-02"] * 4)
        self.assertTrue(predictions["daily_cv_status"].eq("evaluated").all())
        self.assertEqual(len(folds), 8)
        self.assertEqual(len(comparison), 6)
        self.assertTrue(comparison["exact_count"].eq(8).all())

    def test_other_days_cannot_change_daily_fit_or_holdout_predictions(self):
        frame, kernels = self.fixture()
        original_days, original, _, _ = self.fit(frame, kernels)
        frame.loc[4:, "value"] *= 20
        changed_days, changed, _, _ = self.fit(frame, kernels)
        self.assertEqual(original_days["2024-01-01"]["fits"], changed_days["2024-01-01"]["fits"])
        np.testing.assert_allclose(original.loc[:3, "daily_network_held_out_mg_n_l"],
                                   changed.loc[:3, "daily_network_held_out_mg_n_l"])

    def test_entire_heldout_site_is_excluded_from_daily_training(self):
        frame, kernels = self.fixture()
        _, original, _, _ = self.fit(frame, kernels)
        frame.loc[frame["location_code"].eq("A"), "value"] = 100
        _, changed, _, _ = self.fit(frame, kernels)
        np.testing.assert_allclose(original.loc[[0, 4], "daily_network_held_out_mg_n_l"],
                                   changed.loc[[0, 4], "daily_network_held_out_mg_n_l"])

    def test_support_uses_training_only_and_all_comparisons_share_mask(self):
        frame, kernels = self.fixture()
        frame["spatial_fold"] = [0, 0, 0, 1] * 2
        _, predictions, folds, comparison = self.fit(frame, kernels)
        rejected = predictions["spatial_fold"].eq(0)
        self.assertTrue(predictions.loc[rejected, "daily_cv_status"].eq("insufficient_training_data").all())
        self.assertTrue(predictions.loc[rejected, "daily_network_held_out_mg_n_l"].isna().all())
        self.assertTrue(comparison["exact_count"].eq(2).all())
        self.assertTrue(folds.loc[folds["fold"].eq(0), "training_sites"].eq(1).all())

    def test_sparse_and_all_censored_days_have_no_source_estimates(self):
        frame, kernels = self.fixture()
        frame.loc[4:, "value_kind"] = "upper_bound"
        days, predictions, _, _ = self.fit(frame, kernels)
        self.assertEqual(days["2024-01-02"]["status"], "insufficient_data")
        self.assertIsNone(days["2024-01-02"]["fits"])
        self.assertTrue(predictions.loc[4:, "daily_network_fitted_mg_n_l"].isna().all())
        self.assertTrue(predictions.loc[4:, "daily_network_held_out_mg_n_l"].isna().all())
        with self.assertRaisesRegex(ValueError, "at least 3"):
            fit_daily_slots(frame, kernels, "2024-01-01", "2024-01-03", .01, 1, 1)

    def test_censored_bounds_remain_inequalities(self):
        frame, kernels = self.fixture()
        frame.loc[0, "value_kind"] = "upper_bound"
        frame.loc[0, "value"] = 10
        first, _, _, _ = self.fit(frame, kernels)
        frame.loc[0, "value"] = 100
        second, _, _, _ = self.fit(frame, kernels)
        np.testing.assert_allclose(first["2024-01-01"]["fits"]["network"]["coefficients"],
                                   second["2024-01-01"]["fits"]["network"]["coefficients"])

    def test_disk_outputs_preserve_baseline_and_fix_cross_day_score_scale(self):
        frame, kernels = self.fixture()
        with tempfile.TemporaryDirectory() as directory:
            baseline, output = Path(directory) / "baseline", Path(directory) / "daily"
            baseline.mkdir()
            frame.to_csv(baseline / "observations_with_predictions.csv", index=False)
            candidates = pd.DataFrame({"candidate_id": ["N1", "N2"], "longitude": [4.9, 5.],
                                       "latitude": [52.3, 52.4]})
            candidates.to_csv(baseline / "candidate_sources.csv", index=False)
            rows = [{"location_code": code, "candidate_id": candidate,
                     "network_kernel": kernels["network"][i, j], "euclidean_kernel": kernels["euclidean"][i, j]}
                    for i, code in enumerate(["A", "B", "C", "D"])
                    for j, candidate in enumerate(["N1", "N2"])]
            pd.DataFrame(rows).to_csv(baseline / "source_receptor_distances.csv", index=False)
            (baseline / "model_metadata.json").write_text(json.dumps({
                "start": "2024-01-01", "end": "2024-01-03", "time_zone": "UTC+01:00",
                "observation_count": 8, "candidate_count": 2, "regularization": .01,
                "decay_length_m": 2000, "grid_spacing_m": 2000,
            }))
            before = {path.name: path.read_bytes() for path in baseline.iterdir()}
            with patch("fit_nitrate_daily.write_report"):
                metadata = run(baseline, output, 3, 2)
            self.assertEqual(before, {path.name: path.read_bytes() for path in baseline.iterdir()})
            self.assertEqual(metadata["fitted_day_count"], 2)
            saved = pd.read_csv(output / "daily_sources.csv")
            for model, group in saved.groupby("model"):
                np.testing.assert_allclose(group["relative_score"],
                                           group["coefficient_mg_n_l"] / metadata["normalization_maxima"][model])
            self.assertEqual(len(pd.read_csv(output / "comparison.csv")), 6)
            model_map = json.loads((output / "model_map.json").read_text())
            self.assertEqual(model_map["defaultDate"], "2024-01-01")
            self.assertIsNone(model_map["days"]["2024-01-03"]["fits"])


if __name__ == "__main__":
    unittest.main()
