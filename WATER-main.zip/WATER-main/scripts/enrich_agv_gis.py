"""Download public AGV GIS and build an explicitly assumed outlet-flow scenario."""
from __future__ import annotations

import argparse
import html
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

import networkx as nx
import pandas as pd
from pyproj import Transformer
from shapely import make_valid
from shapely.geometry import LineString, Point, mapping, shape
from shapely.ops import transform
from shapely.strtree import STRtree
from shapely.validation import explain_validity

from prepare_nitrogen import ROOT
from water_connectivity import Reach, adjacent_measurements, build_network, snap_locations


BASE = "https://services-eu1.arcgis.com/nN7Fv7YeT1qPGzBX/arcgis/rest/services/"
BBOX = [4.65, 52.05, 5.15, 52.5]
LAYERS = {
    "watercourses": ("agol_legger_hydroobject_actueel", 2,
                    ["code", "categorieOppervlaktewater", "ws_bodemhoogte", "ws_waterbreedte",
                     "ws_waterdiepte", "ws_actiefVanaf", "ws_actiefTotMet", "ws_procedurestatus"]),
    "pumps": ("agol_legger_gemaal_actueel", 2,
              ["code", "richting", "functieGemaal", "ws_typeGemaal", "ws_procedurestatus"]),
    "culverts": ("agol_legger_duikersifonhevel_actueel", 2,
                 ["code", "hoogteBinnenOnderkantBov", "hoogteBinnenOnderkantBene",
                  "ws_indInlaatfunctie", "ws_procedurestatus"]),
    "weirs": ("agol_legger_stuw_actueel", 2,
              ["code", "richting", "typeStuw", "typeRegelbaarheid", "ws_procedurestatus"]),
    "dams": ("agol_legger_vastedam_actueel", 2,
             ["code", "richting", "ws_type", "ws_procedurestatus"]),
    "water_level_areas": ("DAMO_BEHEERREGISTER_PEILGEBIEDEN_VIGEREND", 0,
                          ["code", "naam", "statusObject", "statusPeilgebied",
                           "ws_peilgebiedSoort", "ws_peilbeheer"]),
}
PUMP_FUNCTIONS = {
    1: "supply", 2: "drainage", 4: "sub-drainage", 5: "drainage and supply",
    6: "emergency drainage", 8: "flushing", 99: "unknown",
}
TO_RD = Transformer.from_crs(4326, 28992, always_xy=True).transform
TO_WGS = Transformer.from_crs(28992, 4326, always_xy=True).transform


def get_json(url: str, parameters: dict, *, post: bool = False) -> dict:
    encoded = urlencode(parameters)
    request = Request(url, data=encoded.encode("ascii")) if post else url + "?" + encoded
    with urlopen(request, timeout=90) as response:
        result = json.load(response)
    if "error" in result:
        raise RuntimeError(f"AGV GIS error at {url}: {result['error']}")
    return result


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=True, separators=(",", ":"), allow_nan=False),
                    encoding="utf-8")


def download_layer(name: str, source: Path, refresh: bool) -> tuple[dict, dict]:
    service, layer, fields = LAYERS[name]
    url = f"{BASE}{service}/FeatureServer/{layer}"
    cached = source / f"{name}.geojson"
    provenance = source / f"{name}.metadata.json"
    if cached.exists() and provenance.exists() and not refresh:
        print(f"Using cached official GIS: {name}", flush=True)
        return json.loads(cached.read_text(encoding="utf-8")), json.loads(provenance.read_text(encoding="utf-8"))
    metadata = get_json(url, {"f": "json"})
    available = {field["name"] for field in metadata["fields"]}
    missing = set(fields) - available
    if missing:
        raise ValueError(f"AGV schema changed for {name}: missing fields {sorted(missing)}")
    oid = metadata["objectIdField"]
    query = {
        "f": "json", "where": "1=1", "returnIdsOnly": "true",
        "geometry": json.dumps({"xmin": BBOX[0], "ymin": BBOX[1], "xmax": BBOX[2], "ymax": BBOX[3]}),
        "geometryType": "esriGeometryEnvelope", "inSR": 4326,
        "spatialRel": "esriSpatialRelIntersects",
    }
    ids_result = get_json(url + "/query", query)
    ids = sorted(ids_result.get("objectIds") or [])
    if not ids:
        raise ValueError(f"No GIS features returned for {name}; refusing an empty successful export.")
    features = []
    for offset in range(0, len(ids), 500):
        response = get_json(url + "/query", {
            "f": "geojson", "objectIds": ",".join(map(str, ids[offset:offset + 500])),
            "outFields": ",".join([oid] + fields), "returnGeometry": "true", "outSR": 4326,
        }, post=True)
        if response.get("type") != "FeatureCollection" or response.get("exceededTransferLimit"):
            raise ValueError(f"Incomplete or invalid GeoJSON response for {name}")
        features.extend(response["features"])
    returned_ids = [feature["properties"][oid] for feature in features]
    if sorted(returned_ids) != ids:
        raise ValueError(f"GIS paging completeness check failed for {name}")
    collection = {"type": "FeatureCollection", "features": features}
    evidence = {
        "provider": "Waterschap Amstel, Gooi en Vecht / Waternet",
        "layer_url": url, "layer_name": metadata["name"], "layer_id": layer,
        "downloaded_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_last_edit_epoch_ms": metadata.get("editingInfo", {}).get("lastEditDate"),
        "source_crs": metadata.get("extent", {}).get("spatialReference"),
        "download_crs": "EPSG:4326", "query_bbox_wgs84": BBOX, "feature_count": len(features),
        "object_id_field": oid, "queried_fields": fields,
        "license_note": "Public official service; portal licenseInfo was empty. Confirm reuse terms before redistribution.",
        "copyright_text": metadata.get("copyrightText", ""),
        "fields": metadata["fields"],
    }
    write_json(cached, collection)
    write_json(provenance, evidence)
    print(f"Downloaded {name}: {len(features)} features", flush=True)
    return collection, evidence


def normalize_reaches(collections: dict) -> tuple[list[Reach], dict, list[dict]]:
    reaches, features, rejected = [], [], []
    for name in ("watercourses", "culverts"):
        for feature in collections[name]["features"]:
            properties = feature["properties"]
            identifier = f"{name}:{feature.get('id', properties['OBJECTID'])}"
            if not feature.get("geometry"):
                rejected.append({"feature_id": identifier, "reason": "missing_geometry"})
                continue
            geometry = transform(TO_RD, shape(feature["geometry"]))
            parts = list(geometry.geoms) if geometry.geom_type == "MultiLineString" else [geometry]
            for index, part in enumerate(parts):
                part_id = f"{identifier}:{index}"
                if part.geom_type != "LineString" or part.length <= 0 or not part.is_valid:
                    rejected.append({"feature_id": part_id, "reason": "invalid_or_non_line_geometry"})
                    continue
                reaches.append(Reach(part_id, part, "unknown"))
                features.append({
                    "type": "Feature", "geometry": mapping(transform(TO_WGS, part)),
                    "properties": {
                        "reach_id": part_id, "asset_code": properties["code"], "source_layer": name,
                        "hydraulic_direction": "not supplied by source",
                    },
                })
    return reaches, {"type": "FeatureCollection", "features": features}, rejected


def outlet_scenario(graph: nx.MultiGraph, station_nodes: dict, outlet: str) -> dict:
    if outlet not in station_nodes:
        raise ValueError(f"Outlet {outlet} was not unambiguously matched to the downloaded network.")
    distances = nx.single_source_dijkstra_path_length(graph, station_nodes[outlet], weight="weight")
    for start, end, attributes in graph.edges(data=True):
        source, target = attributes["digitized_from"], attributes["digitized_to"]
        if source not in distances or target not in distances or abs(distances[source] - distances[target]) < .01:
            attributes["direction"] = "unknown"
        else:
            attributes["direction"] = "forward" if distances[source] > distances[target] else "reverse"
    return distances


def add_area_membership(matches: pd.DataFrame, areas: dict) -> tuple[pd.DataFrame, list[dict]]:
    geometries, codes, repairs = [], [], []
    for feature in areas["features"]:
        geometry = transform(TO_RD, shape(feature["geometry"]))
        if not geometry.is_valid:
            reason = explain_validity(geometry)
            geometry = make_valid(geometry)
            if geometry.is_empty or not geometry.is_valid or geometry.geom_type not in {"Polygon", "MultiPolygon"}:
                raise ValueError(f"Unrepairable official water-level polygon: {feature['properties']['code']}")
            repairs.append({"area_code": str(feature["properties"]["code"]), "source_issue": reason,
                            "repair_method": "shapely.make_valid"})
            feature["geometry"] = mapping(transform(TO_WGS, geometry))
            feature["properties"]["geometry_repaired"] = True
        geometries.append(geometry)
        codes.append(str(feature["properties"]["code"]))
    tree = STRtree(geometries)
    memberships = []
    for match in matches.itertuples(index=False):
        if pd.isna(match.rd_x) or pd.isna(match.rd_y):
            memberships.append([])
            continue
        point = Point(match.rd_x, match.rd_y)
        memberships.append(sorted(codes[index] for index in tree.query(point)
                                  if geometries[index].covers(point)))
    matches["water_level_area_codes"] = [json.dumps(values) for values in memberships]
    matches["water_level_area_count"] = [len(values) for values in memberships]
    repaired_codes = {repair["area_code"] for repair in repairs}
    matches["water_level_area_geometry_repaired"] = [bool(set(values) & repaired_codes) for values in memberships]
    return matches, repairs


def pump_enrichment(data_dir: Path, pumps: dict, target: Path) -> None:
    rows = []
    for feature in pumps["features"]:
        properties = feature["properties"]
        point = shape(feature["geometry"])
        rows.append({
            "station_asset_id": properties["code"], "longitude": point.x, "latitude": point.y,
            "function_code": properties["functieGemaal"],
            "function_en": PUMP_FUNCTIONS.get(properties["functieGemaal"], "not recorded"),
            "type_code": properties["ws_typeGemaal"],
            "symbol_angle_degrees": properties["richting"],
        })
    inventory = pd.read_csv(data_dir / "pump_series_inventory.csv")
    points = pd.DataFrame(rows)
    duplicates = points["station_asset_id"].duplicated(keep=False)
    if duplicates.any():
        raise ValueError("Nonunique official pump asset codes; manual matching is required.")
    enriched = inventory.drop(columns="coordinates_available").merge(
        points, on="station_asset_id", how="left", validate="many_to_one",
    )
    enriched["coordinates_available"] = enriched["longitude"].notna()
    enriched.to_csv(target / "pump_series_gis.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data-dir", type=Path, default=ROOT / "datasets" / "nitrogen_source_analysis")
    parser.add_argument("--outlet", required=True, help="User-selected monitoring code; assumed drainage outlet.")
    parser.add_argument("--refresh", action="store_true", help="Refresh the cached public GIS snapshot.")
    parser.add_argument("--snap-distance", type=float, default=50)
    args = parser.parse_args()
    data_dir = args.data_dir.resolve()
    target = data_dir / "gis"
    source = target / "source"
    source.mkdir(parents=True, exist_ok=True)
    collections, evidence = {}, {}
    for name in LAYERS:
        collections[name], evidence[name] = download_layer(name, source, args.refresh)
    reaches, watercourses, rejected = normalize_reaches(collections)
    locations = pd.read_csv(data_dir / "monitoring_locations.csv")
    locations = locations.loc[locations["has_nitrogen_observations"]].copy()
    if args.outlet not in set(locations["location_code"]):
        raise ValueError(f"Unknown nitrogen monitoring code: {args.outlet}")
    matches = snap_locations(locations, reaches, maximum_distance=args.snap_distance)
    matches = locations.merge(matches, on="location_code", validate="one_to_one")
    matches["manual_review_recommended"] = (
        ~matches["snap_status"].eq("matched") | matches["distance_to_watercourse_m"].gt(25)
    )
    graph, station_nodes = build_network(reaches, matches)
    distances = outlet_scenario(graph, station_nodes, args.outlet)
    components = {node: number for number, nodes in enumerate(nx.connected_components(graph), start=1) for node in nodes}
    matches["network_component"] = matches["location_code"].map(
        {code: components[node] for code, node in station_nodes.items()},
    )
    matches["distance_to_assumed_outlet_m"] = matches["location_code"].map(
        {code: distances.get(node) for code, node in station_nodes.items()},
    )
    matches["connected_to_assumed_outlet"] = matches["distance_to_assumed_outlet_m"].notna()
    matches, polygon_repairs = add_area_membership(matches, collections["water_level_areas"])
    matches.to_csv(target / "measurement_network_matches.csv", index=False)
    print(f"Matching: {matches['snap_status'].value_counts().to_dict()}", flush=True)
    relations = adjacent_measurements(graph, station_nodes)
    structures = []
    for name in ("pumps", "weirs", "dams"):
        for feature in collections[name]["features"]:
            copied = {"type": "Feature", "geometry": feature["geometry"],
                      "properties": {"asset_code": feature["properties"]["code"], "structure_type": name}}
            structures.append(copied)
    structure_geometries = [transform(TO_RD, shape(feature["geometry"])) for feature in structures]
    structure_tree = STRtree(structure_geometries)
    routes = []
    for relation in relations:
        relation["relation"] = relation["relation"].replace("nominal_", "scenario_")
        coordinates = relation.pop("coordinates_rd")
        route = LineString(coordinates) if len(coordinates) > 1 else None
        nearby_structures = []
        if route is not None:
            for index in structure_tree.query(route.buffer(10)):
                if route.distance(structure_geometries[index]) <= 10:
                    nearby_structures.append(structures[index]["properties"]["asset_code"])
        relation["nearby_hydraulic_structure_codes"] = nearby_structures
        relation["direction_basis"] = "assumed shortest-network-distance gradient toward " + args.outlet
        relation["hydraulic_passability_verified"] = False
        if route is not None:
            routes.append({"type": "Feature", "geometry": mapping(transform(TO_WGS, route)),
                           "properties": relation.copy()})
    relation_frame = pd.DataFrame(relations, columns=[
        "from_location", "to_location", "relation", "network_distance_m", "reach_ids",
        "nearby_hydraulic_structure_codes", "direction_basis", "hydraulic_passability_verified",
    ])
    for column in ("reach_ids", "nearby_hydraulic_structure_codes"):
        relation_frame[column] = relation_frame[column].map(json.dumps)
    relation_frame.to_csv(target / "measurement_relations.csv", index=False)
    write_json(target / "watercourse_network.geojson", watercourses)
    write_json(target / "pumping_stations.geojson", collections["pumps"])
    write_json(target / "hydraulic_structures.geojson", {"type": "FeatureCollection", "features": structures})
    write_json(target / "water_level_areas.geojson", collections["water_level_areas"])
    write_json(target / "measurement_relations.geojson", {"type": "FeatureCollection", "features": routes})
    pump_enrichment(data_dir, collections["pumps"], target)
    summary = {
        "outlet_code": args.outlet, "direction_method": "USER-SELECTED OUTLET SCENARIO, NOT OBSERVED FLOW",
        "timezone": "Fixed GMT+1 (UTC+01:00), no daylight-saving changes",
        "source_feature_counts": {name: len(data["features"]) for name, data in collections.items()},
        "reach_count": len(reaches), "graph_nodes": graph.number_of_nodes(), "graph_edges": graph.number_of_edges(),
        "network_components": nx.number_connected_components(graph),
        "measurement_matching": matches["snap_status"].value_counts().to_dict(),
        "measurements_connected_to_outlet": int(matches["connected_to_assumed_outlet"].sum()),
        "outlet_snap_distance_m": float(matches.loc[matches["location_code"].eq(args.outlet),
                                                    "distance_to_watercourse_m"].iloc[0]),
        "matched_locations_over_25m_from_centerline": int(
            (matches["snap_status"].eq("matched") & matches["distance_to_watercourse_m"].gt(25)).sum()),
        "relation_counts": relation_frame["relation"].value_counts().to_dict(),
        "rejected_geometries": rejected, "snap_distance_limit_m": args.snap_distance,
        "water_level_polygon_repairs": polygon_repairs,
        "ambiguous_match_margin_m": 2, "endpoint_quantization_m": .01,
        "limitations": [
            "Current GIS snapshot applied to historical monitoring sites; historical topology is not established.",
            "Only primary watercourses and published culverts are represented; missing secondary ditches cause gaps.",
            "Junctions require shared endpoints rounded to 1 cm. Crossings alone do not create a connection.",
            "Nearby watercourses within 2 m of the best snap distance are ambiguous unless their projected points coincide.",
            "Outlet scenario follows decreasing shortest network distance, not measured water level, velocity or pumping direction.",
            "Disconnected components have no inferred direction toward the chosen outlet.",
            "Weirs, pumps and fixed dams are mapped and nearby route structures flagged, but hydraulic passability is unverified.",
            "Pumping functieGemaal is a function category; numeric richting is not treated as verified flow direction.",
            "Regional GIS extent is bounded; routes outside the downloaded extent are not inferred.",
        ],
        "sources": evidence,
    }
    write_json(target / "provenance.json", summary)
    source_rows = "".join(
        f"<tr><td>{html.escape(name)}</td><td>{value['feature_count']:,}</td>"
        f"<td><a href='{html.escape(value['layer_url'])}'>{html.escape(value['layer_name'])}</a></td></tr>"
        for name, value in evidence.items()
    )
    report = f"""<!doctype html><html lang="en"><meta charset="utf-8"><title>AGV water connectivity</title>
<style>body{{font:16px system-ui;max-width:1100px;margin:40px auto;line-height:1.55;padding:0 20px}}
table{{border-collapse:collapse}}td,th{{border:1px solid #ccc;padding:8px;text-align:left}}pre{{white-space:pre-wrap}}</style>
<h1>AGV water connectivity and assumed outlet-flow scenario</h1>
<p><a href="../nitrogen_map.html">Open the enhanced nitrogen map</a></p>
<p><strong>This is an outlet scenario, not observed hydraulic flow.</strong> The user selected
{html.escape(args.outlet)} (Berlage bridge). Direction is inferred only on the connected network by decreasing
shortest network distance to that point. All time series are interpreted as fixed GMT+1 (UTC+01:00), without DST.</p>
<h2>Official GIS sources</h2><table><tr><th>Dataset</th><th>Downloaded features</th><th>Official service</th></tr>
{source_rows}</table><h2>Results and limitations</h2>
<pre>{html.escape(json.dumps({key: value for key, value in summary.items() if key != 'sources'}, indent=2))}</pre>
<h2>How to use the relationships</h2><p>measurement_relations.csv records next reachable monitoring sites
along network branches. scenario_downstream means the complete path descends toward the chosen outlet;
scenario_upstream is the reciprocal. A path between different branches need not have either direction,
even when both sites lie in the same connected component. Disconnected components remain unresolved.
No direction is inferred from digitization order, numeric symbol rotation, coordinate latitude, or bed height.</p>
<p>AMS011 is {summary['outlet_snap_distance_m']:.1f} m from the matched centreline. Matches over 25 m
are flagged for manual review; the maximum permitted snap distance is {args.snap_distance:g} m.
Nearby structures within 10 m of routes are flagged, not assumed passable. Current primary-watercourse
GIS cannot establish historical connectivity or all secondary-ditch connections.</p>
<h2>Files</h2><p>measurement_network_matches.csv records all 1,055 nitrogen sites, including unmatched and
ambiguous matches, snapping offsets, network components and water-level area membership.
pump_series_gis.csv joins the 83 flow-series IDs to official pump asset codes without collapsing individual pumps.
measurement_relations.geojson retains full route geometry; watercourse_network.geojson, pumping_stations.geojson,
hydraulic_structures.geojson and water_level_areas.geojson support GIS reuse.
source/ preserves original downloaded snapshots and layer metadata; provenance.json records the queries,
completeness counts, edit timestamps, limitations and the single explicitly audited polygon repair.</p>
<p>Public accessibility does not establish a redistribution license. The portal license fields were empty;
confirm reuse conditions before redistributing snapshots. Attribution: Waterschap Amstel, Gooi en Vecht / Waternet.</p>
</html>"""
    (target / "report.html").write_text(report, encoding="utf-8")
    print(json.dumps({key: value for key, value in summary.items() if key != "sources"}, indent=2))


if __name__ == "__main__":
    main()
